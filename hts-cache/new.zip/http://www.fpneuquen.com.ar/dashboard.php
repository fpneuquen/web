

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-D23TBS0BCN"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-D23TBS0BCN');
    </script>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Web de consulta de Centros de Formacion Profesional" />
    <meta name="author" content="Silvio Stenta" />
    <title>Formacion Profesional WEB</title>
    <link rel="icon" type="image/png" href="img/logofp.png">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
 <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 --></head>

<body class="sb-nav-fixed">
    <nav class="navbar navbar-expand-lg navbar-dark ">
        <!-- Navbar Brand-->
        <button class="btn btn-link btn-sm order-1 order-lg-1 me-4 me-lg-1" id="sidebarToggle" href="index.php">
            <i class="fas fa-bars fa-lg "></i></button>
        <a class="navbar-brand ps-3" href="index.php"><img src="img/logo fp 288x271.png" class="img-fluid" alt="max-width: 30%;height: auto" width="20%"></a>
        <!-- Sidebar Toggle-->

        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <!-- <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button> -->
            </div>
        </form>
        <!-- Navbar User-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="login.php">Login</a></li>
                    <li><a class="dropdown-item" href="./administrador/inicio.php">Settings</a></li>
                    <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="cerrar.php">Cerrar</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <!-- Navbar Lateral -->

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-primary" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Todas las Escuelas
                        </a>
                        <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                            </nav>
                        </div>
                        <!-- <div class="sb-sidenav-menu-heading">Addons</div> -->
                        <!--                         <a class="nav-link" href="charts.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Graficos
                        </a> -->


                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseCFP" aria-expanded="false" aria-controls="collapseCFP">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Centros
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseCFP" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="table.php"><i class="fa fa-book" aria-hidden="true"></i>Listado por Zona</a>
                                <a class="nav-link" href="centrosxzonas.php"><i class="fas fa-map-pin" aria-hidden="true"></i>Ubicacion por Zona</a>
                            </nav>
                        </div>


                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseTray" aria-expanded="false" aria-controls="collapseTray">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Trayectos Formativos
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseTray" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="Sectores.php">
                                    <div class="sb-nav-link-icon"> <i class="fa-brands fa-bandcamp"></i></div>
                                    Sectores Productivos
                                </a>
                                <a class="nav-link" href="SubSectores.php">
                                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                    Sub-Sectores
                                </a>
                                <a class="nav-link" href="TrayectosFormativos.php">
                                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                    Trayectos Formativos
                                </a>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>

                    invitado                </div>
            </nav>
        </div>
        <!-- Principal -->



        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="js/scripts.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.css" />
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/fc-4.0.2/r-2.2.9/rr-1.2.8/sc-2.0.5/sl-1.3.4/datatables.min.css" />

        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/fc-4.0.2/r-2.2.9/rr-1.2.8/sc-2.0.5/sl-1.3.4/datatables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.1/b-2.2.3/b-colvis-2.2.3/b-html5-2.2.3/b-print-2.2.3/datatables.min.js"></script>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

        <div id="layoutSidenav_content">
            <main>


<div class="container-fluid px-4">
                        <h1 class="mt-4">Principal</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Escritorio</a></li>
                            <li class="breadcrumb-item active">Escuelas</li>
                        </ol>

                        <div class="card mb-4">
                            <div class="card-body">
                                Listado de Escuelas de la Provinica                                 .
                            </div>

                        </div>

                           <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Listado de Escuelas
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple" class="table table-striped table-bordered" >
                                    <thead>
                                        <tr>
                                            <th>Centro</th>
                                            <th>Domicilio</th>
                                            <th>Email</th>
                                            <th>Localidad</th>
                                            <th>Zona</th>
                                            <th>Telefono</th>
                                            <th>Ubicacion</th>
                                        </tr>
                                    </thead>
                                    
                                        
                                    <tbody>                                        <tr>
                                            <td>CE.M.O.E. SAN JOSÉ OBRERO</td>
                                            <td>PRIMEROS POBLADORES 1123</td>
                                            <td><a href="mailto:cemoesanjoseobrero@gmail.com"> cemoesanjoseobrero@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423957</td>
                                            <td><a href="./mapas.php?id=580000100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 64</td>
                                            <td>MORENO PERITO 281</td>
                                            <td><a href="mailto:cpem064@neuquen.gov.ar"> cpem064@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994430365</td>
                                            <td><a href="./mapas.php?id=580000300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 248 DR GREGORIO ÁLVAREZ</td>
                                            <td>RUTA PROVINCIAL 21</td>
                                            <td><a href="mailto:primaria248@neuquen.gov.ar"> primaria248@neuquen.gov.ar </a></td>
                                            <td>PARAJE LA Y</td>
                                            <td>NORTE</td>
                                            <td>2948491042</td>
                                            <td><a href="./mapas.php?id=580000700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 164</td>
                                            <td>LAS LENGAS 426</td>
                                            <td><a href="mailto:primaria164@neuquen.gov.ar"> primaria164@neuquen.gov.ar </a></td>
                                            <td>CAVIAHUE</td>
                                            <td>NORTE</td>
                                            <td>2948495091</td>
                                            <td><a href="./mapas.php?id=580000900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.E.P.A. 56</td>
                                            <td>CALLE 131</td>
                                            <td><a href="mailto:cepa056@neuquen.gov.ar"> cepa056@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>2994855307</td>
                                            <td><a href="./mapas.php?id=580001200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 100</td>
                                            <td>CALLE 15</td>
                                            <td><a href="mailto:primaria100@neuquen.gov.ar"> primaria100@neuquen.gov.ar </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994904235</td>
                                            <td><a href="./mapas.php?id=580001400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 271 ALBERGUE ADOLFO KAPELUSZ</td>
                                            <td>FERNANDEZ JOSE</td>
                                            <td><a href="mailto:primaria271@neuquen.gov.ar"> primaria271@neuquen.gov.ar </a></td>
                                            <td>OCTAVIO PICO</td>
                                            <td>ANELO</td>
                                            <td>2996565429</td>
                                            <td><a href="./mapas.php?id=580001600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 37 CAHUIN RUCA</td>
                                            <td>RIO NEGRO</td>
                                            <td><a href="mailto:jardin037@neuquen.gov.ar"> jardin037@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994887066</td>
                                            <td><a href="./mapas.php?id=580001700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 300</td>
                                            <td>PERON JUAN D PTE 587</td>
                                            <td><a href="mailto:primaria300@neuquen.gov.ar"> primaria300@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886044</td>
                                            <td><a href="./mapas.php?id=580001800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 24</td>
                                            <td>20 DE DICIEMBRE BV 209</td>
                                            <td><a href="mailto:cpem024@neuquen.gov.ar"> cpem024@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886043</td>
                                            <td><a href="./mapas.php?id=580001900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 14</td>
                                            <td>DE ROSAS JUAN MANUEL 688</td>
                                            <td><a href="mailto:especial014@neuquen.gov.ar"> especial014@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886452</td>
                                            <td><a href="./mapas.php?id=580002000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 19 HUNELUE</td>
                                            <td>PINO HACHADO</td>
                                            <td><a href="mailto:jardin19hunelue@neuquen.gov.ar"> jardin19hunelue@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499530</td>
                                            <td><a href="./mapas.php?id=580002300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 19 ANEXO LA BUITRERA</td>
                                            <td>ALANIZ</td>
                                            <td><a href="mailto:jardin19hunelue@neuquen.gov.ar; jardin19labuitrera@neuquen.gov.ar"> jardin19hunelue@neuquen.gov.ar; jardin19labuitrera@neuquen.gov.ar </a></td>
                                            <td>LA BUITRERA</td>
                                            <td>CENTRO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580002301"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 19 ANEXO LAS LAJITAS</td>
                                            <td>DEL TRABAJO AV</td>
                                            <td><a href="mailto:jardin19hunelue@neuquen.gov.ar"> jardin19hunelue@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580002302"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 19 HUNELUE ANEXO ESCUELA PRIMARIA 170</td>
                                            <td>OLASCOAGA 360</td>
                                            <td><a href="mailto:jardin19hunelue@neuquen.gov.ar"> jardin19hunelue@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499353</td>
                                            <td><a href="./mapas.php?id=580002303"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 221 SEGUNDO MILLAQUEO LLOICA</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:primaria221@neuquen.gov.ar"> primaria221@neuquen.gov.ar </a></td>
                                            <td>LOS ALAZANES</td>
                                            <td>CENTRO</td>
                                            <td>2942481100</td>
                                            <td><a href="./mapas.php?id=580002500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 66</td>
                                            <td>SAAVEDRA CORNELIO 180</td>
                                            <td><a href="mailto:cpem066@neuquen.gov.ar"> cpem066@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499358</td>
                                            <td><a href="./mapas.php?id=580002600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 279</td>
                                            <td>DEL TRABAJO AV</td>
                                            <td><a href="mailto:primaria279@neuquen.gov.ar"> primaria279@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499042</td>
                                            <td><a href="./mapas.php?id=580002700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 75 ALBERGUE DON ENRIQUE CHEUQUEL</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria075@neuquen.gov.ar"> primaria075@neuquen.gov.ar </a></td>
                                            <td>MALLIN DE LOS CABALLOS</td>
                                            <td>CENTRO</td>
                                            <td>2942665784</td>
                                            <td><a href="./mapas.php?id=580003000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 15 DESIDERIA LANDESTOY DE MEDRANO</td>
                                            <td>DON BOSCO AV 147</td>
                                            <td><a href="mailto:primaria015@neuquen.gov.ar"> primaria015@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421223</td>
                                            <td><a href="./mapas.php?id=580003200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.E.P.A. 121</td>
                                            <td>DE CHURRARIN MARIA</td>
                                            <td><a href="mailto:cepa121@neuquen.gov.ar"> cepa121@neuquen.gov.ar </a></td>
                                            <td>PICUN LEUFU</td>
                                            <td>SUR</td>
                                            <td>294215453771</td>
                                            <td><a href="./mapas.php?id=580003300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 269</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria269@neuquen.gov.ar"> primaria269@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994869033</td>
                                            <td><a href="./mapas.php?id=580003500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 281</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria281@neuquen.gov.ar"> primaria281@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155520363</td>
                                            <td><a href="./mapas.php?id=580003600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 243</td>
                                            <td>CALLE PRINCIPAL</td>
                                            <td><a href="mailto:primaria243@neuquen.gov.ar"> primaria243@neuquen.gov.ar </a></td>
                                            <td>SAUZAL BONITO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2995865562</td>
                                            <td><a href="./mapas.php?id=580003700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 291 ALBERGUE SR RAÚL JORGE OTAÑO</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria291@neuquen.gov.ar"> primaria291@neuquen.gov.ar </a></td>
                                            <td>AGUADA TOLEDO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2995866949</td>
                                            <td><a href="./mapas.php?id=580003800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 176</td>
                                            <td>RUTA NACIONAL 22 KM 1200</td>
                                            <td><a href="mailto:primaria176@neuquen.gov.ar"> primaria176@neuquen.gov.ar </a></td>
                                            <td>CHALLACO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155115152</td>
                                            <td><a href="./mapas.php?id=580003900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 59</td>
                                            <td>ALSINA ADOLFO 100</td>
                                            <td><a href="mailto:cpem059@neuquen.gov.ar"> cpem059@neuquen.gov.ar </a></td>
                                            <td>PIEDRA DEL AGUILA</td>
                                            <td>CENTRO</td>
                                            <td>2942493030</td>
                                            <td><a href="./mapas.php?id=580004200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 32</td>
                                            <td>ALSINA ADOLFO 100</td>
                                            <td><a href="mailto:cpem032@neuquen.gov.ar"> cpem032@neuquen.gov.ar </a></td>
                                            <td>PIEDRA DEL AGUILA</td>
                                            <td>CENTRO</td>
                                            <td>2942493189</td>
                                            <td><a href="./mapas.php?id=580004300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ALBERGUE CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 32</td>
                                            <td>LOPEZ ALANIZ</td>
                                            <td><a href="mailto:cpem32albergue@neuquen.gov.ar"> cpem32albergue@neuquen.gov.ar </a></td>
                                            <td>PIEDRA DEL AGUILA</td>
                                            <td>CENTRO</td>
                                            <td>2942493534</td>
                                            <td><a href="./mapas.php?id=580004301"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 10 FRANCISCO PASCACIO MORENO</td>
                                            <td>ALVAREZ GREGORIO DR 254</td>
                                            <td><a href="mailto:primaria010@neuquen.gov.ar"> primaria010@neuquen.gov.ar </a></td>
                                            <td>PIEDRA DEL AGUILA</td>
                                            <td>CENTRO</td>
                                            <td>2942493133</td>
                                            <td><a href="./mapas.php?id=580004600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 301</td>
                                            <td>ARGERICH MANUEL GREGORIO</td>
                                            <td><a href="mailto:primaria301@neuquen.gov.ar"> primaria301@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299156314922</td>
                                            <td><a href="./mapas.php?id=580004700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 13 DE SERVICIOS MÚLTIPLES</td>
                                            <td>RIO PILCOMAYO 1191</td>
                                            <td><a href="mailto:ee13serviciosmultiples@neuquen.gov.ar"> ee13serviciosmultiples@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994934672</td>
                                            <td><a href="./mapas.php?id=580004800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 8 DR ALBERTO PLOTTIER</td>
                                            <td>MORENO PERITO</td>
                                            <td><a href="mailto:cpem008@neuquen.gov.ar"> cpem008@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933149</td>
                                            <td><a href="./mapas.php?id=580004900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 295 RUCA HUENEY</td>
                                            <td>LAS GAVIOTAS 1695</td>
                                            <td><a href="mailto:primaria295@neuquen.gov.ar"> primaria295@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994464284</td>
                                            <td><a href="./mapas.php?id=580005000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DOMINGO SAVIO</td>
                                            <td>MARTINEZ GREGORIO 670</td>
                                            <td><a href="mailto:dsavionq@yahoo.com"> dsavionq@yahoo.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435223</td>
                                            <td><a href="./mapas.php?id=580005100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 32 PEÑI HUE</td>
                                            <td>CIUDAD DE RIO GALLEGOS 1690</td>
                                            <td><a href="mailto:jardin032@neuquen.gov.ar"> jardin032@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994465187</td>
                                            <td><a href="./mapas.php?id=580005200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 40</td>
                                            <td>LAS GAVIOTAS 1690</td>
                                            <td><a href="mailto:cpem040@neuquen.gov.ar"> cpem040@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994465188</td>
                                            <td><a href="./mapas.php?id=580005300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 56</td>
                                            <td>PALHUEN 79</td>
                                            <td><a href="mailto:cpem056@neuquen.gov.ar"> cpem056@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994936266</td>
                                            <td><a href="./mapas.php?id=580005400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 8 CAPITÁN DON JUAN DE SAN MARTÍN</td>
                                            <td>PERTICONE EUGENIO 55</td>
                                            <td><a href="mailto:epet008@neuquen.gov.ar"> epet008@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994424364</td>
                                            <td><a href="./mapas.php?id=580005700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA SUPERIOR DE BELLAS ARTES MANUEL BELGRANO</td>
                                            <td>LANIN 1948</td>
                                            <td><a href="mailto:bellasartesneuquen@gmail.com"> bellasartesneuquen@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994434369</td>
                                            <td><a href="./mapas.php?id=580005800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA SUPERIOR DE BELLAS ARTES ANEXO HUINGANCO</td>
                                            <td>LOS ÑIRES</td>
                                            <td><a href="mailto:bellasartesneuquen@gmail.com"> bellasartesneuquen@gmail.com </a></td>
                                            <td>HUINGANCO</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580005801"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA SUPERIOR DE BELLAS ARTES MANUEL BELGRANO ANEXO OESTE</td>
                                            <td>GOMEZ CASIMIRO 2200</td>
                                            <td><a href="mailto:bellasartesneuquen@gmail.com"> bellasartesneuquen@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994434369</td>
                                            <td><a href="./mapas.php?id=580005802"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 121 JOAQUÍN V.GONZÁLEZ</td>
                                            <td>MAZZONI PEDRO 725</td>
                                            <td><a href="mailto:primaria121@neuquen.gov.ar"> primaria121@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994485096</td>
                                            <td><a href="./mapas.php?id=580005900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 191 HÉROES DE MALVINAS</td>
                                            <td>ALERCE</td>
                                            <td><a href="mailto:primaria191@neuquen.gov.ar"> primaria191@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>2994855150</td>
                                            <td><a href="./mapas.php?id=580006000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 273 CARLOS JULIO SANG</td>
                                            <td>ALERCE</td>
                                            <td><a href="mailto:primaria273@neuquen.gov.ar"> primaria273@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>2994855066</td>
                                            <td><a href="./mapas.php?id=580006100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 58</td>
                                            <td>DE ROSAS JUAN MANUEL 100</td>
                                            <td><a href="mailto:cpem058@neuquen.gov.ar"> cpem058@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994963137</td>
                                            <td><a href="./mapas.php?id=580006200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 170 BARTOLOMÉ MITRE</td>
                                            <td>ALBERDI JUAN BAUTISTA 661</td>
                                            <td><a href="mailto:primaria170@neuquen.gov.ar"> primaria170@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499071</td>
                                            <td><a href="./mapas.php?id=580006300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 13</td>
                                            <td>4 DE AGOSTO</td>
                                            <td><a href="mailto:epet013@neuquen.gov.ar"> epet013@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421688</td>
                                            <td><a href="./mapas.php?id=580006500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 34 AYENHUE</td>
                                            <td>LAS ROCAS 214</td>
                                            <td><a href="mailto:jardin034@neuquen.gov.ar"> jardin034@neuquen.gov.ar </a></td>
                                            <td>PIEDRA DEL AGUILA</td>
                                            <td>CENTRO</td>
                                            <td>2942493376</td>
                                            <td><a href="./mapas.php?id=580006700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 27</td>
                                            <td>ZABALETA M AV 678</td>
                                            <td><a href="mailto:cpem027@neuquen.gov.ar"> cpem027@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994936833</td>
                                            <td><a href="./mapas.php?id=580006800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 36 THEIN</td>
                                            <td>DEL TRABAJADOR AV</td>
                                            <td><a href="mailto:jardin036@neuquen.gov.ar"> jardin036@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460779</td>
                                            <td><a href="./mapas.php?id=580006900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 22 GRAL JOSE DE SAN MARTÍN</td>
                                            <td>SAN MARTIN AV 593</td>
                                            <td><a href="mailto:primaria022@neuquen.gov.ar"> primaria022@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994963287</td>
                                            <td><a href="./mapas.php?id=580007000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 151</td>
                                            <td>VIÑUELA MARCELO</td>
                                            <td><a href="mailto:primaria151@neuquen.gov.ar"> primaria151@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994963195</td>
                                            <td><a href="./mapas.php?id=580007100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 2 MI MAÑANA</td>
                                            <td>ROTTER PADRE AV 456</td>
                                            <td><a href="mailto:especial002@neuquen.gov.ar"> especial002@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994965272</td>
                                            <td><a href="./mapas.php?id=580007200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 3 SANTA TERESITA</td>
                                            <td>ANTARTIDA ARGENTINA 301</td>
                                            <td><a href="mailto:jardin003@neuquen.gov.ar; aachaco3@gmail.com"> jardin003@neuquen.gov.ar; aachaco3@gmail.com </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994967349</td>
                                            <td><a href="./mapas.php?id=580007300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 49 WOLF SCHCOLNIK</td>
                                            <td>SUIPACHA 137</td>
                                            <td><a href="mailto:primaria049@neuquen.gov.ar"> primaria049@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994964243</td>
                                            <td><a href="./mapas.php?id=580007400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 159</td>
                                            <td>CERROS COLORADOS</td>
                                            <td><a href="mailto:primaria159@neuquen.gov.ar"> primaria159@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994861193</td>
                                            <td><a href="./mapas.php?id=580007500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 12</td>
                                            <td>SAN MARTIN AV 593</td>
                                            <td><a href="mailto:epa012@neuquen.gov.ar"> epa012@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994963287</td>
                                            <td><a href="./mapas.php?id=580007600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 10 JARDÍN ESCONDIDO</td>
                                            <td>LAS FLORES AV 1655</td>
                                            <td><a href="mailto:jardin010@neuquen.gov.ar"> jardin010@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994330696</td>
                                            <td><a href="./mapas.php?id=580007900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 249</td>
                                            <td>PRIMEROS POBLADORES</td>
                                            <td><a href="mailto:primaria249@neuquen.gov.ar"> primaria249@neuquen.gov.ar </a></td>
                                            <td>SANTO TOMAS</td>
                                            <td>CENTRO</td>
                                            <td>2942489427</td>
                                            <td><a href="./mapas.php?id=580008000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 133 DR JUAN KEIDEL</td>
                                            <td>ROTTER PEDRO AV 517</td>
                                            <td><a href="mailto:primaria133@neuquen.gov.ar"> primaria133@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994967388</td>
                                            <td><a href="./mapas.php?id=580008500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 55 CTE LUIS PIEDRABUENA</td>
                                            <td>RUTA PROVINCIAL 20</td>
                                            <td><a href="mailto:primaria055@neuquen.gov.ar"> primaria055@neuquen.gov.ar </a></td>
                                            <td>LIMAY CENTRO</td>
                                            <td>SUR</td>
                                            <td>2942492493</td>
                                            <td><a href="./mapas.php?id=580008700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 129</td>
                                            <td>RUTA PROVINCIAL 20 KM 25</td>
                                            <td><a href="mailto:primaria129@neuquen.gov.ar"> primaria129@neuquen.gov.ar </a></td>
                                            <td>EL SAUCE</td>
                                            <td>SUR</td>
                                            <td>294215547154</td>
                                            <td><a href="./mapas.php?id=580008800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 5</td>
                                            <td>RIO NEUQUEN 22</td>
                                            <td><a href="mailto:jardin005@neuquen.gov.ar"> jardin005@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994960636</td>
                                            <td><a href="./mapas.php?id=580008900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 63 PROFESOR HUGO FERNÁNDEZ</td>
                                            <td>13 DE DICIEMBRE</td>
                                            <td><a href="mailto:primaria063@neuquen.gov.ar"> primaria063@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994966169</td>
                                            <td><a href="./mapas.php?id=580009200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 7 MERCEDITAS DE SAN MARTÍN</td>
                                            <td>LAGO VILLARINO 325</td>
                                            <td><a href="mailto:jardin007@neuquen.gov.ar"> jardin007@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994965821</td>
                                            <td><a href="./mapas.php?id=580009300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 4 MARINA MARGARITA RAVIOLI</td>
                                            <td>CHUBUT 581</td>
                                            <td><a href="mailto:jardin004@neuquen.gov.ar"> jardin004@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994961401</td>
                                            <td><a href="./mapas.php?id=580009400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 119 PRÓSPERO GUILLERMO ALEMANDRI</td>
                                            <td>PAZ GRL 157</td>
                                            <td><a href="mailto:primaria119@neuquen.gov.ar"> primaria119@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994962493</td>
                                            <td><a href="./mapas.php?id=580009500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 138</td>
                                            <td>25 DE MAYO 532</td>
                                            <td><a href="mailto:primaria138@neuquen.gov.ar"> primaria138@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994960833</td>
                                            <td><a href="./mapas.php?id=580009600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 264 ALBERGUE</td>
                                            <td>RUTA PROVINCIAL 1</td>
                                            <td><a href="mailto:primaria264@neuquen.gov.ar"> primaria264@neuquen.gov.ar </a></td>
                                            <td>LOS CHIHUIDOS</td>
                                            <td>ANELO</td>
                                            <td>2996318368</td>
                                            <td><a href="./mapas.php?id=580009700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 16</td>
                                            <td>PERON EVA 630</td>
                                            <td><a href="mailto:primaria016@neuquen.gov.ar"> primaria016@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994431924</td>
                                            <td><a href="./mapas.php?id=580009800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO DON BOSCO</td>
                                            <td>CHANETON ABEL 599</td>
                                            <td><a href="mailto:dirprimdbnqn@gmail.com"> dirprimdbnqn@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422229</td>
                                            <td><a href="./mapas.php?id=580009900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 21 RUPU MOGÑEN</td>
                                            <td>CATRIEL 1105</td>
                                            <td><a href="mailto:jardin021@neuquen.gov.ar"> jardin021@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994431434</td>
                                            <td><a href="./mapas.php?id=580010100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 6 ROSARIO VERA PEÑALOZA</td>
                                            <td>GALARZA 2565</td>
                                            <td><a href="mailto:jardin006@neuquen.gov.ar"> jardin006@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994468509</td>
                                            <td><a href="./mapas.php?id=580010200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 147 ISLAS MALVINAS</td>
                                            <td>NOGOYA 2725</td>
                                            <td><a href="mailto:primaria147@neuquen.gov.ar"> primaria147@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994468234</td>
                                            <td><a href="./mapas.php?id=580010300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 201 HIPÓLITO YRIGOYEN</td>
                                            <td>BELGRANO MANUEL GRL 485</td>
                                            <td><a href="mailto:primaria201@neuquen.gov.ar"> primaria201@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423748</td>
                                            <td><a href="./mapas.php?id=580010400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 22</td>
                                            <td>MATHEU DOMINGO 145</td>
                                            <td><a href="mailto:cpem022@neuquen.gov.ar"> cpem022@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435606</td>
                                            <td><a href="./mapas.php?id=580010500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 10 GRAL.ENRIQUE MOSCONI</td>
                                            <td>SCHREIBER JUAN 892</td>
                                            <td><a href="mailto:epet010@neuquen.gov.ar"> epet010@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994963288</td>
                                            <td><a href="./mapas.php?id=580010600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 123 TOMÁS CASULLO</td>
                                            <td>BIDART BEBA</td>
                                            <td><a href="mailto:primaria123@neuquen.gov.ar"> primaria123@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994964634</td>
                                            <td><a href="./mapas.php?id=580010700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 4 DE SERVICIOS MÚLTIPLES</td>
                                            <td>ELORDI GDOR 1315</td>
                                            <td><a href="mailto:especial004@neuquen.gov.ar"> especial004@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994482987</td>
                                            <td><a href="./mapas.php?id=580010800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 63</td>
                                            <td>MORENO PERITO 281</td>
                                            <td><a href="mailto:cpem063@neuquen.gov.ar"> cpem063@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422255</td>
                                            <td><a href="./mapas.php?id=580010900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 205 MAESTROS NEUQUINOS</td>
                                            <td>LOS PENSAMIENTOS 291</td>
                                            <td><a href="mailto:primaria205@neuquen.gov.ar"> primaria205@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994330699</td>
                                            <td><a href="./mapas.php?id=580011000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 4 CRIO JOSÉ BELINDO LÓPEZ</td>
                                            <td>MANFREDI PSJE</td>
                                            <td><a href="mailto:primaria004@neuquen.gov.ar"> primaria004@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994331781</td>
                                            <td><a href="./mapas.php?id=580011100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 25</td>
                                            <td>RAMOS DE ESPEJOS 2550</td>
                                            <td><a href="mailto:cpem025@neuquen.gov.ar"> cpem025@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994331684</td>
                                            <td><a href="./mapas.php?id=580011200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 20</td>
                                            <td>22 DE OCTUBRE</td>
                                            <td><a href="mailto:cpem020@neuquen.gov.ar"> cpem020@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994962218</td>
                                            <td><a href="./mapas.php?id=580011300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 292</td>
                                            <td>EJERCITO ARGENTINO 380</td>
                                            <td><a href="mailto:primaria292@neuquen.gov.ar"> primaria292@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994966349</td>
                                            <td><a href="./mapas.php?id=580011400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 102 YACIMIENTOS PETROLÍFEROS FISCALES</td>
                                            <td>SALTA 650</td>
                                            <td><a href="mailto:primaria102@neuquen.gov.ar"> primaria102@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994960452</td>
                                            <td><a href="./mapas.php?id=580011500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 51</td>
                                            <td>NAVARRETE WENCESLAO</td>
                                            <td><a href="mailto:cpem051@neuquen.gov.ar"> cpem051@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994964572</td>
                                            <td><a href="./mapas.php?id=580011600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 35 PICHI ANTU</td>
                                            <td>PERNISECK LUDOVICO</td>
                                            <td><a href="mailto:jardin035@neuquen.gov.ar"> jardin035@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994960550</td>
                                            <td><a href="./mapas.php?id=580011700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 45</td>
                                            <td>SAN MARTIN 973</td>
                                            <td><a href="mailto:primaria045@neuquen.gov.ar"> primaria045@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994967363</td>
                                            <td><a href="./mapas.php?id=580011800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 172</td>
                                            <td>LAGO CURRHUE 180</td>
                                            <td><a href="mailto:primaria172@neuquen.gov.ar"> primaria172@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994966419</td>
                                            <td><a href="./mapas.php?id=580011900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 143 DR.VÍCTOR EZIO ZANI</td>
                                            <td>PERNISEK LUDOVICO</td>
                                            <td><a href="mailto:primaria143@neuquen.gov.ar"> primaria143@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994967305</td>
                                            <td><a href="./mapas.php?id=580012000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 137 WHILMIRO PEDRO CHALLIOL</td>
                                            <td>ELORDI GDOR 532</td>
                                            <td><a href="mailto:primaria137@neuquen.gov.ar"> primaria137@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994960650</td>
                                            <td><a href="./mapas.php?id=580012100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 1 MARGARITA SALINAS DE PÁEZ</td>
                                            <td>MORENO PERITO 240</td>
                                            <td><a href="mailto:epet001@neuquen.gov.ar"> epet001@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994961191</td>
                                            <td><a href="./mapas.php?id=580012200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 43</td>
                                            <td>OLASCOAGA MANUEL JOSE AV 501</td>
                                            <td><a href="mailto:cpem043@neuquen.gov.ar"> cpem043@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994963352</td>
                                            <td><a href="./mapas.php?id=580012300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 272 ELOÍSA C.DE CANTONI</td>
                                            <td>DI PAOLO 539</td>
                                            <td><a href="mailto:primaria272@neuquen.gov.ar"> primaria272@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994961502</td>
                                            <td><a href="./mapas.php?id=580012400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 6</td>
                                            <td>OLASCOAGA MANUEL JOSE 501</td>
                                            <td><a href="mailto:cpem006@neuquen.gov.ar"> cpem006@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994963352</td>
                                            <td><a href="./mapas.php?id=580012500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 132 CEFERINO NAMUNCURA</td>
                                            <td>PURRAN CACIQUE 499</td>
                                            <td><a href="mailto:primaria132@neuquen.gov.ar"> primaria132@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994487652</td>
                                            <td><a href="./mapas.php?id=580012600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 29</td>
                                            <td>DE SAN MARTIN JOSE GRL 5202</td>
                                            <td><a href="mailto:cpem029@neuquen.gov.ar"> cpem029@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440631</td>
                                            <td><a href="./mapas.php?id=580012700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 26</td>
                                            <td>CALLE 5</td>
                                            <td><a href="mailto:cpem026@neuquen.gov.ar"> cpem026@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461549</td>
                                            <td><a href="./mapas.php?id=580012800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 3</td>
                                            <td>LAGO NONTHUE 2999</td>
                                            <td><a href="mailto:epet003@neuquen.gov.ar"> epet003@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460722</td>
                                            <td><a href="./mapas.php?id=580012900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 115</td>
                                            <td>CASTELLI JUAN JOSE 4851</td>
                                            <td><a href="mailto:primaria115@neuquen.gov.ar"> primaria115@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460222</td>
                                            <td><a href="./mapas.php?id=580013000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 256 REPÚBLICA DE CHILE</td>
                                            <td>GALARZA 2451</td>
                                            <td><a href="mailto:primaria256@neuquen.gov.ar"> primaria256@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994468740</td>
                                            <td><a href="./mapas.php?id=580013100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 197 PROF SILVIA ROGGETTI</td>
                                            <td>ACOSTA RAMON 2290</td>
                                            <td><a href="mailto:primaria197@neuquen.gov.ar"> primaria197@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994426134</td>
                                            <td><a href="./mapas.php?id=580013200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 12</td>
                                            <td>MATHEU DOMINGO 145</td>
                                            <td><a href="mailto:cpem012@neuquen.gov.ar"> cpem012@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994430256</td>
                                            <td><a href="./mapas.php?id=580013300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 23</td>
                                            <td>LAINEZ MANUEL 102</td>
                                            <td><a href="mailto:cpem023@neuquen.gov.ar"> cpem023@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994436196</td>
                                            <td><a href="./mapas.php?id=580013500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PROVINCIAL DE EDUCACIÓN TERCIARIA 1</td>
                                            <td>ARGENTINA AV 935</td>
                                            <td><a href="mailto:ipet001@neuquen.gov.ar"> ipet001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994471913</td>
                                            <td><a href="./mapas.php?id=580013600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PROVINCIAL DE EDUCACIÓN TERCIARIA 1 ANEXO ALUMINE</td>
                                            <td>PARRA RAMON</td>
                                            <td><a href="mailto:educacionsuperioralumine@gmail.com"> educacionsuperioralumine@gmail.com </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2994471913</td>
                                            <td><a href="./mapas.php?id=580013601"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PROVINCIAL DE EDUCACIÓN TERCIARIA 1 ANEXO ZAPALA</td>
                                            <td>DEL MAESTRO AV 676</td>
                                            <td><a href="mailto:educacionsuperiorzapala@gmail.com"> educacionsuperiorzapala@gmail.com </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942432475</td>
                                            <td><a href="./mapas.php?id=580013607"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PROVINCIAL DE EDUCACIÓN TERCIARIA 1 ANEXO RINCÓN DE LOS SAUCES</td>
                                            <td>PERON JUAN D PTE 587</td>
                                            <td><a href="mailto:educacionsuperiorrdls@gmail.com"> educacionsuperiorrdls@gmail.com </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994887598</td>
                                            <td><a href="./mapas.php?id=580013608"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PROVINCIAL DE EDUCACIÓN TERCIARIA 1 ANEXO ANDACOLLO</td>
                                            <td>SAPAG FELIPE GDOR AV</td>
                                            <td><a href="mailto:secretaria@ipet1.edu.ar"> secretaria@ipet1.edu.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2948421272</td>
                                            <td><a href="./mapas.php?id=580013609"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PROVINCIAL DE EDUCACIÓN TERCIARIA 1 ANEXO AÑELO</td>
                                            <td>RUTA PROVINCIAL 17</td>
                                            <td><a href="mailto:secretaria.ipet1@gmail.com"> secretaria.ipet1@gmail.com </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994904000</td>
                                            <td><a href="./mapas.php?id=580013610"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PROVINCIAL DE EDUCACIÓN TERCIARIA ANEXO LAS LAJAS</td>
                                            <td>SANTA LUCIA 268</td>
                                            <td><a href="mailto:ipet001laslajas@neuquen.gov.ar"> ipet001laslajas@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>294215402067</td>
                                            <td><a href="./mapas.php?id=580013611"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PROVINCIAL DE EDUCACIÓN TERCIARIA 1 ANEXO PLAZA HUINCUL</td>
                                            <td>DEL LIBERTADOR AV 517</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580013612"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 66 DON JORGE EMILIO DE VEGA PESSINO</td>
                                            <td>RUTA PROVINCIAL 2</td>
                                            <td><a href="mailto:primaria066@neuquen.gov.ar"> primaria066@neuquen.gov.ar </a></td>
                                            <td>LA SALADA</td>
                                            <td>NORTE</td>
                                            <td>2948490300</td>
                                            <td><a href="./mapas.php?id=580014500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 66 DON JORGE EMILIO DE VEGA PESSINO ANEXO ARROYO BLANCO</td>
                                            <td>RUTA PROVINCIAL 2</td>
                                            <td><a href="mailto:primaria066@neuquen.gov.ar"> primaria066@neuquen.gov.ar </a></td>
                                            <td>ARROYO BLANCO</td>
                                            <td>NORTE</td>
                                            <td>2948490300</td>
                                            <td><a href="./mapas.php?id=580014501"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 331 ALBERGUE</td>
                                            <td>RUTA PROVINCIAL 41</td>
                                            <td><a href="mailto:primaria331@neuquen.gov.ar"> primaria331@neuquen.gov.ar </a></td>
                                            <td>CAEPE MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948492800</td>
                                            <td><a href="./mapas.php?id=580014600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 24 BENJAMÍN ZORRILLA</td>
                                            <td>EL LIBERTADOR AV</td>
                                            <td><a href="mailto:primaria024@neuquen.gov.ar"> primaria024@neuquen.gov.ar </a></td>
                                            <td>TRICAO MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948497951</td>
                                            <td><a href="./mapas.php?id=580014800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 71</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria071@neuquen.gov.ar"> primaria071@neuquen.gov.ar </a></td>
                                            <td>TRES CHORROS</td>
                                            <td>NORTE</td>
                                            <td>2948480240</td>
                                            <td><a href="./mapas.php?id=580015100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 76 CTE PATROCINIO RECABARREN</td>
                                            <td>LOS ÑIRES</td>
                                            <td><a href="mailto:primaria076@neuquen.gov.ar"> primaria076@neuquen.gov.ar </a></td>
                                            <td>HUINGANCO</td>
                                            <td>NORTE</td>
                                            <td>2948499000</td>
                                            <td><a href="./mapas.php?id=580015400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 149</td>
                                            <td>RUTA PROVICIAL 39</td>
                                            <td><a href="mailto:primaria149@neuquen.gov.ar"> primaria149@neuquen.gov.ar </a></td>
                                            <td>HUARACO</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1160</td>
                                            <td><a href="./mapas.php?id=580015500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 162 PRIMERA AUTORIDAD CIVIL DEL NEUQUEN</td>
                                            <td>RUTA PROVINCIAL 39 11</td>
                                            <td><a href="mailto:primaria162@neuquen.gov.ar"> primaria162@neuquen.gov.ar </a></td>
                                            <td>CHARRA RUCA</td>
                                            <td>NORTE</td>
                                            <td>2948499019</td>
                                            <td><a href="./mapas.php?id=580015600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 93 JUAN PASCUAL PRINGLES</td>
                                            <td>BUTA MALLIN AV</td>
                                            <td><a href="mailto:primaria093@neuquen.gov.ar"> primaria093@neuquen.gov.ar </a></td>
                                            <td>LOS MICHES</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1197</td>
                                            <td><a href="./mapas.php?id=580015700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DIOCESANA PADRE ADOLFO FERNÁNDEZ</td>
                                            <td>LEGUIZAMON ONESIMO 1550</td>
                                            <td><a href="mailto:escuelapadrefito@yahoo.com.ar"> escuelapadrefito@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423534</td>
                                            <td><a href="./mapas.php?id=580016000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 6</td>
                                            <td>MISIONES 397</td>
                                            <td><a href="mailto:epa006@neuquen.gov.ar"> epa006@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422920</td>
                                            <td><a href="./mapas.php?id=580016100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES MATERNAL SUEÑITOS</td>
                                            <td>CLARO PSJE 655</td>
                                            <td><a href="mailto:vanesaboladeres@hotmail.com"> vanesaboladeres@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994425795</td>
                                            <td><a href="./mapas.php?id=580016200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA AGROPECUARIA 2</td>
                                            <td>RUTA NACIONAL 22 1233</td>
                                            <td><a href="mailto:epea002@neuquen.gov.ar"> epea002@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933478</td>
                                            <td><a href="./mapas.php?id=580016300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 289</td>
                                            <td>ASMAR GDOR 1770</td>
                                            <td><a href="mailto:primaria289@neuquen.gov.ar"> primaria289@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423403</td>
                                            <td><a href="./mapas.php?id=580016400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 53</td>
                                            <td>COLON CRISTOBAL 775</td>
                                            <td><a href="mailto:cpem053@neuquen.gov.ar"> cpem053@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994434399</td>
                                            <td><a href="./mapas.php?id=580016500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 207 CIUDAD DE SALTA</td>
                                            <td>BAHIA BLANCA 1100</td>
                                            <td><a href="mailto:primaria207@neuquen.gov.ar"> primaria207@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994425028</td>
                                            <td><a href="./mapas.php?id=580016600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 4</td>
                                            <td>MORENO PERITO 354</td>
                                            <td><a href="mailto:ifd004@neuquen.gov.ar"> ifd004@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994470266</td>
                                            <td><a href="./mapas.php?id=580016700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 3</td>
                                            <td>PEREZ TTE CNL 524</td>
                                            <td><a href="mailto:ifd003@neuquen.gov.ar"> ifd003@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972428190</td>
                                            <td><a href="./mapas.php?id=580017000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 117</td>
                                            <td>SIN NOMBRE 3</td>
                                            <td><a href="mailto:primaria117@neuquen.gov.ar"> primaria117@neuquen.gov.ar </a></td>
                                            <td>LAGO MELIQUINA</td>
                                            <td>SUR</td>
                                            <td>2972422647</td>
                                            <td><a href="./mapas.php?id=580017200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 10</td>
                                            <td>RODRIGUEZ LEOPOLDO INTD</td>
                                            <td><a href="mailto:epa010@neuquen.gov.ar"> epa010@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972412836</td>
                                            <td><a href="./mapas.php?id=580017300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 10 ANEXOS</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:epa10@neuquen.gov.ar"> epa10@neuquen.gov.ar </a></td>
                                            <td>TROMPUL (RAI)</td>
                                            <td>SUR</td>
                                            <td>2972412836</td>
                                            <td><a href="./mapas.php?id=580017301"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA AUXILIARES TÉCNICOS DE LA MEDICINA</td>
                                            <td>LAINEZ MANUEL 102</td>
                                            <td><a href="mailto:eatm@neuquen.gov.ar"> eatm@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422757</td>
                                            <td><a href="./mapas.php?id=580017900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 158 PROVINCIA DE CATAMARCA</td>
                                            <td>SARMIENTO DOMINGO F 401</td>
                                            <td><a href="mailto:primaria158@neuquen.gov.ar"> primaria158@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435802</td>
                                            <td><a href="./mapas.php?id=580018000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PABLO VI</td>
                                            <td>LAS FLORES AV 1901</td>
                                            <td><a href="mailto:direccion@pablovineuquen.edu.ar"> direccion@pablovineuquen.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994331411</td>
                                            <td><a href="./mapas.php?id=580018100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 180 PERITO PASCACIO MORENO</td>
                                            <td>RICCHIERI PABLO 1095</td>
                                            <td><a href="mailto:primaria180@neuquen.gov.ar"> primaria180@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994400709</td>
                                            <td><a href="./mapas.php?id=580018200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 41</td>
                                            <td>LINARES INTD 760</td>
                                            <td><a href="mailto:cpem041@neuquen.gov.ar"> cpem041@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994401509</td>
                                            <td><a href="./mapas.php?id=580018400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 67 CONTRAALMIRANTE MARTÍN GUERRICO</td>
                                            <td>DE AGUADO 1545</td>
                                            <td><a href="mailto:primaria067@neuquen.gov.ar"> primaria067@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435849</td>
                                            <td><a href="./mapas.php?id=580018500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CRISTIANA EVANGÉLICA DE NEUQUEN E.C.E.N. N.PRIMARIO</td>
                                            <td>RICCHIERI PABLO TTE 1334</td>
                                            <td><a href="mailto:administracion@fecen.edu.ar"> administracion@fecen.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155394930</td>
                                            <td><a href="./mapas.php?id=580018600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 70 ALBERGUE DIRECTOR HÉCTOR ALBERTO JOFRÉ</td>
                                            <td>RUTA PROVINCIAL 4</td>
                                            <td><a href="mailto:primaria070@neuquen.gov.ar"> primaria070@neuquen.gov.ar </a></td>
                                            <td>NAUNAUCO</td>
                                            <td>NORTE</td>
                                            <td>2948496301</td>
                                            <td><a href="./mapas.php?id=580018800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 68 CACIQUE FRANCISCO HUAYQUILLAN</td>
                                            <td>RUTA PROVINCIAL 4</td>
                                            <td><a href="mailto:primaria068@neuquen.gov.ar"> primaria068@neuquen.gov.ar </a></td>
                                            <td>COLIPILLI</td>
                                            <td>NORTE</td>
                                            <td>2948491056</td>
                                            <td><a href="./mapas.php?id=580018900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 31 EJÉRCITO DE LOS ANDES</td>
                                            <td>RUTA PROVINCIAL 6</td>
                                            <td><a href="mailto:primaria031@neuquen.gov.ar"> primaria031@neuquen.gov.ar </a></td>
                                            <td>EL CHOLAR</td>
                                            <td>NORTE</td>
                                            <td>2948492985</td>
                                            <td><a href="./mapas.php?id=580019000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 28 PROF.PRÓSPERO ALEMANDRI</td>
                                            <td>SAPAG FELIPE GDOR AV</td>
                                            <td><a href="mailto:primaria028@neuquen.gov.ar"> primaria028@neuquen.gov.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2948494065</td>
                                            <td><a href="./mapas.php?id=580019100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 46</td>
                                            <td>MAESTROS NEUQUINOS 1055</td>
                                            <td><a href="mailto:cpem046@neuquen.gov.ar"> cpem046@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994470377</td>
                                            <td><a href="./mapas.php?id=580019200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 232 MANUEL BELGRANO</td>
                                            <td>ALCORTA MTRO 1125</td>
                                            <td><a href="mailto:primaria232@neuquen.gov.ar"> primaria232@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994425642</td>
                                            <td><a href="./mapas.php?id=580019300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 61 NICOLÁS AVELLANEDA</td>
                                            <td>MISIONES 397</td>
                                            <td><a href="mailto:primaria061@neuquen.gov.ar"> primaria061@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422920</td>
                                            <td><a href="./mapas.php?id=580019400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 15</td>
                                            <td>CARRASCO CAMILO</td>
                                            <td><a href="mailto:cpem015@neuquen.gov.ar"> cpem015@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994920531</td>
                                            <td><a href="./mapas.php?id=580019500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 240 INTEGRACIÓN LATINOAMERICANA</td>
                                            <td>ALBERDI JUAN BAUTISTA 527</td>
                                            <td><a href="mailto:primaria240@neuquen.gov.ar"> primaria240@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994936825</td>
                                            <td><a href="./mapas.php?id=580019600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 192 19 DE JUNIO</td>
                                            <td>ZABALETA M AV 618</td>
                                            <td><a href="mailto:primaria192@neuquen.gov.ar"> primaria192@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994936258</td>
                                            <td><a href="./mapas.php?id=580019700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PRIMARIO PRIVADO POSTA CRISTO REY</td>
                                            <td>PERON J D AV 6480</td>
                                            <td><a href="mailto:postacristoreynp@neuquen.gov.ar"> postacristoreynp@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2995660866</td>
                                            <td><a href="./mapas.php?id=580019800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO SECUNDARIO JEAN PIAGET</td>
                                            <td>FAIMALLA 2700</td>
                                            <td><a href="mailto:secretaria@jeanpiagetnqn.edu.ar"> secretaria@jeanpiagetnqn.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994400022</td>
                                            <td><a href="./mapas.php?id=580019900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 17 MARCELO BERBEL</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria017@neuquen.gov.ar"> primaria017@neuquen.gov.ar </a></td>
                                            <td>TAQUIMILAN CENTRO</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1133</td>
                                            <td><a href="./mapas.php?id=580020200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 11</td>
                                            <td>SAPAG FELIPE GDOR AV 555</td>
                                            <td><a href="mailto:cpem011@neuquen.gov.ar"> cpem011@neuquen.gov.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2948494045</td>
                                            <td><a href="./mapas.php?id=580020400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 262 ALBERGUE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria262@neuquen.gov.ar"> primaria262@neuquen.gov.ar </a></td>
                                            <td>GUANACOS</td>
                                            <td>NORTE</td>
                                            <td>2948494092 </td>
                                            <td><a href="./mapas.php?id=580020600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 154</td>
                                            <td>CALLE 4</td>
                                            <td><a href="mailto:primaria154@neuquen.gov.ar"> primaria154@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994413035</td>
                                            <td><a href="./mapas.php?id=580020800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 17 ANTU LIHUE</td>
                                            <td>CALLE 4</td>
                                            <td><a href="mailto:jardin017@neuquen.gov.ar"> jardin017@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994413047</td>
                                            <td><a href="./mapas.php?id=580020900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 183</td>
                                            <td>MAESTROS NEUQUINOS 1060</td>
                                            <td><a href="mailto:primaria183@neuquen.gov.ar"> primaria183@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994429160</td>
                                            <td><a href="./mapas.php?id=580021000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 12 GRAL JOSE DE SAN MARTÍN</td>
                                            <td>ANAYA GDOR 235</td>
                                            <td><a href="mailto:ifd012@neuquen.gov.ar"> ifd012@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994487640</td>
                                            <td><a href="./mapas.php?id=580021100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 29 PICHE PIUQUE</td>
                                            <td>LAGO TRAFUL AV</td>
                                            <td><a href="mailto:jardin029@neuquen.gov.ar"> jardin029@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994890495</td>
                                            <td><a href="./mapas.php?id=580021200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 22 IRUM ANTU</td>
                                            <td>STORNI ALFONSINA</td>
                                            <td><a href="mailto:jardin022@neuquen.gov.ar"> jardin022@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994890797</td>
                                            <td><a href="./mapas.php?id=580021300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES MATERNAL SOEMITOS</td>
                                            <td>SANTO DOMINGO</td>
                                            <td><a href="mailto:jardinsoemitos16@outlook.com"> jardinsoemitos16@outlook.com </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994892512</td>
                                            <td><a href="./mapas.php?id=580021400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 13</td>
                                            <td>ECUADOR</td>
                                            <td><a href="mailto:primaria013@neuquen.gov.ar"> primaria013@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891596</td>
                                            <td><a href="./mapas.php?id=580021500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 109 REPÚBLICA DE VENEZUELA</td>
                                            <td>ISLAS MALVINAS 19</td>
                                            <td><a href="mailto:primaria109@neuquen.gov.ar"> primaria109@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891536</td>
                                            <td><a href="./mapas.php?id=580021600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 305</td>
                                            <td>MEXICO 1660</td>
                                            <td><a href="mailto:primaria305@neuquen.gov.ar"> primaria305@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994890518</td>
                                            <td><a href="./mapas.php?id=580021900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 196</td>
                                            <td>KILKA 3402</td>
                                            <td><a href="mailto:primaria196@neuquen.gov.ar"> primaria196@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461496</td>
                                            <td><a href="./mapas.php?id=580022100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 86 BATALLA DE MAIPÚ</td>
                                            <td>RUTA NACIONAL 40 KM 2220,42</td>
                                            <td><a href="mailto:primaria086@neuquen.gov.ar"> primaria086@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426188</td>
                                            <td><a href="./mapas.php?id=580022500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO F.A.S.T.A. MIGUEL A.TOBARES N.PRIMARIO</td>
                                            <td>RUTA NACIONAL 40 KM 2117</td>
                                            <td><a href="mailto:secprimaria@fastatobares.edu.ar"> secprimaria@fastatobares.edu.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426394</td>
                                            <td><a href="./mapas.php?id=580022600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 89</td>
                                            <td>RODRIGUEZ LEOPOLDO INTD</td>
                                            <td><a href="mailto:primaria089@neuquen.gov.ar"> primaria089@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972427050</td>
                                            <td><a href="./mapas.php?id=580022800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO SAN PABLO APÓSTOL</td>
                                            <td>DE GINGINS CJON 285</td>
                                            <td><a href="mailto:primaria@sanpablo.edu.ar"> primaria@sanpablo.edu.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426204</td>
                                            <td><a href="./mapas.php?id=580023000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 57</td>
                                            <td>LOS PINOS 345</td>
                                            <td><a href="mailto:cpem057@neuquen.gov.ar"> cpem057@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972424860</td>
                                            <td><a href="./mapas.php?id=580023100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 8</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:especial008@neuquen.gov.ar"> especial008@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426891</td>
                                            <td><a href="./mapas.php?id=580023200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 24 FRANCISCO ROSSI</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:jardin024@neuquen.gov.ar"> jardin024@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972429433</td>
                                            <td><a href="./mapas.php?id=580023300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 142 JUAN GALO DE LAVALLE</td>
                                            <td>ELORRIAGA DAMIAN</td>
                                            <td><a href="mailto:primaria142@neuquen.gov.ar"> primaria142@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426326</td>
                                            <td><a href="./mapas.php?id=580023400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 146 KIMTUIN KOM PEÑI HUEN</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria146@neuquen.gov.ar"> primaria146@neuquen.gov.ar </a></td>
                                            <td>TROMPUL (RAI)</td>
                                            <td>SUR</td>
                                            <td>2972424984</td>
                                            <td><a href="./mapas.php?id=580023600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 49</td>
                                            <td>BUSTOS PEREZ JOSE 710</td>
                                            <td><a href="mailto:cpem049@neuquen.gov.ar"> cpem049@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440640</td>
                                            <td><a href="./mapas.php?id=580023800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ADVENTISTA JUAN BAUTISTA ALBERDI</td>
                                            <td>ISLAS MALVINAS 853</td>
                                            <td><a href="mailto:primaria.neuquen@educacionadventista.org.ar"> primaria.neuquen@educacionadventista.org.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422771</td>
                                            <td><a href="./mapas.php?id=580024100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 19</td>
                                            <td>BORLENGHI CNL 450</td>
                                            <td><a href="mailto:cpem019@neuquen.gov.ar"> cpem019@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422924</td>
                                            <td><a href="./mapas.php?id=580024200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>SAN AGUSTÍN INTERNATIONAL SCHOOL</td>
                                            <td>RIO DESAGUADERO 698</td>
                                            <td><a href="mailto:secretaria@sanagustinschool.edu.ar"> secretaria@sanagustinschool.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994480629</td>
                                            <td><a href="./mapas.php?id=580024300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 124 CELESTINO ELIZARI</td>
                                            <td>EX RUTA 234</td>
                                            <td><a href="mailto:primaria124@neuquen.gov.ar"> primaria124@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994898731</td>
                                            <td><a href="./mapas.php?id=580024400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 105 FRANCISCO HUMBERTO RODRÍGUEZ</td>
                                            <td>BOLIVAR SIMON AV 950</td>
                                            <td><a href="mailto:primaria105@neuquen.gov.ar"> primaria105@neuquen.gov.ar </a></td>
                                            <td>VISTA ALEGRE NORTE</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891972</td>
                                            <td><a href="./mapas.php?id=580024500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO COMUNITARIO RURAL EVANGÉLICO ANDACOLLO</td>
                                            <td>BONGARRA JOSE</td>
                                            <td><a href="mailto:pazcaro@hotmail.com.ar"> pazcaro@hotmail.com.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2942494042</td>
                                            <td><a href="./mapas.php?id=580024600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 44</td>
                                            <td>CALLE 11</td>
                                            <td><a href="mailto:cpem044@neuquen.gov.ar"> cpem044@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994413770</td>
                                            <td><a href="./mapas.php?id=580024700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 175</td>
                                            <td>INDUSTRIALES NEUQUINOS</td>
                                            <td><a href="mailto:primaria175@neuquen.gov.ar"> primaria175@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994413619</td>
                                            <td><a href="./mapas.php?id=580024800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO CONFLUENCIA</td>
                                            <td>LELOIR 210</td>
                                            <td><a href="mailto:secretaria@colegioconfluencia.edu.ar"> secretaria@colegioconfluencia.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994427027</td>
                                            <td><a href="./mapas.php?id=580025000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 60</td>
                                            <td>COLON CRISTOBAL 775</td>
                                            <td><a href="mailto:cpem060@neuquen.gov.ar"> cpem060@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994426398</td>
                                            <td><a href="./mapas.php?id=580025100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 1 GRAL. SAN MARTÍN</td>
                                            <td>BELGRANO MANUEL GRL AV 1000</td>
                                            <td><a href="mailto:cpem001@neuquen.gov.ar"> cpem001@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891117</td>
                                            <td><a href="./mapas.php?id=580025200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 50</td>
                                            <td>ESTADOS UNIDOS 248</td>
                                            <td><a href="mailto:cpem050@neuquen.gov.ar"> cpem050@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994892856</td>
                                            <td><a href="./mapas.php?id=580025300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 277 POLICÍA FEDERAL ARGENTINA</td>
                                            <td>REPUBLICA ARGENTINA</td>
                                            <td><a href="mailto:primaria277@neuquen.gov.ar"> primaria277@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891590</td>
                                            <td><a href="./mapas.php?id=580025400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 239</td>
                                            <td>HONDURAS 1100</td>
                                            <td><a href="mailto:primaria239@neuquen.gov.ar"> primaria239@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994898030</td>
                                            <td><a href="./mapas.php?id=580025500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 229 CONGRESISTAS DE TUCUMÁN</td>
                                            <td>9 DE JULIO 179</td>
                                            <td><a href="mailto:primaria229@neuquen.gov.ar"> primaria229@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994898027</td>
                                            <td><a href="./mapas.php?id=580025600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO SECUNDARIO VIRGEN DE LUJÁN</td>
                                            <td>REPUBLICA DE CHILE 520</td>
                                            <td><a href="mailto:virgendelujan2@yahoo.com.ar"> virgendelujan2@yahoo.com.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891798</td>
                                            <td><a href="./mapas.php?id=580025700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 181 1 DE MAYO</td>
                                            <td>VARVARCO 850</td>
                                            <td><a href="mailto:primaria181@neuquen.gov.ar"> primaria181@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461627</td>
                                            <td><a href="./mapas.php?id=580025800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 27 PEUMAYEN</td>
                                            <td>AGUILA JORGE SOLDADO 4595</td>
                                            <td><a href="mailto:jardin027@neuquen.gov.ar"> jardin027@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440635</td>
                                            <td><a href="./mapas.php?id=580025900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 198</td>
                                            <td>MASCARDI PADRE 1580</td>
                                            <td><a href="mailto:primaria198@neuquen.gov.ar"> primaria198@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994425697</td>
                                            <td><a href="./mapas.php?id=580026000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 267</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria267@neuquen.gov.ar"> primaria267@neuquen.gov.ar </a></td>
                                            <td>ARROYITO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994902019</td>
                                            <td><a href="./mapas.php?id=580026100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 13</td>
                                            <td>MORENO PERITO 829</td>
                                            <td><a href="mailto:cpem013@neuquen.gov.ar"> cpem013@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972427387</td>
                                            <td><a href="./mapas.php?id=580026200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 12 ING. JUAN CARLOS FONTANIVE</td>
                                            <td>ROCA RUDECINDO 940</td>
                                            <td><a href="mailto:epet012@neuquen.gov.ar"> epet012@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972428433</td>
                                            <td><a href="./mapas.php?id=580026300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO F.A.S.T.A. MIGUEL A.TOBARES</td>
                                            <td>RUTA NACIONAL 40 KM 2117</td>
                                            <td><a href="mailto:secnivelmedio@fastatobares.edu.ar"> secnivelmedio@fastatobares.edu.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426394</td>
                                            <td><a href="./mapas.php?id=580026400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 274 PADRE ENRIQUE OLIVARES</td>
                                            <td>OBEID GABRIEL</td>
                                            <td><a href="mailto:primaria274@neuquen.gov.ar"> primaria274@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972427575</td>
                                            <td><a href="./mapas.php?id=580026500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 188</td>
                                            <td>LOS PEHUENES 345</td>
                                            <td><a href="mailto:primaria188@neuquen.gov.ar"> primaria188@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972425076</td>
                                            <td><a href="./mapas.php?id=580026600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 179</td>
                                            <td>ROCA RUDECINDO</td>
                                            <td><a href="mailto:primaria179@neuquen.gov.ar"> primaria179@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972428189</td>
                                            <td><a href="./mapas.php?id=580026700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 5 BERNARDINO RIVADAVIA</td>
                                            <td>SARMIENTO DOMINGO F 750</td>
                                            <td><a href="mailto:primaria005@neuquen.gov.ar"> primaria005@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972427383</td>
                                            <td><a href="./mapas.php?id=580026800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 42</td>
                                            <td>SAN IGNACIO 4010</td>
                                            <td><a href="mailto:cpem042@neuquen.gov.ar"> cpem042@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440623</td>
                                            <td><a href="./mapas.php?id=580026900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO SANTA TERESA DE JESÚS NIVEL MEDIO</td>
                                            <td>CARMEN DE PATAGONES 450</td>
                                            <td><a href="mailto:teresianonqn@gmail.com"> teresianonqn@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423562</td>
                                            <td><a href="./mapas.php?id=580027000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>A.M.E.N. COLEGIO BAUTISTA NIVEL MEDIO</td>
                                            <td>AMANCAY 1075</td>
                                            <td><a href="mailto:secretariasecundario@amen.org.ar"> secretariasecundario@amen.org.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994434504</td>
                                            <td><a href="./mapas.php?id=580027100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA A.M.S.E. JEAN PIAGET</td>
                                            <td>ISLAS MALVINAS 1095</td>
                                            <td><a href="mailto:direccion.primaria@jeanpiagetnqn.edu.ar"> direccion.primaria@jeanpiagetnqn.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994432375</td>
                                            <td><a href="./mapas.php?id=580027200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 28</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:cpem028@neuquen.gov.ar"> cpem028@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426344</td>
                                            <td><a href="./mapas.php?id=580027300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 6 NIVEL INICIAL Y PRIMARIO</td>
                                            <td>AMANCAY 620</td>
                                            <td><a href="mailto:ifd006@neuquen.gov.ar"> ifd006@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422388</td>
                                            <td><a href="./mapas.php?id=580027400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 235 ARMADA ARGENTINA</td>
                                            <td>SUAREZ CNL 1875</td>
                                            <td><a href="mailto:primaria235@neuquen.gov.ar"> primaria235@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422992</td>
                                            <td><a href="./mapas.php?id=580027500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 28 CIUDADANO PATÁGONICO</td>
                                            <td>BORLENGHI CNL 451</td>
                                            <td><a href="mailto:jardin028@neuquen.gov.ar"> jardin028@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994436683</td>
                                            <td><a href="./mapas.php?id=580027600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 2</td>
                                            <td>BRASIL</td>
                                            <td><a href="mailto:epet002@neuquen.gov.ar"> epet002@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891622</td>
                                            <td><a href="./mapas.php?id=580027800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 33</td>
                                            <td>ALVAREZ GREGORIO DR 51</td>
                                            <td><a href="mailto:cpem033@neuquen.gov.ar"> cpem033@neuquen.gov.ar </a></td>
                                            <td>VISTA ALEGRE SUR</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994898952</td>
                                            <td><a href="./mapas.php?id=580027900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 166 TOMÁS CASULLO</td>
                                            <td>MESCHINI ERNESTO ING 210</td>
                                            <td><a href="mailto:primaria166@neuquen.gov.ar"> primaria166@neuquen.gov.ar </a></td>
                                            <td>VISTA ALEGRE SUR</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891405</td>
                                            <td><a href="./mapas.php?id=580028000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 202</td>
                                            <td>CENTENO MARIO 3455</td>
                                            <td><a href="mailto:primaria202@neuquen.gov.ar"> primaria202@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460794</td>
                                            <td><a href="./mapas.php?id=580028100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 9</td>
                                            <td>BUSTOS PEREZ JOSE 750</td>
                                            <td><a href="mailto:epa009@neuquen.gov.ar"> epa009@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440627</td>
                                            <td><a href="./mapas.php?id=580028200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 25 NEPEN</td>
                                            <td>CALLE 5</td>
                                            <td><a href="mailto:jardin025@neuquen.gov.ar"> jardin025@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460692</td>
                                            <td><a href="./mapas.php?id=580028400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 298</td>
                                            <td>RECONQUISTA 1498</td>
                                            <td><a href="mailto:primaria298@neuquen.gov.ar"> primaria298@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994464548</td>
                                            <td><a href="./mapas.php?id=580028500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 206</td>
                                            <td>DOMUYO AV</td>
                                            <td><a href="mailto:primaria206@neuquen.gov.ar"> primaria206@neuquen.gov.ar </a></td>
                                            <td>VARVARCO</td>
                                            <td>NORTE</td>
                                            <td>299154554491</td>
                                            <td><a href="./mapas.php?id=580028800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 35</td>
                                            <td>OLASCOAGA</td>
                                            <td><a href="mailto:cpem035@neuquen.gov.ar"> cpem035@neuquen.gov.ar </a></td>
                                            <td>BUTA RANQUIL</td>
                                            <td>NORTE</td>
                                            <td>2948493177</td>
                                            <td><a href="./mapas.php?id=580029500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 211 GENDARME ARGENTINO</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria211@neuquen.gov.ar"> primaria211@neuquen.gov.ar </a></td>
                                            <td>RANQUIL VEGA</td>
                                            <td>ANELO</td>
                                            <td>2994495200 INT 1140</td>
                                            <td><a href="./mapas.php?id=580029700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 173 ALBERGUE RUCA QUIMPEN</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria173@neuquen.gov.ar"> primaria173@neuquen.gov.ar </a></td>
                                            <td>SIERRA DE HUANTRAICO</td>
                                            <td>ANELO</td>
                                            <td>2994495200 INT 1143</td>
                                            <td><a href="./mapas.php?id=580029800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 127 ALBERGUE</td>
                                            <td>EX RUTA NACIONAL 40</td>
                                            <td><a href="mailto:primaria127@neuquen.gov.ar"> primaria127@neuquen.gov.ar </a></td>
                                            <td>AGUADA CHACAYCO</td>
                                            <td>ANELO</td>
                                            <td>2942346784</td>
                                            <td><a href="./mapas.php?id=580029900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 95 PROVINCIA DE SAN LUIS</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria095@neuquen.gov.ar"> primaria095@neuquen.gov.ar </a></td>
                                            <td>BUTA RANQUIL</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1163</td>
                                            <td><a href="./mapas.php?id=580030000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 32 LEOPOLDO GENARO CARREÑO</td>
                                            <td>BELGRANO MANUEL GRL</td>
                                            <td><a href="mailto:primaria032@neuquen.gov.ar"> primaria032@neuquen.gov.ar </a></td>
                                            <td>BARRANCAS</td>
                                            <td>ANELO</td>
                                            <td>2948482006</td>
                                            <td><a href="./mapas.php?id=580030200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 329 CELESTINO CABRAL</td>
                                            <td>CATALA SALVADOR</td>
                                            <td><a href="mailto:primaria329@neuquen.gov.ar"> primaria329@neuquen.gov.ar </a></td>
                                            <td>BUTA RANQUIL</td>
                                            <td>NORTE</td>
                                            <td>2948493082</td>
                                            <td><a href="./mapas.php?id=580030300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 2 DPTO DE APLICACIÓN</td>
                                            <td>TUCUMAN</td>
                                            <td><a href="mailto:smmarcela169@gmail.com"> smmarcela169@gmail.com </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421199</td>
                                            <td><a href="./mapas.php?id=580030400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 4</td>
                                            <td>NEWBERY JORGE</td>
                                            <td><a href="mailto:epa004@neuquen.gov.ar"> epa004@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2942421026</td>
                                            <td><a href="./mapas.php?id=580030500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 4 ANEXO BARRANCAS</td>
                                            <td>LAS HERAS</td>
                                            <td><a href="mailto:epa004barrancas@neuquen.gov.ar"> epa004barrancas@neuquen.gov.ar </a></td>
                                            <td>BARRANCAS</td>
                                            <td>ANELO</td>
                                            <td>2948421026</td>
                                            <td><a href="./mapas.php?id=580030503"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 4 ANEXO NAUNAUCO</td>
                                            <td>RUTA PROVINCIAL 4</td>
                                            <td><a href="mailto:epachml2017@gmail.com"> epachml2017@gmail.com </a></td>
                                            <td>NAUNAUCO</td>
                                            <td>NORTE</td>
                                            <td>2948421026</td>
                                            <td><a href="./mapas.php?id=580030506"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 4 ANEXO COLIPILLI</td>
                                            <td>RUTA PROVINCIAL 4</td>
                                            <td><a href="mailto:epa004@neuquen.gov.ar"> epa004@neuquen.gov.ar </a></td>
                                            <td>COLIPILLI</td>
                                            <td>NORTE</td>
                                            <td>2948421026</td>
                                            <td><a href="./mapas.php?id=580030507"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 4 ANEXO CHORRIACA</td>
                                            <td>PICHAIHUE</td>
                                            <td><a href="mailto:epachml@gmail.com"> epachml@gmail.com </a></td>
                                            <td>CHORRIACA</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580030508"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 4 ANEXO LAGUNA AUQUINCO</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:epachml2017@gmail.com"> epachml2017@gmail.com </a></td>
                                            <td>LAGUNA AUQUINCO</td>
                                            <td>ANELO</td>
                                            <td>2948421026</td>
                                            <td><a href="./mapas.php?id=580030509"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 7 PARA CIEGOS Y DISMINUÍDOS VISUALES</td>
                                            <td>ANAYA GDOR 205</td>
                                            <td><a href="mailto:ee07@neuquen.gov.ar"> ee07@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994430230</td>
                                            <td><a href="./mapas.php?id=580030800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 182 DON JAIME</td>
                                            <td>DOMENE JOSE 255</td>
                                            <td><a href="mailto:primaria182@neuquen.gov.ar"> primaria182@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435292</td>
                                            <td><a href="./mapas.php?id=580030900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 6</td>
                                            <td>STORNI ALFONSINA 1141</td>
                                            <td><a href="mailto:epet006@neuquen.gov.ar"> epet006@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435688</td>
                                            <td><a href="./mapas.php?id=580031100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 260 CIUDAD DE NEUQUEN</td>
                                            <td>LINCOLN ABRAHAM 851</td>
                                            <td><a href="mailto:primaria260@neuquen.gov.ar"> primaria260@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994432092</td>
                                            <td><a href="./mapas.php?id=580031300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 90 RAÚL DÍAZ</td>
                                            <td>RUTA PROVINCIAL 13</td>
                                            <td><a href="mailto:primaria090@neuquen.gov.ar"> primaria090@neuquen.gov.ar </a></td>
                                            <td>LA ANGOSTURA DE ICALMA</td>
                                            <td>SUR</td>
                                            <td>299154389600</td>
                                            <td><a href="./mapas.php?id=580031500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 42</td>
                                            <td>RUTA PROVINCIAL 21</td>
                                            <td><a href="mailto:primaria042@neuquen.gov.ar"> primaria042@neuquen.gov.ar </a></td>
                                            <td>CAMPANA MAHUIDA</td>
                                            <td>NORTE</td>
                                            <td>2948498079</td>
                                            <td><a href="./mapas.php?id=580031700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 10</td>
                                            <td>25 DE MAYO</td>
                                            <td><a href="mailto:cpem010@neuquen.gov.ar"> cpem010@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>2948498023</td>
                                            <td><a href="./mapas.php?id=580031800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 333 RAMÓN N.CARRIZO BAGNATTI</td>
                                            <td>RUTA PROVINCIAL 21</td>
                                            <td><a href="mailto:primaria333@neuquen.gov.ar"> primaria333@neuquen.gov.ar </a></td>
                                            <td>HUARENCHENQUE</td>
                                            <td>NORTE</td>
                                            <td>2942421159</td>
                                            <td><a href="./mapas.php?id=580031900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 330 JULIA SÍVORI DE PÉREZ</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria330@neuquen.gov.ar"> primaria330@neuquen.gov.ar </a></td>
                                            <td>TRAHUNCURA</td>
                                            <td>NORTE</td>
                                            <td>2942421159</td>
                                            <td><a href="./mapas.php?id=580032000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 35</td>
                                            <td>RUTA PROVINCIAL 33</td>
                                            <td><a href="mailto:primaria035@neuquen.gov.ar"> primaria035@neuquen.gov.ar </a></td>
                                            <td>CAJON DE ALMAZA</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1145</td>
                                            <td><a href="./mapas.php?id=580032100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 208</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria208@neuquen.gov.ar"> primaria208@neuquen.gov.ar </a></td>
                                            <td>MALLIN DEL TORO</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1169</td>
                                            <td><a href="./mapas.php?id=580032200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 12</td>
                                            <td>CAMPANA MAHUIDA</td>
                                            <td><a href="mailto:especial012@neuquen.gov.ar"> especial012@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>299154210191</td>
                                            <td><a href="./mapas.php?id=580032300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 110</td>
                                            <td>RUTA PROVINCIAL 32</td>
                                            <td><a href="mailto:primaria110@neuquen.gov.ar"> primaria110@neuquen.gov.ar </a></td>
                                            <td>PICHAIHUE</td>
                                            <td>NORTE</td>
                                            <td>2948496000</td>
                                            <td><a href="./mapas.php?id=580032400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 212 ALBERGUE</td>
                                            <td>RUTA PROVINCIAL 23</td>
                                            <td><a href="mailto:primaria212@neuquen.gov.ar"> primaria212@neuquen.gov.ar </a></td>
                                            <td>LONCO LUAN</td>
                                            <td>SUR</td>
                                            <td>2942469317</td>
                                            <td><a href="./mapas.php?id=580032700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 59</td>
                                            <td>GUILLEN NICOLAS</td>
                                            <td><a href="mailto:primaria059@neuquen.gov.ar"> primaria059@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994894919</td>
                                            <td><a href="./mapas.php?id=580033300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 165</td>
                                            <td>PIONEROS PATAGONICOS 623</td>
                                            <td><a href="mailto:primaria165@neuquen.gov.ar"> primaria165@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2942496166</td>
                                            <td><a href="./mapas.php?id=580033400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO COMUNITARIO RURAL EVANGÉLICO ALUMINE</td>
                                            <td>RUTA PROVINCIAL 13 KM 3</td>
                                            <td><a href="mailto:marypeletay08@hotmail.com"> marypeletay08@hotmail.com </a></td>
                                            <td>VILLA PEHUENIA</td>
                                            <td>SUR</td>
                                            <td>294215681190</td>
                                            <td><a href="./mapas.php?id=580033500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO EDUCATIVO ESPECIAL INTEGRADOR DEL SOL</td>
                                            <td>LUCERO LUCAS 5240</td>
                                            <td><a href="mailto:ceeidelsol@yahoo.com.ar"> ceeidelsol@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299156720740</td>
                                            <td><a href="./mapas.php?id=580033800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 78</td>
                                            <td>RUTA PROVINCIAL 29</td>
                                            <td><a href="mailto:primaria078@neuquen.gov.ar"> primaria078@neuquen.gov.ar </a></td>
                                            <td>TRAILATHUE</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1135</td>
                                            <td><a href="./mapas.php?id=580034000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 245</td>
                                            <td>BUSTOS PEREZ JOSE 750</td>
                                            <td><a href="mailto:primaria245@neuquen.gov.ar"> primaria245@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440627</td>
                                            <td><a href="./mapas.php?id=580034100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 296</td>
                                            <td>RODHE CNL 205</td>
                                            <td><a href="mailto:primaria296@neuquen.gov.ar"> primaria296@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994466407</td>
                                            <td><a href="./mapas.php?id=580034200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 101 PAULA ALBARRACÍN DE SARMIENTO</td>
                                            <td>PLANAS TEODORO 5615</td>
                                            <td><a href="mailto:primaria101@neuquen.gov.ar"> primaria101@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440633</td>
                                            <td><a href="./mapas.php?id=580034300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 280</td>
                                            <td>BELGRANO MANUEL GRL 4575</td>
                                            <td><a href="mailto:primaria280@neuquen.gov.ar"> primaria280@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461459</td>
                                            <td><a href="./mapas.php?id=580034400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 5</td>
                                            <td>BELGRANO MANUEL GRL 4340</td>
                                            <td><a href="mailto:epet005@neuquen.gov.ar"> epet005@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994464186</td>
                                            <td><a href="./mapas.php?id=580034500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 178 DR GREGORIO ÁLVAREZ</td>
                                            <td>CALLE 18</td>
                                            <td><a href="mailto:primaria178@neuquen.gov.ar"> primaria178@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461458</td>
                                            <td><a href="./mapas.php?id=580034600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 47</td>
                                            <td>ORTEGA RUFINO 575</td>
                                            <td><a href="mailto:cpem047@neuquen.gov.ar"> cpem047@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994465330</td>
                                            <td><a href="./mapas.php?id=580034700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA AGROPECUARIA 1</td>
                                            <td>RUTA PROVINCIAL 43</td>
                                            <td><a href="mailto:epea001@neuquen.gov.ar"> epea001@neuquen.gov.ar </a></td>
                                            <td>LAS OVEJAS</td>
                                            <td>NORTE</td>
                                            <td>2948481104</td>
                                            <td><a href="./mapas.php?id=580034800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 30 JUSTO JOSÉ DE URQUIZA</td>
                                            <td>VERA CLEOMEDES</td>
                                            <td><a href="mailto:primaria030@neuquen.gov.ar"> primaria030@neuquen.gov.ar </a></td>
                                            <td>LAS OVEJAS</td>
                                            <td>NORTE</td>
                                            <td>2948481066</td>
                                            <td><a href="./mapas.php?id=580035000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 254 ANTÁRTIDA ARGENTINA</td>
                                            <td>LAMADRID</td>
                                            <td><a href="mailto:primaria254@neuquen.gov.ar"> primaria254@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421451</td>
                                            <td><a href="./mapas.php?id=580035200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 327 PADRE DOMINGO MILANESIO</td>
                                            <td>LAMADRID GRL 30</td>
                                            <td><a href="mailto:primaria327@neuquen.gov.ar"> primaria327@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421443</td>
                                            <td><a href="./mapas.php?id=580035300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 11 EL PORTAL</td>
                                            <td>JUSTO GRL 850</td>
                                            <td><a href="mailto:especial011@neuquen.gov.ar"> especial011@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421509</td>
                                            <td><a href="./mapas.php?id=580035400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 131</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:primaria131@neuquen.gov.ar"> primaria131@neuquen.gov.ar </a></td>
                                            <td>BUTACO</td>
                                            <td>ANELO</td>
                                            <td>2948496600 </td>
                                            <td><a href="./mapas.php?id=580035500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 2 CONRADO VILLEGAS</td>
                                            <td>PCIA DE SAN JUAN AV 50</td>
                                            <td><a href="mailto:primaria002@neuquen.gov.ar"> primaria002@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994424322</td>
                                            <td><a href="./mapas.php?id=580035900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 3 MARÍA TERESA JABAT DE BIANCHI</td>
                                            <td>CORDOBA 315</td>
                                            <td><a href="mailto:eespecial3@gmail.com"> eespecial3@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994424150</td>
                                            <td><a href="./mapas.php?id=580036000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>I.S.I COLLEGE</td>
                                            <td>BELGRANO MANUEL GRL 516</td>
                                            <td><a href="mailto:secretaria@isicollege.edu.ar"> secretaria@isicollege.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994484812</td>
                                            <td><a href="./mapas.php?id=580036100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 62</td>
                                            <td>PCIA DE SAN JUAN AV 50</td>
                                            <td><a href="mailto:cpem062@neuquen.gov.ar"> cpem062@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994424322</td>
                                            <td><a href="./mapas.php?id=580036200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE TÍTERES ALICIA MURPHY</td>
                                            <td>ANAYA GDOR 375</td>
                                            <td><a href="mailto:escueladetiteres@neuquen.gov.ar"> escueladetiteres@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423481</td>
                                            <td><a href="./mapas.php?id=580036300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 34</td>
                                            <td>DOMENE JOSE 345</td>
                                            <td><a href="mailto:cpem034@neuquen.gov.ar"> cpem034@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994436198</td>
                                            <td><a href="./mapas.php?id=580036600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO TECNOLÓGICO DEL COMAHUE (ITC)</td>
                                            <td>OLASCOAGA MANUEL AV 547</td>
                                            <td><a href="mailto:mutualcolegio@itc.edu.ar"> mutualcolegio@itc.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994426560</td>
                                            <td><a href="./mapas.php?id=580036700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 20 INSPECTOR DANIEL EXEQUIEL GATICA</td>
                                            <td>RUIVAL PSJE 1400</td>
                                            <td><a href="mailto:primaria020@neuquen.gov.ar"> primaria020@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423941</td>
                                            <td><a href="./mapas.php?id=580036800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 82 TERRITORIO NAC TIERRA DEL FUEGO ANTÁRTI</td>
                                            <td>OLASCOAGA MANUEL AV 1285</td>
                                            <td><a href="mailto:primaria082@neuquen.gov.ar"> primaria082@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994431272</td>
                                            <td><a href="./mapas.php?id=580036900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 50 DON JAIME FRANCISCO DE NEVARES</td>
                                            <td>RIO AGRIO AV</td>
                                            <td><a href="mailto:primaria050@neuquen.gov.ar"> primaria050@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>2948498015</td>
                                            <td><a href="./mapas.php?id=580037000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 216 ALBERGUE</td>
                                            <td>RUTA PROVINCIAL 33</td>
                                            <td><a href="mailto:primaria216@neuquen.gov.ar"> primaria216@neuquen.gov.ar </a></td>
                                            <td>QUINTUCO</td>
                                            <td>NORTE</td>
                                            <td>2948490500</td>
                                            <td><a href="./mapas.php?id=580037100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO MARÍA AUXILIADORA NEUQUEN</td>
                                            <td>ROCA JULIO A GRL 855</td>
                                            <td><a href="mailto:nivelmedio@imaneuquen.edu.ar"> nivelmedio@imaneuquen.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422121</td>
                                            <td><a href="./mapas.php?id=580037400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 18 JULIO ARGENTINO ROCA</td>
                                            <td>DURAN 1460</td>
                                            <td><a href="mailto:cpem018@neuquen.gov.ar"> cpem018@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994432025</td>
                                            <td><a href="./mapas.php?id=580037500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 9 EDUARDO VÍCTOR GATTI</td>
                                            <td>NAHUEL HUAPI 84</td>
                                            <td><a href="mailto:epet009@neuquen.gov.ar"> epet009@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933653</td>
                                            <td><a href="./mapas.php?id=580037700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 112 AMALIA JESUSA URETA DE FUNES</td>
                                            <td>DE LOS OLMOS AV</td>
                                            <td><a href="mailto:primaria112@neuquen.gov.ar"> primaria112@neuquen.gov.ar </a></td>
                                            <td>TAQUIMILAN</td>
                                            <td>NORTE</td>
                                            <td>2948497034</td>
                                            <td><a href="./mapas.php?id=580037800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CRISTIANA CRECIENDO</td>
                                            <td>SAN MARTIN AV 440</td>
                                            <td><a href="mailto:creciendo@ccesperanza.org"> creciendo@ccesperanza.org </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994935770</td>
                                            <td><a href="./mapas.php?id=580037900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 37</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria037@neuquen.gov.ar"> primaria037@neuquen.gov.ar </a></td>
                                            <td>LOS CATUTOS</td>
                                            <td>CENTRO</td>
                                            <td>294215667722</td>
                                            <td><a href="./mapas.php?id=580038000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 217 ALBERGUE</td>
                                            <td>RUTA PROVINCIAL 46</td>
                                            <td><a href="mailto:primaria217@neuquen.gov.ar"> primaria217@neuquen.gov.ar </a></td>
                                            <td>ÑIRECO</td>
                                            <td>CENTRO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580038100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 36</td>
                                            <td>AVELLANEDA NICOLAS 1050</td>
                                            <td><a href="mailto:cpem036@neuquen.gov.ar"> cpem036@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942422015</td>
                                            <td><a href="./mapas.php?id=580038200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 61</td>
                                            <td>AVELLANEDA NICOLAS 1035</td>
                                            <td><a href="mailto:cpem061@neuquen.gov.ar"> cpem061@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942431697</td>
                                            <td><a href="./mapas.php?id=580038300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 8</td>
                                            <td>SAN MARTIN AV 452</td>
                                            <td><a href="mailto:jardin008@neuquen.gov.ar"> jardin008@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421334</td>
                                            <td><a href="./mapas.php?id=580038400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 8 ANEXO</td>
                                            <td>ETCHELUZ MARTIN 312</td>
                                            <td><a href="mailto:jardin008@neuquen.gov.ar"> jardin008@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942423911</td>
                                            <td><a href="./mapas.php?id=580038401"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 9</td>
                                            <td>FERNANDEZ ALBERTO DIP 1248</td>
                                            <td><a href="mailto:jardin009@neuquen.gov.ar"> jardin009@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942430505</td>
                                            <td><a href="./mapas.php?id=580038500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 224</td>
                                            <td>RUTA PROVINCIAL 10</td>
                                            <td><a href="mailto:primaria224@neuquen.gov.ar"> primaria224@neuquen.gov.ar </a></td>
                                            <td>BAJADA VIEJA</td>
                                            <td>CENTRO</td>
                                            <td>2942430505</td>
                                            <td><a href="./mapas.php?id=580038600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 128</td>
                                            <td>ACCESO RUTA NACIONAL 40</td>
                                            <td><a href="mailto:primaria128@neuquen.gov.ar"> primaria128@neuquen.gov.ar </a></td>
                                            <td>VILLA DEL AGRIO</td>
                                            <td>CENTRO</td>
                                            <td>294215460249</td>
                                            <td><a href="./mapas.php?id=580038700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 45</td>
                                            <td>25 DE MAYO</td>
                                            <td><a href="mailto:cpem045@neuquen.gov.ar"> cpem045@neuquen.gov.ar </a></td>
                                            <td>BAJADA DEL AGRIO</td>
                                            <td>CENTRO</td>
                                            <td>2942497948</td>
                                            <td><a href="./mapas.php?id=580038800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 14 ALEJANDRINO ROSALES</td>
                                            <td>RUTA PROVINCIAL 10</td>
                                            <td><a href="mailto:primaria014@neuquen.gov.ar"> primaria014@neuquen.gov.ar </a></td>
                                            <td>QUILI MALAL</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1148</td>
                                            <td><a href="./mapas.php?id=580038900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 171 NUEVA REPÚBLICA</td>
                                            <td>DE SAN MARTIN JOSE GRL AV</td>
                                            <td><a href="mailto:primaria171@neuquen.gov.ar"> primaria171@neuquen.gov.ar </a></td>
                                            <td>BAJADA DEL AGRIO</td>
                                            <td>CENTRO</td>
                                            <td>2942497947</td>
                                            <td><a href="./mapas.php?id=580039100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 88</td>
                                            <td>SAN MARTIN GRL AV 185</td>
                                            <td><a href="mailto:primaria088@neuquen.gov.ar"> primaria088@neuquen.gov.ar </a></td>
                                            <td>LAS COLORADAS</td>
                                            <td>CENTRO</td>
                                            <td>2942495057</td>
                                            <td><a href="./mapas.php?id=580039200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 83 ALBERGUE</td>
                                            <td>RUTA PROVINCIAL 20</td>
                                            <td><a href="mailto:primaria083@neuquen.gov.ar"> primaria083@neuquen.gov.ar </a></td>
                                            <td>CHACAYCO</td>
                                            <td>CENTRO</td>
                                            <td>2942489620</td>
                                            <td><a href="./mapas.php?id=580039300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 122</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria122@neuquen.gov.ar"> primaria122@neuquen.gov.ar </a></td>
                                            <td>BAJADA DE LOS MOLLES</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1107</td>
                                            <td><a href="./mapas.php?id=580039400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 231</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria231@neuquen.gov.ar"> primaria231@neuquen.gov.ar </a></td>
                                            <td>LAS CORTADERAS</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1111</td>
                                            <td><a href="./mapas.php?id=580039500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 247 ALBERGUE</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:primaria247@neuquen.gov.ar"> primaria247@neuquen.gov.ar </a></td>
                                            <td>AGUADA DEL FLORENCIO</td>
                                            <td>CENTRO</td>
                                            <td>2972422256</td>
                                            <td><a href="./mapas.php?id=580039600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 290</td>
                                            <td>RUTA PROVINCIAL 20</td>
                                            <td><a href="mailto:primaria290@neuquen.gov.ar"> primaria290@neuquen.gov.ar </a></td>
                                            <td>AGUA DEL OVERO</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1109</td>
                                            <td><a href="./mapas.php?id=580039800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 328 JUANA AZURDUY</td>
                                            <td>DE SAN MARTIN JOSE GRL</td>
                                            <td><a href="mailto:primaria328@neuquen.gov.ar"> primaria328@neuquen.gov.ar </a></td>
                                            <td>EL HUECU</td>
                                            <td>NORTE</td>
                                            <td>2948491036</td>
                                            <td><a href="./mapas.php?id=580040100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 30</td>
                                            <td>CIUDAD DE CHOS MALAL</td>
                                            <td><a href="mailto:cpem030@neuquen.gov.ar"> cpem030@neuquen.gov.ar </a></td>
                                            <td>EL HUECU</td>
                                            <td>NORTE</td>
                                            <td>2948491018</td>
                                            <td><a href="./mapas.php?id=580040200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 31</td>
                                            <td>COMPLEJO EL CHOCON</td>
                                            <td><a href="mailto:cpem031@neuquen.gov.ar"> cpem031@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>2994855095</td>
                                            <td><a href="./mapas.php?id=580040400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 39</td>
                                            <td>RUTA PROVINCIAL 7</td>
                                            <td><a href="mailto:cpem039@neuquen.gov.ar"> cpem039@neuquen.gov.ar </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994904090</td>
                                            <td><a href="./mapas.php?id=580040500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 144 ALBERGUE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria144@neuquen.gov.ar"> primaria144@neuquen.gov.ar </a></td>
                                            <td>AGUADA SAN ROQUE</td>
                                            <td>ANELO</td>
                                            <td>294215461418</td>
                                            <td><a href="./mapas.php?id=580040600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 238 GRAL ENRIQUE MOSCONI</td>
                                            <td>20 DE DICIEMBRE BV</td>
                                            <td><a href="mailto:primaria238@neuquen.gov.ar"> primaria238@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886040</td>
                                            <td><a href="./mapas.php?id=580040700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 5 EJÉRCITO ARGENTINO</td>
                                            <td>SAAVEDRA CORNELIO 180</td>
                                            <td><a href="mailto:cpem005@neuquen.gov.ar"> cpem005@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499018</td>
                                            <td><a href="./mapas.php?id=580040800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 7</td>
                                            <td>ROCA JULIO ARGENTINO 669</td>
                                            <td><a href="mailto:ifd007@neuquen.gov.ar"> ifd007@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499352</td>
                                            <td><a href="./mapas.php?id=580040900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 332 JULIO EUSTASIO GUIÑAZÚ ALANIZ</td>
                                            <td>ALANIZ</td>
                                            <td><a href="mailto:primaria332@neuquen.gov.ar"> primaria332@neuquen.gov.ar </a></td>
                                            <td>LA BUITRERA</td>
                                            <td>CENTRO</td>
                                            <td>2942499425</td>
                                            <td><a href="./mapas.php?id=580041000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 283 EMMA NILDA CÁRCAMO</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria283@neuquen.gov.ar"> primaria283@neuquen.gov.ar </a></td>
                                            <td>SAN DEMETRIO</td>
                                            <td>CENTRO</td>
                                            <td>2996205833</td>
                                            <td><a href="./mapas.php?id=580041100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 36 CEFERINO NAMUNCURA</td>
                                            <td>SAN MARTIN AV</td>
                                            <td><a href="mailto:primaria036@neuquen.gov.ar"> primaria036@neuquen.gov.ar </a></td>
                                            <td>COVUNCO CENTRO</td>
                                            <td>CENTRO</td>
                                            <td>2942490144</td>
                                            <td><a href="./mapas.php?id=580041300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 73 REG.INFANTERÍA DE MONTAÑA 10</td>
                                            <td>RUTA PROVINCIAL 3</td>
                                            <td><a href="mailto:primaria073@neuquen.gov.ar"> primaria073@neuquen.gov.ar </a></td>
                                            <td>COVUNCO ARRIBA</td>
                                            <td>CENTRO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580041400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 80 EJÉRCITO ARGENTINO</td>
                                            <td>12 DE OCTUBRE</td>
                                            <td><a href="mailto:primaria080@neuquen.gov.ar"> primaria080@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>294215548194</td>
                                            <td><a href="./mapas.php?id=580041500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 99 SAN JUAN BOSCO</td>
                                            <td>BROWN ALMTE 1651</td>
                                            <td><a href="mailto:primaria099@neuquen.gov.ar"> primaria099@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421446</td>
                                            <td><a href="./mapas.php?id=580041600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 114 EMILIO ANDRÉS HAAS</td>
                                            <td>25 DE MAYO 1950</td>
                                            <td><a href="mailto:primaria114@neuquen.gov.ar"> primaria114@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421424</td>
                                            <td><a href="./mapas.php?id=580041800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 135 TTE GRAL EDUARDO RACEDO</td>
                                            <td>BELGRANO MANUEL GRL</td>
                                            <td><a href="mailto:primaria135@neuquen.gov.ar"> primaria135@neuquen.gov.ar </a></td>
                                            <td>MARIANO MORENO</td>
                                            <td>CENTRO</td>
                                            <td>2942490116</td>
                                            <td><a href="./mapas.php?id=580041900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 156</td>
                                            <td>SARMIENTO DOMINGO F 260</td>
                                            <td><a href="mailto:primaria156@neuquen.gov.ar"> primaria156@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421604</td>
                                            <td><a href="./mapas.php?id=580042000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 218</td>
                                            <td>RUTA PROVINCIAL 13</td>
                                            <td><a href="mailto:primaria218@neuquen.gov.ar"> primaria218@neuquen.gov.ar </a></td>
                                            <td>LAGUNA MIRANDA</td>
                                            <td>CENTRO</td>
                                            <td>2996581919</td>
                                            <td><a href="./mapas.php?id=580042100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUCIÓN SALESIANA TALLERES DON BOSCO</td>
                                            <td>PRIMEROS POBLADORES 151</td>
                                            <td><a href="mailto:talleresdonbosco@neuquen.gov.ar"> talleresdonbosco@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942422325</td>
                                            <td><a href="./mapas.php?id=580042300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 225 LÍA RIVEROS DE FLORES</td>
                                            <td>DE NEVARES JAIME F DON</td>
                                            <td><a href="mailto:primaria225@neuquen.gov.ar"> primaria225@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421345</td>
                                            <td><a href="./mapas.php?id=580042400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 16</td>
                                            <td>NEWBERY JORGE</td>
                                            <td><a href="mailto:jardin016@neuquen.gov.ar"> jardin016@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421432</td>
                                            <td><a href="./mapas.php?id=580042500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 4</td>
                                            <td>GARDIN PADRE 21</td>
                                            <td><a href="mailto:cpem004@neuquen.gov.ar"> cpem004@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421468</td>
                                            <td><a href="./mapas.php?id=580042600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 185</td>
                                            <td>RAHUE 138</td>
                                            <td><a href="mailto:primaria185@neuquen.gov.ar"> primaria185@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942430620</td>
                                            <td><a href="./mapas.php?id=580042700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 307</td>
                                            <td>FERNANDEZ ALBERTO DIPUTADO 1261</td>
                                            <td><a href="mailto:primaria307@neuquen.gov.ar"> primaria307@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421521</td>
                                            <td><a href="./mapas.php?id=580042800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 3 TTE AVIADOR LUIS CANDELARIA</td>
                                            <td>ITALIA 327</td>
                                            <td><a href="mailto:primaria003@neuquen.gov.ar"> primaria003@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421479</td>
                                            <td><a href="./mapas.php?id=580042900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 148</td>
                                            <td>LONCO LUAN</td>
                                            <td><a href="mailto:primaria148@neuquen.gov.ar"> primaria148@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942422175</td>
                                            <td><a href="./mapas.php?id=580043000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 167 LUIS BELTRÁN MERCADO</td>
                                            <td>R DE CHURRARIN MARIA A</td>
                                            <td><a href="mailto:primaria167@neuquen.gov.ar"> primaria167@neuquen.gov.ar </a></td>
                                            <td>PICUN LEUFU</td>
                                            <td>SUR</td>
                                            <td>2942492049</td>
                                            <td><a href="./mapas.php?id=580044100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 177</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria177@neuquen.gov.ar"> primaria177@neuquen.gov.ar </a></td>
                                            <td>VILLA UNION</td>
                                            <td>SUR</td>
                                            <td>294215665764</td>
                                            <td><a href="./mapas.php?id=580044200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 189</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria189@neuquen.gov.ar"> primaria189@neuquen.gov.ar </a></td>
                                            <td>PICUN LEUFU</td>
                                            <td>SUR</td>
                                            <td>2948450372</td>
                                            <td><a href="./mapas.php?id=580044300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 228</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria228@neuquen.gov.ar"> primaria228@neuquen.gov.ar </a></td>
                                            <td>PASO AGUERRE</td>
                                            <td>SUR</td>
                                            <td>2942489526</td>
                                            <td><a href="./mapas.php?id=580044400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 16</td>
                                            <td>LOS ALAMOS PSJE</td>
                                            <td><a href="mailto:cpem016@neuquen.gov.ar"> cpem016@neuquen.gov.ar </a></td>
                                            <td>PICUN LEUFU</td>
                                            <td>SUR</td>
                                            <td>2942492032</td>
                                            <td><a href="./mapas.php?id=580044600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 16 ANEXO PASO AGUERRE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:cpem016anexo@neuquen.gov.ar"> cpem016anexo@neuquen.gov.ar </a></td>
                                            <td>PASO AGUERRE</td>
                                            <td>SUR</td>
                                            <td>2942489526</td>
                                            <td><a href="./mapas.php?id=580044601"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 265 INTENDENTE CÉSAR REGUERO</td>
                                            <td>RIO LIMAY 60</td>
                                            <td><a href="mailto:primaria265@neuquen.gov.ar"> primaria265@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994936609</td>
                                            <td><a href="./mapas.php?id=580044800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 106 BENJAMÍN MATIENZO</td>
                                            <td>CANDOLLE AV 4099</td>
                                            <td><a href="mailto:primaria106@neuquen.gov.ar"> primaria106@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994936725</td>
                                            <td><a href="./mapas.php?id=580044900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 1 CIUDAD DE BUENOS AIRES</td>
                                            <td>CATRIEL 435</td>
                                            <td><a href="mailto:primaria001@neuquen.gov.ar"> primaria001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994430462</td>
                                            <td><a href="./mapas.php?id=580045000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 200 MÉDICO RURAL DR RENÉ FAVALORO</td>
                                            <td>RHODE CNL 1360</td>
                                            <td><a href="mailto:primaria200@neuquen.gov.ar"> primaria200@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460155</td>
                                            <td><a href="./mapas.php?id=580045100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 220</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:natividadtinario2020@gmail.com"> natividadtinario2020@gmail.com </a></td>
                                            <td>EL SAUCE</td>
                                            <td>SUR</td>
                                            <td>2995469930</td>
                                            <td><a href="./mapas.php?id=580045200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 1 NIVEL INICIAL Y PRIMARIA</td>
                                            <td>LOS ÑIRES 220</td>
                                            <td><a href="mailto:jardin011@neuquen.gov.ar ; ifd001niyp@neuquen.gov.ar"> jardin011@neuquen.gov.ar ; ifd001niyp@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994965995</td>
                                            <td><a href="./mapas.php?id=580045500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 14</td>
                                            <td>MORENO PERITO 240</td>
                                            <td><a href="mailto:ifd014@neuquen.gov.ar"> ifd014@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994964847</td>
                                            <td><a href="./mapas.php?id=580045600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 5</td>
                                            <td>PAZ GRL 157</td>
                                            <td><a href="mailto:epa005@neuquen.gov.ar"> epa005@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994962493</td>
                                            <td><a href="./mapas.php?id=580045700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 255 AMÉRICO ANÍBAL JOSÉ VERDENELLI</td>
                                            <td>DEL TRABAJO AV</td>
                                            <td><a href="mailto:primaria255@neuquen.gov.ar"> primaria255@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994962209</td>
                                            <td><a href="./mapas.php?id=580045800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 193</td>
                                            <td>LAS GAVIOTAS 1070</td>
                                            <td><a href="mailto:primaria193@neuquen.gov.ar"> primaria193@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460174</td>
                                            <td><a href="./mapas.php?id=580045900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 190</td>
                                            <td>GOMEZ CASIMIRO 1551</td>
                                            <td><a href="mailto:primaria190@neuquen.gov.ar"> primaria190@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461778</td>
                                            <td><a href="./mapas.php?id=580046000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 199</td>
                                            <td>LAS GAVIOTAS</td>
                                            <td><a href="mailto:primaria199@neuquen.gov.ar"> primaria199@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994462979</td>
                                            <td><a href="./mapas.php?id=580046100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 56 PCIA DE RÍO NEGRO</td>
                                            <td>LIBERTAD 325</td>
                                            <td><a href="mailto:primaria056@neuquen.gov.ar"> primaria056@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435878</td>
                                            <td><a href="./mapas.php?id=580046200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 1 SENDEROS DE LUZ</td>
                                            <td>GALARZA 2851</td>
                                            <td><a href="mailto:especial001@neuquen.gov.ar"> especial001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994466500</td>
                                            <td><a href="./mapas.php?id=580046300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 195 SILVIA BOS</td>
                                            <td>CATRIEL 1151</td>
                                            <td><a href="mailto:primaria195@neuquen.gov.ar"> primaria195@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422215</td>
                                            <td><a href="./mapas.php?id=580046400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 150 ESPAÑA</td>
                                            <td>EMMA CARLOS MAESTRO PSJE 1021</td>
                                            <td><a href="mailto:primaria150@neuquen.gov.ar"> primaria150@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435708</td>
                                            <td><a href="./mapas.php?id=580046500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 7</td>
                                            <td>GALARZA 2625</td>
                                            <td><a href="mailto:epet007@neuquen.gov.ar"> epet007@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994466963</td>
                                            <td><a href="./mapas.php?id=580046600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 23 HUEPIL</td>
                                            <td>SARMIENTO DOMINGO F 411</td>
                                            <td><a href="mailto:jardin023@neuquen.gov.ar"> jardin023@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423739</td>
                                            <td><a href="./mapas.php?id=580046700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 2</td>
                                            <td>LAINEZ MANUEL 102</td>
                                            <td><a href="mailto:cpem002@neuquen.gov.ar"> cpem002@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994438733</td>
                                            <td><a href="./mapas.php?id=580046800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 136 DOÑA TERESA CORONADO</td>
                                            <td>EL CHOCON 2575</td>
                                            <td><a href="mailto:primaria136@neuquen.gov.ar"> primaria136@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994401150</td>
                                            <td><a href="./mapas.php?id=580046900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO BILINGÜE NEUQUEN</td>
                                            <td>LOS ALAMOS 700</td>
                                            <td><a href="mailto:secretaria@bilingueneuquen.com.ar"> secretaria@bilingueneuquen.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994402214</td>
                                            <td><a href="./mapas.php?id=580047000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 103 TTE GRAL JULIO A ROCA</td>
                                            <td>PERTICONE EUGENIO 1841</td>
                                            <td><a href="mailto:primaria103@neuquen.gov.ar"> primaria103@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994400043</td>
                                            <td><a href="./mapas.php?id=580047100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 302</td>
                                            <td>RUTA PROVINCIAL 4</td>
                                            <td><a href="mailto:primaria302@neuquen.gov.ar"> primaria302@neuquen.gov.ar </a></td>
                                            <td>COLIPILLI</td>
                                            <td>NORTE</td>
                                            <td>29484910556</td>
                                            <td><a href="./mapas.php?id=580047200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 11</td>
                                            <td>9 DE JULIO 341</td>
                                            <td><a href="mailto:epet011@neuquen.gov.ar"> epet011@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421616</td>
                                            <td><a href="./mapas.php?id=580047500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 5 SUYAI</td>
                                            <td>TORRES MAYOR 1650</td>
                                            <td><a href="mailto:especial005@neuquen.gov.ar"> especial005@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421850</td>
                                            <td><a href="./mapas.php?id=580047600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 37</td>
                                            <td>LEVALLE NICOLAS AV</td>
                                            <td><a href="mailto:cpem037@neuquen.gov.ar"> cpem037@neuquen.gov.ar </a></td>
                                            <td>MARIANO MORENO</td>
                                            <td>CENTRO</td>
                                            <td>2942490153</td>
                                            <td><a href="./mapas.php?id=580047700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 1 PADRE JOSÉ MARÍA</td>
                                            <td>DE ALVEAR MARCELO T BV 110</td>
                                            <td><a href="mailto:jardin001@neuquen.gov.ar"> jardin001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422988</td>
                                            <td><a href="./mapas.php?id=580048000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO MARÍA AUXILIADORA NIVEL MEDIO</td>
                                            <td>PONTE GINES 451</td>
                                            <td><a href="mailto:imanmjunin@neuquen.gov.ar"> imanmjunin@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491119</td>
                                            <td><a href="./mapas.php?id=580048200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 4 GENDARMERÍA NACIONAL</td>
                                            <td>ALVAREZ GREGORIO DR</td>
                                            <td><a href="mailto:epet004@neuquen.gov.ar"> epet004@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491556</td>
                                            <td><a href="./mapas.php?id=580048300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA TALLER LAURA VICUÑA</td>
                                            <td>PONTE GINES 451</td>
                                            <td><a href="mailto:tallerlauravicuna@neuquen.gov.ar"> tallerlauravicuna@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491119</td>
                                            <td><a href="./mapas.php?id=580048400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 7 MALVINAS ARGENTINAS</td>
                                            <td>SAN MARTIN 607</td>
                                            <td><a href="mailto:cpem007@neuquen.gov.ar"> cpem007@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491127</td>
                                            <td><a href="./mapas.php?id=580048500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 8</td>
                                            <td>PAIME AIME</td>
                                            <td><a href="mailto:ifd008@neuquen.gov.ar"> ifd008@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>299156556906</td>
                                            <td><a href="./mapas.php?id=580048600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.M.O.E. CEFERINO NAMUNCURA</td>
                                            <td>PONTE GINES 571</td>
                                            <td><a href="mailto:cemoeceferino@neuquen.gov.ar"> cemoeceferino@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491178</td>
                                            <td><a href="./mapas.php?id=580049500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO CEFERINO NAMUNCURA</td>
                                            <td>PONTE GINES 571</td>
                                            <td><a href="mailto:colegioceferino@neuquen.gov.ar"> colegioceferino@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491178</td>
                                            <td><a href="./mapas.php?id=580049900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 11 MARÍA MONTESSORI</td>
                                            <td>DUARTE DE PERON EVA 401</td>
                                            <td><a href="mailto:jardin011@neuquen.gov.ar"> jardin011@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491100</td>
                                            <td><a href="./mapas.php?id=580050200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 30 RUCA PICHICHE</td>
                                            <td>OLAVARRIA 390</td>
                                            <td><a href="mailto:jardin030@neuquen.gov.ar"> jardin030@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491135</td>
                                            <td><a href="./mapas.php?id=580050300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 7 TOMÁS FALKNER</td>
                                            <td>REPUBLICA DE CHILE 325</td>
                                            <td><a href="mailto:primaria007@neuquen.gov.ar"> primaria007@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491139</td>
                                            <td><a href="./mapas.php?id=580050400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 187 MAESTRO ERNESTO COMELLI</td>
                                            <td>ALVAREZ GREGORIO DR</td>
                                            <td><a href="mailto:primaria187@neuquen.gov.ar"> primaria187@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491583</td>
                                            <td><a href="./mapas.php?id=580050500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 153 AGUSTÍN CACACE</td>
                                            <td>MORENO MARIANO 633</td>
                                            <td><a href="mailto:primaria153@neuquen.gov.ar"> primaria153@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491275</td>
                                            <td><a href="./mapas.php?id=580050600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 11</td>
                                            <td>LAMADRID GRL 430</td>
                                            <td><a href="mailto:epa011@neuquen.gov.ar"> epa011@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972492102</td>
                                            <td><a href="./mapas.php?id=580050800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 9 RUCA ANTU</td>
                                            <td>ALVAREZ GREGORIO DR</td>
                                            <td><a href="mailto:escuela009@neuquen.gov.ar"> escuela009@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491733</td>
                                            <td><a href="./mapas.php?id=580050900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 65</td>
                                            <td>ALVAREZ GREGORIO DR</td>
                                            <td><a href="mailto:cpem065@neuquen.gov.ar"> cpem065@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491472</td>
                                            <td><a href="./mapas.php?id=580051200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 46 MAESTROS ARGENTINOS</td>
                                            <td>SAN LUIS 550</td>
                                            <td><a href="mailto:primaria046@neuquen.gov.ar"> primaria046@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299493337</td>
                                            <td><a href="./mapas.php?id=580051400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 92 PEDRO B PALACIOS ALMAFUERTE</td>
                                            <td>NORIEGA GOMEZ F 371</td>
                                            <td><a href="mailto:primaria092@neuquen.gov.ar"> primaria092@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933336</td>
                                            <td><a href="./mapas.php?id=580051500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 18 INTEGRACIÓN LATINOAMERICANA</td>
                                            <td>ALBERDI JUAN BAUTISTA 459</td>
                                            <td><a href="mailto:jardin018@neuquen.gov.ar"> jardin018@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994934785</td>
                                            <td><a href="./mapas.php?id=580051600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 268</td>
                                            <td>URQUIZA 523</td>
                                            <td><a href="mailto:primaria268@neuquen.gov.ar"> primaria268@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994920523</td>
                                            <td><a href="./mapas.php?id=580051700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 9</td>
                                            <td>CALLE 02</td>
                                            <td><a href="mailto:cpem009@neuquen.gov.ar"> cpem009@neuquen.gov.ar </a></td>
                                            <td>VILLA EL CHOCON</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994901227</td>
                                            <td><a href="./mapas.php?id=580051800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 3</td>
                                            <td>COPAHUE 725</td>
                                            <td><a href="mailto:cpem003@neuquen.gov.ar"> cpem003@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421675</td>
                                            <td><a href="./mapas.php?id=580051900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 48</td>
                                            <td>ABRAHAM DAVID 2135</td>
                                            <td><a href="mailto:cpem048@neuquen.gov.ar"> cpem048@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994436948</td>
                                            <td><a href="./mapas.php?id=580052000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 326 DOMINGO SARMIENTO</td>
                                            <td>SAN MARTIN AV 916</td>
                                            <td><a href="mailto:primaria326@neuquen.gov.ar"> primaria326@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421493</td>
                                            <td><a href="./mapas.php?id=580052100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 257 REPÚBLICA DE MÉXICO</td>
                                            <td>AVELLANEDA NICOLAS 1055</td>
                                            <td><a href="mailto:primaria257@neuquen.gov.ar"> primaria257@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421486</td>
                                            <td><a href="./mapas.php?id=580052200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 194 PABLO NERUDA</td>
                                            <td>9 DE JULIO</td>
                                            <td><a href="mailto:primaria194@neuquen.gov.ar"> primaria194@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942422114</td>
                                            <td><a href="./mapas.php?id=580052300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO BAUTISTA AMEN</td>
                                            <td>AMEGHINO FLORENTINO 1305</td>
                                            <td><a href="mailto:amenprimaria@neuquen.gov.ar"> amenprimaria@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994434260</td>
                                            <td><a href="./mapas.php?id=580052400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO NUESTRA SEÑORA DE LA VIDA</td>
                                            <td>ANTARTIDA ARGENTINA 4125</td>
                                            <td><a href="mailto:colegionsdelavida@gmail.com"> colegionsdelavida@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994451262</td>
                                            <td><a href="./mapas.php?id=580052600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 54</td>
                                            <td>CASTELLI JUAN JOSE 4475</td>
                                            <td><a href="mailto:cpem054@neuquen.gov.ar"> cpem054@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2995220362</td>
                                            <td><a href="./mapas.php?id=580052700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 288 HÉROES DE MALVINAS</td>
                                            <td>RUTA NACIONAL 22</td>
                                            <td><a href="mailto:primaria288@neuquen.gov.ar"> primaria288@neuquen.gov.ar </a></td>
                                            <td>SANTO DOMINGO</td>
                                            <td>CENTRO</td>
                                            <td>2995879172</td>
                                            <td><a href="./mapas.php?id=580053100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 8</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria008@neuquen.gov.ar"> primaria008@neuquen.gov.ar </a></td>
                                            <td>RAMON M. CASTRO</td>
                                            <td>CENTRO</td>
                                            <td>2942432042</td>
                                            <td><a href="./mapas.php?id=580053300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 2</td>
                                            <td>BROWN ALMTE 1651</td>
                                            <td><a href="mailto:epa002@neuquen.gov.ar"> epa002@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421446</td>
                                            <td><a href="./mapas.php?id=580053600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 2 ANEXO LAS COLORADAS</td>
                                            <td>SAN MARTIN GRL AV</td>
                                            <td><a href="mailto:epa002@neuquen.gov.ar"> epa002@neuquen.gov.ar </a></td>
                                            <td>LAS COLORADAS</td>
                                            <td>CENTRO</td>
                                            <td>2942421750</td>
                                            <td><a href="./mapas.php?id=580053601"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 2 ANEXO LOS CATUTOS</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:epa002@neuquen.gov.ar"> epa002@neuquen.gov.ar </a></td>
                                            <td>LOS CATUTOS</td>
                                            <td>CENTRO</td>
                                            <td>2942421750</td>
                                            <td><a href="./mapas.php?id=580053602"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 2 ANEXO RAMON CASTRO</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:epa002@neuquen.gov.ar"> epa002@neuquen.gov.ar </a></td>
                                            <td>RAMON M. CASTRO</td>
                                            <td>CENTRO</td>
                                            <td>2942421750</td>
                                            <td><a href="./mapas.php?id=580053603"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 85 SOBERANÍA ARGENTINA</td>
                                            <td>RUTA PROVINCIAL 3</td>
                                            <td><a href="mailto:primaria085@neuquen.gov.ar"> primaria085@neuquen.gov.ar </a></td>
                                            <td>LOS HORNOS</td>
                                            <td>CENTRO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580053700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 87 LA PATRIA</td>
                                            <td>RUTA PROVINCIAL 16</td>
                                            <td><a href="mailto:primaria087@neuquen.gov.ar"> primaria087@neuquen.gov.ar </a></td>
                                            <td>COVUNCO ABAJO</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1190</td>
                                            <td><a href="./mapas.php?id=580053800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 54 REPÚBLICA ÁRABE - SIRIA</td>
                                            <td>RUTA PROVINCIAL 16</td>
                                            <td><a href="mailto:primaria054@neuquen.gov.ar"> primaria054@neuquen.gov.ar </a></td>
                                            <td>LA PATAGONIA</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1151</td>
                                            <td><a href="./mapas.php?id=580053900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES RAYITOS DE ESPERANZA</td>
                                            <td>CHANETON ABEL 640</td>
                                            <td><a href="mailto:jardinrayitos@hotmail.com"> jardinrayitos@hotmail.com </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942423457</td>
                                            <td><a href="./mapas.php?id=580054000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 81 SOLDADOS DE LA PATRIA</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria081@neuquen.gov.ar"> primaria081@neuquen.gov.ar </a></td>
                                            <td>PUENTE PICUN LEUFU</td>
                                            <td>CENTRO</td>
                                            <td>2942489910</td>
                                            <td><a href="./mapas.php?id=580054100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 215</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria215@neuquen.gov.ar"> primaria215@neuquen.gov.ar </a></td>
                                            <td>BARDA NEGRA</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1172</td>
                                            <td><a href="./mapas.php?id=580054200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 10 PADRE JACINTO STABILE</td>
                                            <td>GODOY DIAZ ALFREDO 181</td>
                                            <td><a href="mailto:especial010@neuquen.gov.ar"> especial010@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994890235</td>
                                            <td><a href="./mapas.php?id=580054700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA SALESIANA VIRGEN DE LUJÁN</td>
                                            <td>PONS INTD 160</td>
                                            <td><a href="mailto:cvirgendelujan@gmail.com"> cvirgendelujan@gmail.com </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891053</td>
                                            <td><a href="./mapas.php?id=580054800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 13 HUENEI HUE</td>
                                            <td>HONDURAS</td>
                                            <td><a href="mailto:jardin013@neuquen.gov.ar"> jardin013@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891492</td>
                                            <td><a href="./mapas.php?id=580054900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 91 DR. ROBERTO NOBLE</td>
                                            <td>NEUQUEN</td>
                                            <td><a href="mailto:primaria091@neuquen.gov.ar"> primaria091@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994920528</td>
                                            <td><a href="./mapas.php?id=580055100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 186 PUÑEN-HUE</td>
                                            <td>HUEMUL AV 171</td>
                                            <td><a href="mailto:primaria186@neuquen.gov.ar"> primaria186@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494555</td>
                                            <td><a href="./mapas.php?id=580055200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 111</td>
                                            <td>CARPINTERO GIGANTE</td>
                                            <td><a href="mailto:primaria111@neuquen.gov.ar"> primaria111@neuquen.gov.ar </a></td>
                                            <td>VILLA TRAFUL</td>
                                            <td>SUR</td>
                                            <td>2944479082</td>
                                            <td><a href="./mapas.php?id=580055300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 17</td>
                                            <td>LOS TAIQUES 17</td>
                                            <td><a href="mailto:cpem017@neuquen.gov.ar"> cpem017@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494243</td>
                                            <td><a href="./mapas.php?id=580055600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 26 FRUTILLITAS</td>
                                            <td>NAHUEL HUAPI AV 417</td>
                                            <td><a href="mailto:jardin026@neuquen.gov.ar"> jardin026@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494637</td>
                                            <td><a href="./mapas.php?id=580056200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 104 EL CORAZÓN DE LOS LAGOS</td>
                                            <td>LOS TAIQUES 18</td>
                                            <td><a href="mailto:primaria104@neuquen.gov.ar"> primaria104@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494167</td>
                                            <td><a href="./mapas.php?id=580056300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 134 GENDARME ARGENTINO</td>
                                            <td>ROCA RUDECINDO 719</td>
                                            <td><a href="mailto:primaria134@neuquen.gov.ar"> primaria134@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972427579</td>
                                            <td><a href="./mapas.php?id=580056400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 107 CARLOS BOUQUET ROLDÁN</td>
                                            <td>PLANAS TEODORO 3645</td>
                                            <td><a href="mailto:primaria107@neuquen.gov.ar"> primaria107@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994467477</td>
                                            <td><a href="./mapas.php?id=580056600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 29</td>
                                            <td>RUTA PROVINCIAL 21</td>
                                            <td><a href="mailto:primaria029@neuquen.gov.ar"> primaria029@neuquen.gov.ar </a></td>
                                            <td>HUALCUPEN</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1132</td>
                                            <td><a href="./mapas.php?id=580056700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 152 ESTHER KRAITMAN DE KASTIKA</td>
                                            <td>ALBERDI JUAN B 133</td>
                                            <td><a href="mailto:primaria152@neuquen.gov.ar"> primaria152@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994961802</td>
                                            <td><a href="./mapas.php?id=580056800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 15 RAQUEL GRILLO DE ROSENBROCK</td>
                                            <td>SAENZ PEÑA ROQUE 1655</td>
                                            <td><a href="mailto:jardin015@neuquen.gov.ar"> jardin015@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994961504</td>
                                            <td><a href="./mapas.php?id=580057000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 13 REPÚBLICA DE NICARAGUA</td>
                                            <td>ITALIA 144</td>
                                            <td><a href="mailto:ifd013terciario@neuquen.gov.ar"> ifd013terciario@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421942</td>
                                            <td><a href="./mapas.php?id=580057100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 14 DOÑA GREGORIA MATORRAS DE SAN MARTÍN</td>
                                            <td>SANTA FE 1020</td>
                                            <td><a href="mailto:epet014@neuquen.gov.ar"> epet014@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423807</td>
                                            <td><a href="./mapas.php?id=580057200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO SANTA TERESA DE JESÚS NIVEL PRIMARIO</td>
                                            <td>CARMEN DE PATAGONES 450</td>
                                            <td><a href="mailto:direccionprimariastj@hotmail.com"> direccionprimariastj@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423562</td>
                                            <td><a href="./mapas.php?id=580057300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 6</td>
                                            <td>MOREAU DE JUSTO ALICIA 1900</td>
                                            <td><a href="mailto:alechaures@hotmail.com"> alechaures@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994432333</td>
                                            <td><a href="./mapas.php?id=580057400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 204</td>
                                            <td>RUTA PROVINCIAL 7</td>
                                            <td><a href="mailto:primaria204@neuquen.gov.ar"> primaria204@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994898455</td>
                                            <td><a href="./mapas.php?id=580057800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 282</td>
                                            <td>LAGO LACAR</td>
                                            <td><a href="mailto:primaria282@neuquen.gov.ar"> primaria282@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994898732</td>
                                            <td><a href="./mapas.php?id=580058000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 223 DON VICTORIANO ÁVILA</td>
                                            <td>SAN IGNACIO 4010</td>
                                            <td><a href="mailto:primaria223@neuquen.gov.ar"> primaria223@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440623</td>
                                            <td><a href="./mapas.php?id=580058100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES ALITA</td>
                                            <td>PUCARA 5445</td>
                                            <td><a href="mailto:jardinalita@outlook.com.ar"> jardinalita@outlook.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994006581</td>
                                            <td><a href="./mapas.php?id=580058200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 31 ANTU MOGNEN</td>
                                            <td>HUILEN AV 1621</td>
                                            <td><a href="mailto:jardin031@neuquen.gov.ar"> jardin031@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461762</td>
                                            <td><a href="./mapas.php?id=580058300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 18 LAURA ALMENDRA</td>
                                            <td>RUTA PROVINCIAL 44</td>
                                            <td><a href="mailto:primaria018@neuquen.gov.ar"> primaria018@neuquen.gov.ar </a></td>
                                            <td>LOS CARRIZOS</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1191</td>
                                            <td><a href="./mapas.php?id=580058400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 118 REPÚBLICA DE ITALIA</td>
                                            <td>INDEPENDENCIA 920</td>
                                            <td><a href="mailto:primaria118@neuquen.gov.ar"> primaria118@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994434002</td>
                                            <td><a href="./mapas.php?id=580059100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 1</td>
                                            <td>RICCHIERI PABLO 1095</td>
                                            <td><a href="mailto:epa001@neuquen.gov.ar"> epa001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994404287</td>
                                            <td><a href="./mapas.php?id=580059200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 140 PROVINCIA DE SANTA FE</td>
                                            <td>BOSCH REMIGIO 1150</td>
                                            <td><a href="mailto:primaria140@neuquen.gov.ar"> primaria140@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994433050</td>
                                            <td><a href="./mapas.php?id=580059300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 261</td>
                                            <td>RUTA PROVINCIAL 11 KM 13</td>
                                            <td><a href="mailto:primaria261@neuquen.gov.ar"> primaria261@neuquen.gov.ar </a></td>
                                            <td>MOQUEHUE</td>
                                            <td>SUR</td>
                                            <td>2942470690</td>
                                            <td><a href="./mapas.php?id=580059500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 6 FRAY JUSTO SANTA MARÍA DE ORO</td>
                                            <td>RUTA PROVINCIAL 31</td>
                                            <td><a href="mailto:primaria006@neuquen.gov.ar"> primaria006@neuquen.gov.ar </a></td>
                                            <td>HUNCAL</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1147</td>
                                            <td><a href="./mapas.php?id=580059600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 168 MANUEL BELGRANO</td>
                                            <td>BELGRANO MANUEL</td>
                                            <td><a href="mailto:primaria168@neuquen.gov.ar"> primaria168@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>2948498072</td>
                                            <td><a href="./mapas.php?id=580059700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 10</td>
                                            <td>ALMENDRA DAVID</td>
                                            <td><a href="mailto:ifd010@neuquen.gov.ar"> ifd010@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>2948498397</td>
                                            <td><a href="./mapas.php?id=580059800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 2 HABÍA UNA VEZ</td>
                                            <td>RODRIGUEZ GDOR</td>
                                            <td><a href="mailto:jardin002@neuquen.gov.ar"> jardin002@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>2948498047</td>
                                            <td><a href="./mapas.php?id=580059900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 234 12 DE SETIEMBRE</td>
                                            <td>RIO COLORADO 1100</td>
                                            <td><a href="mailto:escuela234plottier@hotmail.com"> escuela234plottier@hotmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933557</td>
                                            <td><a href="./mapas.php?id=580060000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 97</td>
                                            <td>PICHAIHUE</td>
                                            <td><a href="mailto:primaria097@neuquen.gov.ar"> primaria097@neuquen.gov.ar </a></td>
                                            <td>CHORRIACA</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1112</td>
                                            <td><a href="./mapas.php?id=580060200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 52</td>
                                            <td>VILLEGAS CONRADO 279</td>
                                            <td><a href="mailto:primaria052@neuquen.gov.ar"> primaria052@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2942496121</td>
                                            <td><a href="./mapas.php?id=580060300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 20</td>
                                            <td>SAYHUEQUE CQUE 600</td>
                                            <td><a href="mailto:jardin020@neuquen.gov.ar"> jardin020@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2942496283</td>
                                            <td><a href="./mapas.php?id=580060600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 14</td>
                                            <td>VILLEGAS CONRADO 472</td>
                                            <td><a href="mailto:cpem014@neuquen.gov.ar"> cpem014@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2942496230</td>
                                            <td><a href="./mapas.php?id=580060700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 74 GRAL MARTÍN MIGUEL DE GÜEMES</td>
                                            <td>SARMIENTO DOMINGO F 1045</td>
                                            <td><a href="mailto:primaria074@neuquen.gov.ar"> primaria074@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994487575</td>
                                            <td><a href="./mapas.php?id=580060800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 125 ROSALÍA NÚÑEZ DE ALCARAZ</td>
                                            <td>ROCA JULIO A GRL 850</td>
                                            <td><a href="mailto:primaria125@neuquen.gov.ar"> primaria125@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423461</td>
                                            <td><a href="./mapas.php?id=580060900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 14 AYELEN</td>
                                            <td>BOUQUET ROLDAN CARLOS 210</td>
                                            <td><a href="mailto:jardin014@neuquen.gov.ar"> jardin014@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994432173</td>
                                            <td><a href="./mapas.php?id=580061000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO NEUQUINO DEL PROFESORADO EN INGLÉS</td>
                                            <td>FOTHERINGHAM 346</td>
                                            <td><a href="mailto:secretariainpi@gmail.com"> secretariainpi@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994420429</td>
                                            <td><a href="./mapas.php?id=580061100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 21</td>
                                            <td>DURAN 1460</td>
                                            <td><a href="mailto:cpem021@neuquen.gov.ar"> cpem021@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994432025</td>
                                            <td><a href="./mapas.php?id=580061300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 33 TRAFUL</td>
                                            <td>RODHE CNL 531</td>
                                            <td><a href="mailto:jardin033@neuquen.gov.ar"> jardin033@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461106</td>
                                            <td><a href="./mapas.php?id=580061400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 60</td>
                                            <td>ELORDI GDOR 135</td>
                                            <td><a href="mailto:primaria060@neuquen.gov.ar"> primaria060@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933338</td>
                                            <td><a href="./mapas.php?id=580061500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 14</td>
                                            <td>ROCA GRL AV 230</td>
                                            <td><a href="mailto:epa014@neuquen.gov.ar"> epa014@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994938340</td>
                                            <td><a href="./mapas.php?id=580061600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 14 ANEXO VILLA EL CHOCÓN</td>
                                            <td>9 DE ENERO AV</td>
                                            <td><a href="mailto:epa14plottier@gmail.com"> epa14plottier@gmail.com </a></td>
                                            <td>VILLA EL CHOCON</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994938340</td>
                                            <td><a href="./mapas.php?id=580061601"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 266 EJÉRCITO ARGENTINO</td>
                                            <td>SAN MARTIN AV 2320</td>
                                            <td><a href="mailto:primaria266@neuquen.gov.ar"> primaria266@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933566</td>
                                            <td><a href="./mapas.php?id=580061700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 98 REMEDIOS ESCALADA DE SAN MARTÍN</td>
                                            <td>MISIONES 296</td>
                                            <td><a href="mailto:primaria098@neuquen.gov.ar"> primaria098@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994936606</td>
                                            <td><a href="./mapas.php?id=580061800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 26 CONQUISTA DEL DESIERTO</td>
                                            <td>CALLE 02</td>
                                            <td><a href="mailto:primaria026@neuquen.gov.ar"> primaria026@neuquen.gov.ar </a></td>
                                            <td>VILLA EL CHOCON</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299491226</td>
                                            <td><a href="./mapas.php?id=580061900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 5</td>
                                            <td>SANTA FE SUR 1300</td>
                                            <td><a href="mailto:ifd005@neuquen.gov.ar"> ifd005@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994932962</td>
                                            <td><a href="./mapas.php?id=580062000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 38 RUCA ANTU</td>
                                            <td>LOS ALAMOS PSJE</td>
                                            <td><a href="mailto:jardin038@neuquen.gov.ar"> jardin038@neuquen.gov.ar </a></td>
                                            <td>PICUN LEUFU</td>
                                            <td>SUR</td>
                                            <td>2942492133</td>
                                            <td><a href="./mapas.php?id=580062100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 12</td>
                                            <td>TIERRA DEL FUEGO 365</td>
                                            <td><a href="mailto:primaria012@neuquen.gov.ar"> primaria012@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421458</td>
                                            <td><a href="./mapas.php?id=580062200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CRISTIANA EVANGÉLICA DE NEUQUEN E.C.E.N. N. MEDIO</td>
                                            <td>RICCHIERI PABLO TTE 1334</td>
                                            <td><a href="mailto:ecendireccion@gmail.com"> ecendireccion@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994400885</td>
                                            <td><a href="./mapas.php?id=580062300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 12</td>
                                            <td>ROCA JULIO A GRL AV 1151</td>
                                            <td><a href="mailto:jardin012@neuquen.gov.ar"> jardin012@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972427150</td>
                                            <td><a href="./mapas.php?id=580062700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 313</td>
                                            <td>QUINQUELA MARTIN BENITO 271</td>
                                            <td><a href="mailto:primaria313@neuquen.gov.ar"> primaria313@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426355</td>
                                            <td><a href="./mapas.php?id=580062800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 40 PICHI RAYEN</td>
                                            <td>BELLA VISTA</td>
                                            <td><a href="mailto:jardin040@neuquen.gov.ar"> jardin040@neuquen.gov.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2948494297</td>
                                            <td><a href="./mapas.php?id=580063000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 41</td>
                                            <td>VILLA PEHUENIA</td>
                                            <td><a href="mailto:jardin041@neuquen.gov.ar"> jardin041@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>2994855019</td>
                                            <td><a href="./mapas.php?id=580063200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 39 SUYAI PEÑI</td>
                                            <td>MENDOZA</td>
                                            <td><a href="mailto:jardin039@neuquen.gov.ar"> jardin039@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994934708</td>
                                            <td><a href="./mapas.php?id=580063400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 39 SUYAI PEÑI ANEXO BARRIO LOS AROMOS</td>
                                            <td>JUJUY 344</td>
                                            <td><a href="mailto:jardin039@neuquen.gov.ar"> jardin039@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994934708</td>
                                            <td><a href="./mapas.php?id=580063401"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 42 PICHI HUENEY</td>
                                            <td>CAYASTA 2075</td>
                                            <td><a href="mailto:jardin042@neuquen.gov.ar"> jardin042@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460351</td>
                                            <td><a href="./mapas.php?id=580063600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 309 KÜMELEN</td>
                                            <td>CUADROS HILARIO 2100</td>
                                            <td><a href="mailto:primaria309@neuquen.gov.ar"> primaria309@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994489094</td>
                                            <td><a href="./mapas.php?id=580063700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 214</td>
                                            <td>RUTA PROVINCIAL 34</td>
                                            <td><a href="mailto:primaria214@neuquen.gov.ar"> primaria214@neuquen.gov.ar </a></td>
                                            <td>LA AMARGA</td>
                                            <td>CENTRO</td>
                                            <td>2994541170</td>
                                            <td><a href="./mapas.php?id=580063900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 275</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria275@neuquen.gov.ar"> primaria275@neuquen.gov.ar </a></td>
                                            <td>EL CHENQUE</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1153</td>
                                            <td><a href="./mapas.php?id=580064000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 315</td>
                                            <td>BROWN ALMTE 480</td>
                                            <td><a href="mailto:primaria315@neuquen.gov.ar"> primaria315@neuquen.gov.ar </a></td>
                                            <td>PIEDRA DEL AGUILA</td>
                                            <td>CENTRO</td>
                                            <td>2942493028</td>
                                            <td><a href="./mapas.php?id=580064100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 316 COMUNIDAD MAPUCHE GRAMAJO</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria316@neuquen.gov.ar"> primaria316@neuquen.gov.ar </a></td>
                                            <td>CARRO QUEBRADO</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1155</td>
                                            <td><a href="./mapas.php?id=580064300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 314 ELVIRA ROSA TÉVES</td>
                                            <td>MISIONES</td>
                                            <td><a href="mailto:primaria314@neuquen.gov.ar"> primaria314@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994887131</td>
                                            <td><a href="./mapas.php?id=580064700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 312</td>
                                            <td>VENADO TUERTO 2080</td>
                                            <td><a href="mailto:primaria312@neuquen.gov.ar"> primaria312@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994465033</td>
                                            <td><a href="./mapas.php?id=580064800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 67</td>
                                            <td>STORNI ALFONSINA 1850</td>
                                            <td><a href="mailto:cpem067@neuquen.gov.ar"> cpem067@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994893785</td>
                                            <td><a href="./mapas.php?id=580064900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 55</td>
                                            <td>RIO DIAMANTE</td>
                                            <td><a href="mailto:cpem55pn@gmail.com"> cpem55pn@gmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994936148</td>
                                            <td><a href="./mapas.php?id=580065000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE DISEÑO EN EL HÁBITAT</td>
                                            <td>OLASCOAGA AV 735</td>
                                            <td><a href="mailto:info@edh.edu.ar"> info@edh.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994420277</td>
                                            <td><a href="./mapas.php?id=580065500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 9</td>
                                            <td>BELGRANO MANUEL GRL AV 1000</td>
                                            <td><a href="mailto:ifd009@neuquen.gov.ar"> ifd009@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994898032</td>
                                            <td><a href="./mapas.php?id=580065700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.PA.HO. SANTA TERESA DE JESÚS</td>
                                            <td>CARMEN DE PATAGONES 450</td>
                                            <td><a href="mailto:cepahosantateresa@yahoo.com.ar"> cepahosantateresa@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423562</td>
                                            <td><a href="./mapas.php?id=580066500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.M.O.E. HUECHE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:huechelascoloradas@yahoo.com.ar"> huechelascoloradas@yahoo.com.ar </a></td>
                                            <td>LAS COLORADAS</td>
                                            <td>CENTRO</td>
                                            <td>2942495038</td>
                                            <td><a href="./mapas.php?id=580067500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 31</td>
                                            <td>BELGRANO MANUEL GRL 2250</td>
                                            <td><a href="mailto:cfp031@neuquen.gov.ar"> cfp031@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994432203</td>
                                            <td><a href="./mapas.php?id=580069900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.M.O.E. MARCELINO CHAMPAGNAT</td>
                                            <td>ANTARTIDA ARGENTINA 1774</td>
                                            <td><a href="mailto:cemoechampagnat@neuquen.gov.ar"> cemoechampagnat@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435223</td>
                                            <td><a href="./mapas.php?id=580070900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.M.O.E. MARCELINO CHAMPAGNAT ANEXO BARRIO SAN LORENZO</td>
                                            <td>CAYASTA</td>
                                            <td><a href="mailto:cemoechampagnat@neuquen.gov.ar"> cemoechampagnat@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435223</td>
                                            <td><a href="./mapas.php?id=580070901"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 311</td>
                                            <td>NECOCHEA 2030</td>
                                            <td><a href="mailto:primaria311@neuquen.gov.ar"> primaria311@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994466607</td>
                                            <td><a href="./mapas.php?id=580071300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 293</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria293@neuquen.gov.ar"> primaria293@neuquen.gov.ar </a></td>
                                            <td>PUENTE PICUN LEUFU</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1108</td>
                                            <td><a href="./mapas.php?id=580071600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA BILINGÜE DANTE ALIGHIERI</td>
                                            <td>BELGRANO MANUEL GRL 476</td>
                                            <td><a href="mailto:danteneuquen@yahoo.com.ar"> danteneuquen@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994429694</td>
                                            <td><a href="./mapas.php?id=580071700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA BILINGÜE DANTE ALIGHIERI ANEXO JARDÍN DE INFANTES</td>
                                            <td>JUJUY 456</td>
                                            <td><a href="mailto:danteneuquen@yahoo.com.ar"> danteneuquen@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994429694</td>
                                            <td><a href="./mapas.php?id=580071701"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 299</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria299@neuquen.gov.ar"> primaria299@neuquen.gov.ar </a></td>
                                            <td>CAJON DEL HUECU</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1134</td>
                                            <td><a href="./mapas.php?id=580071800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DEL SOL NIVEL INICIAL</td>
                                            <td>DIAZ CNL 1021</td>
                                            <td><a href="mailto:secretariajardin@escueladelsolsma.edu.ar"> secretariajardin@escueladelsolsma.edu.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426480</td>
                                            <td><a href="./mapas.php?id=580072100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE ESTUDIOS TERCIARIOS DEL COMAHUE</td>
                                            <td>SANTA FE 250</td>
                                            <td><a href="mailto:info@cetec.edu.ar"> info@cetec.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994481905</td>
                                            <td><a href="./mapas.php?id=580072500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE ESTUDIOS TERCIARIOS DEL COMAHUE ANEXO ZAPALA</td>
                                            <td>ITALIA 828</td>
                                            <td><a href="mailto:ceteczapala@speedy.com.ar"> ceteczapala@speedy.com.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942430615</td>
                                            <td><a href="./mapas.php?id=580072501"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE ESTUDIOS TERCIARIOS DEL COMAHUE ANEXO CUTRAL CO</td>
                                            <td>OLASCOAGA MANUEL JOSE AV 741</td>
                                            <td><a href="mailto:esuarez@cetec.edu.ar"> esuarez@cetec.edu.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994965526</td>
                                            <td><a href="./mapas.php?id=580072502"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 8</td>
                                            <td>HONDURAS</td>
                                            <td><a href="mailto:epa008@neuquen.gov.ar"> epa008@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994894399</td>
                                            <td><a href="./mapas.php?id=580072700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 8 ANEXO AÑELO</td>
                                            <td>CALLE 15</td>
                                            <td><a href="mailto:epa008@neuquen.gov.ar"> epa008@neuquen.gov.ar </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994894399</td>
                                            <td><a href="./mapas.php?id=580072701"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA SUPERIOR DE MÚSICA DEL NEUQUEN</td>
                                            <td>DE ALVEAR MARCELO T BV 90</td>
                                            <td><a href="mailto:esmnqn@neuquen.gov.ar"> esmnqn@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994433200</td>
                                            <td><a href="./mapas.php?id=580073500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>VÍNCULO PRIMERA ESCUELA DE PSICOLOGÍA SOCIAL</td>
                                            <td>ROCA JULIO A GRL 658</td>
                                            <td><a href="mailto:vinculoescuela@yahoo.com.ar"> vinculoescuela@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423748</td>
                                            <td><a href="./mapas.php?id=580073600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 15</td>
                                            <td>COPAHUE 650</td>
                                            <td><a href="mailto:cfp015@neuquen.gov.ar"> cfp015@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942423569</td>
                                            <td><a href="./mapas.php?id=580074000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO MANUEL BELGRANO</td>
                                            <td>SOLALIQUE 1070</td>
                                            <td><a href="mailto:colegiombelgranonqn@yahoo.com.ar"> colegiombelgranonqn@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155778716</td>
                                            <td><a href="./mapas.php?id=580074300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES COPELCO OMAR GREGORIO SANDOVAL</td>
                                            <td>PAZ GRL 250</td>
                                            <td><a href="mailto:jardin_copelco@copelnet.com.ar"> jardin_copelco@copelnet.com.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994962566</td>
                                            <td><a href="./mapas.php?id=580075000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 25</td>
                                            <td>EMMA CARLOS MAESTRO PSJE 965</td>
                                            <td><a href="mailto:cfp025@neuquen.gov.ar"> cfp025@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994437367</td>
                                            <td><a href="./mapas.php?id=580075400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE ENSEÑANZA SUPERIOR CRUZ ROJA ARGENTINA</td>
                                            <td>CUTRAL CO 13</td>
                                            <td><a href="mailto:educa.phuincul@cruzroja.org.ar"> educa.phuincul@cruzroja.org.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994963185</td>
                                            <td><a href="./mapas.php?id=580075500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 2</td>
                                            <td>YUPANQUI ATAHUALPA</td>
                                            <td><a href="mailto:cef002@neuquen.gov.ar; horriveros@gmail.com"> cef002@neuquen.gov.ar; horriveros@gmail.com </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994965468</td>
                                            <td><a href="./mapas.php?id=580075800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 3</td>
                                            <td>PRIMEROS POBLADORES</td>
                                            <td><a href="mailto:cef003@neuquen.gov.ar"> cef003@neuquen.gov.ar </a></td>
                                            <td>PICUN LEUFU</td>
                                            <td>SUR</td>
                                            <td>2942492184</td>
                                            <td><a href="./mapas.php?id=580075900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 5</td>
                                            <td>9 DE JULIO</td>
                                            <td><a href="mailto:cefn5chosmalal@yahoo.com.ar"> cefn5chosmalal@yahoo.com.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948422455</td>
                                            <td><a href="./mapas.php?id=580076100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 6</td>
                                            <td>DEL CAÑADON ESTE AV</td>
                                            <td><a href="mailto:cef6zapala@hotmail.com"> cef6zapala@hotmail.com </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942431067</td>
                                            <td><a href="./mapas.php?id=580076200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 7</td>
                                            <td>LAS FRAMBUESAS</td>
                                            <td><a href="mailto:cef007@neuquen.gov.ar"> cef007@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494722</td>
                                            <td><a href="./mapas.php?id=580076300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 8</td>
                                            <td>MORENO MARIANO</td>
                                            <td><a href="mailto:cef008@neuquen.gov.ar"> cef008@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491098</td>
                                            <td><a href="./mapas.php?id=580076400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 9</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:cef009@neuquen.gov.ar"> cef009@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972424808</td>
                                            <td><a href="./mapas.php?id=580076500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 12</td>
                                            <td>SAN MARTIN GRL AV 344</td>
                                            <td><a href="mailto:cef012@neuquen.gov.ar"> cef012@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994920161</td>
                                            <td><a href="./mapas.php?id=580076800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ARTE 1</td>
                                            <td>AFIONE SEVERINO</td>
                                            <td><a href="mailto:eparten1@yahoo.com.ar"> eparten1@yahoo.com.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942423944</td>
                                            <td><a href="./mapas.php?id=580077300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 11</td>
                                            <td>PETRY MARTIN 534</td>
                                            <td><a href="mailto:cfp011@neuquen.gov.ar"> cfp011@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421890</td>
                                            <td><a href="./mapas.php?id=580077600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 09</td>
                                            <td>OLASCOAGA MANUEL AV 1282</td>
                                            <td><a href="mailto:cfp009@neuquen.gov.ar"> cfp009@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994439714</td>
                                            <td><a href="./mapas.php?id=580077700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 17</td>
                                            <td>OLASCOAGA MANUEL 363</td>
                                            <td><a href="mailto:cfp017@neuquen.gov.ar"> cfp017@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499585</td>
                                            <td><a href="./mapas.php?id=580077800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 20</td>
                                            <td>JAIME DE NEVAREZ Y ATAHUALA YUPANQUI </td>
                                            <td><a href="mailto:cfp020@neuquen.gov.ar"> cfp020@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948422998</td>
                                            <td><a href="./mapas.php?id=580077900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 22</td>
                                            <td>SALTA 650</td>
                                            <td><a href="mailto:cfp022@neuquen.gov.ar"> cfp022@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994965789</td>
                                            <td><a href="./mapas.php?id=580078000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 13</td>
                                            <td>LAGO VIEDMA 5826</td>
                                            <td><a href="mailto:cfp013@neuquen.gov.ar"> cfp013@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994467388</td>
                                            <td><a href="./mapas.php?id=580079100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.I.A. 1</td>
                                            <td>OLASCOAGA AV 56</td>
                                            <td><a href="mailto:cia001@neuquen.gov.ar"> cia001@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155084670</td>
                                            <td><a href="./mapas.php?id=580079500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 26</td>
                                            <td>SARMIENTO DOMINGO F</td>
                                            <td><a href="mailto:cfp026@neuquen.gov.ar"> cfp026@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994966123</td>
                                            <td><a href="./mapas.php?id=580080100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 29</td>
                                            <td>DARRIEUX JUAN B 470</td>
                                            <td><a href="mailto:cfp029@neuquen.gov.ar"> cfp029@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994898762</td>
                                            <td><a href="./mapas.php?id=580080200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 16</td>
                                            <td>SAPAG FELIPE GDOR AV 120</td>
                                            <td><a href="mailto:cfp016@neuquen.gov.ar"> cfp016@neuquen.gov.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2948494204</td>
                                            <td><a href="./mapas.php?id=580080300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 16 ANEXO MANZANO AMARGO</td>
                                            <td>PRIMEROS POBLADORES</td>
                                            <td><a href="mailto:cfp16andacollo@gmail.com"> cfp16andacollo@gmail.com </a></td>
                                            <td>MANZANO AMARGO</td>
                                            <td>NORTE</td>
                                            <td>2948494204</td>
                                            <td><a href="./mapas.php?id=580080301"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA INTEGRAL DE ADOLESCENTES Y JÓVENES CON DISCAPACIDAD 5 TAYIL</td>
                                            <td>LANIN 2150</td>
                                            <td><a href="mailto:tayilnqn@yahoo.com.ar"> tayilnqn@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994452875</td>
                                            <td><a href="./mapas.php?id=580080500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 33</td>
                                            <td>LEVALLE NICOLAS AV</td>
                                            <td><a href="mailto:cfp033@neuquen.gov.ar"> cfp033@neuquen.gov.ar </a></td>
                                            <td>MARIANO MORENO</td>
                                            <td>CENTRO</td>
                                            <td>2942490137</td>
                                            <td><a href="./mapas.php?id=580081000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 14</td>
                                            <td>CHILE</td>
                                            <td><a href="mailto:cfp014@neuquen.gov.ar"> cfp014@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933858</td>
                                            <td><a href="./mapas.php?id=580081200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA INTEGRAL DE ADOLESCENTES Y JÓVENES CON DISCAPACIDAD 2</td>
                                            <td>ELORDI GDOR 1315</td>
                                            <td><a href="mailto:eiaj002@neuquen.gov.ar"> eiaj002@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2995110649</td>
                                            <td><a href="./mapas.php?id=580081500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 01</td>
                                            <td>SANTA CRUZ 742</td>
                                            <td><a href="mailto:cfp001@neuquen.gov.ar"> cfp001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994430874</td>
                                            <td><a href="./mapas.php?id=580081600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 12</td>
                                            <td>INDEPENDENCIA 446</td>
                                            <td><a href="mailto:cfp012@neuquen.gov.ar; cfp_n12@hotmail.com"> cfp012@neuquen.gov.ar; cfp_n12@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994483567</td>
                                            <td><a href="./mapas.php?id=580081700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.I.A. 4</td>
                                            <td>SAN MARTIN</td>
                                            <td><a href="mailto:ciartn4@gmail.com"> ciartn4@gmail.com </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948422251</td>
                                            <td><a href="./mapas.php?id=580082200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE INICIACIÓN ARTÍSTICA 4 ANEXO BUTA RANQUIL</td>
                                            <td>OLASCOAGA</td>
                                            <td><a href="mailto:ciartn4@gmail.com"> ciartn4@gmail.com </a></td>
                                            <td>BUTA RANQUIL</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580082201"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA INTEGRAL DE ADOLESCENTES Y JÓVENES CON DISCAPACIDAD 1 MI FUTURO FELIZ</td>
                                            <td>RAMOS PEDRO</td>
                                            <td><a href="mailto:eiaj001@neuquen.gov.ar"> eiaj001@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994967082</td>
                                            <td><a href="./mapas.php?id=580082500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 27</td>
                                            <td>DON BOSCO AV</td>
                                            <td><a href="mailto:cfp027@neuquen.gov.ar"> cfp027@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421121</td>
                                            <td><a href="./mapas.php?id=580082600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.CA.LAB. 134</td>
                                            <td>MITRE BARTOLOME 675</td>
                                            <td><a href="mailto:jorgecristian@gmail.com"> jorgecristian@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155212115</td>
                                            <td><a href="./mapas.php?id=580083100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.CA.LAB. 59</td>
                                            <td>MITRE BARTOLOME 675</td>
                                            <td><a href="mailto:sainzgustavo@hotmail.com"> sainzgustavo@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994424698</td>
                                            <td><a href="./mapas.php?id=580083300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 30</td>
                                            <td>CANDELARIA TTE 926</td>
                                            <td><a href="mailto:cfp030@neuquen.gov.ar"> cfp030@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942422243</td>
                                            <td><a href="./mapas.php?id=580083500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.CA.LAB. 135</td>
                                            <td>MITRE BARTOLOME 675</td>
                                            <td><a href="mailto:fabianmonzon84@hotmail.com"> fabianmonzon84@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155311450</td>
                                            <td><a href="./mapas.php?id=580083700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CE.CA.LAB. 178</td>
                                            <td>SAN MARTIN AV 593</td>
                                            <td><a href="mailto:epa012@neuquen.gov.ar"> epa012@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994968184</td>
                                            <td><a href="./mapas.php?id=580083900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.E.A. 1</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:cea001@neuquen.gov.ar"> cea001@neuquen.gov.ar </a></td>
                                            <td>LAS COLORADAS</td>
                                            <td>CENTRO</td>
                                            <td>2942495038</td>
                                            <td><a href="./mapas.php?id=580084000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 19</td>
                                            <td>BROWN ALMTE 717</td>
                                            <td><a href="mailto:cfp019@neuquen.gov.ar"> cfp019@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972428891</td>
                                            <td><a href="./mapas.php?id=580084500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 10</td>
                                            <td>CARREÑO GENARO</td>
                                            <td><a href="mailto:cfp010@neuquen.gov.ar"> cfp010@neuquen.gov.ar </a></td>
                                            <td>BUTA RANQUIL</td>
                                            <td>NORTE</td>
                                            <td>2948493238</td>
                                            <td><a href="./mapas.php?id=580084600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 28</td>
                                            <td>ITALIA 969</td>
                                            <td><a href="mailto:cfp028@neuquen.gov.ar"> cfp028@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942431359</td>
                                            <td><a href="./mapas.php?id=580084700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 18</td>
                                            <td>LOS HUINGANES</td>
                                            <td><a href="mailto:cfp018@neuquen.gov.ar"> cfp018@neuquen.gov.ar </a></td>
                                            <td>HUINGANCO</td>
                                            <td>NORTE</td>
                                            <td>2948499049</td>
                                            <td><a href="./mapas.php?id=580084800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 08</td>
                                            <td>BELGRANO MANUEL</td>
                                            <td><a href="mailto:cfp008@neuquen.gov.ar"> cfp008@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>2948498068</td>
                                            <td><a href="./mapas.php?id=580084900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 23</td>
                                            <td>Colon y Mariano Moreno</td>
                                            <td><a href="mailto:cfp023@neuquen.gov.ar"> cfp023@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994890791</td>
                                            <td><a href="./mapas.php?id=580085000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 32</td>
                                            <td>OLASCOAGA 385</td>
                                            <td><a href="mailto:cfp032@neuquen.gov.ar"> cfp032@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td>2942499468</td>
                                            <td><a href="./mapas.php?id=580085300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 34</td>
                                            <td>ALVAREZ GREGORIO DR 449</td>
                                            <td><a href="mailto:cfp034@neuquen.gov.ar"> cfp034@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994920810</td>
                                            <td><a href="./mapas.php?id=580085700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.I.A. 3</td>
                                            <td>SAN MARTIN FELIX 368</td>
                                            <td><a href="mailto:cia003@neuquen.gov.ar"> cia003@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972492177</td>
                                            <td><a href="./mapas.php?id=580085900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 334</td>
                                            <td>ENTRE RIOS</td>
                                            <td><a href="mailto:primaria334@neuquen.gov.ar"> primaria334@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994967952</td>
                                            <td><a href="./mapas.php?id=580086500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 335</td>
                                            <td>DE URQUIZA JUSTO JOSE</td>
                                            <td><a href="mailto:primaria335@neuquen.gov.ar"> primaria335@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886468</td>
                                            <td><a href="./mapas.php?id=580086600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 336 A.L.A.S. PARA VOLAR</td>
                                            <td>LAGO VIEDMA 4745</td>
                                            <td><a href="mailto:primaria336@neuquen.gov.ar"> primaria336@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994462062</td>
                                            <td><a href="./mapas.php?id=580086700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 44</td>
                                            <td>NECOCHEA 1836</td>
                                            <td><a href="mailto:jardin044@neuquen.gov.ar"> jardin044@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994466606</td>
                                            <td><a href="./mapas.php?id=580086900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 21</td>
                                            <td>BELGRANO MANUEL GRL 3385</td>
                                            <td><a href="mailto:cfp021@neuquen.gov.ar"> cfp021@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994450145</td>
                                            <td><a href="./mapas.php?id=580087400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 37</td>
                                            <td>SANCHEZ MODESTO PSJE</td>
                                            <td><a href="mailto:cfp16andacollo@gmail.com"> cfp16andacollo@gmail.com </a></td>
                                            <td>LAS OVEJAS</td>
                                            <td>NORTE</td>
                                            <td>2948494204</td>
                                            <td><a href="./mapas.php?id=580088600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 13 REPÚBLICA DE NICARAGUA NIVEL MEDIO</td>
                                            <td>ITALIA 144</td>
                                            <td><a href="mailto:ifd013medio@neuquen.gov.ar"> ifd013medio@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421309</td>
                                            <td><a href="./mapas.php?id=580088700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 6 NIVEL MEDIO</td>
                                            <td>ILLIA ARTURO 695</td>
                                            <td><a href="mailto:ifd006nivelmedio@neuquen.gov.ar"> ifd006nivelmedio@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994471055</td>
                                            <td><a href="./mapas.php?id=580088800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 12 GRAL JOSÉ DE SAN MARTÍN NIVEL INICIAL</td>
                                            <td>ARGENTINA AV 935</td>
                                            <td><a href="mailto:ifd12inicial@neuquen.gov.ar"> ifd12inicial@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994484080</td>
                                            <td><a href="./mapas.php?id=580088900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 12 GRAL JOSÉ DE SAN MARTÍN NIVEL PRIMARIO</td>
                                            <td>ARGENTINA AV 935</td>
                                            <td><a href="mailto:ifd12primario@neuquen.gov.ar"> ifd12primario@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994424824</td>
                                            <td><a href="./mapas.php?id=580089000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 12 GRAL JOSÉ DE SAN MARTÍN NIVEL MEDIO</td>
                                            <td>ARGENTINA AV 935</td>
                                            <td><a href="mailto:ifd012nivelmedio@neuquen.gov.ar"> ifd012nivelmedio@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994424199</td>
                                            <td><a href="./mapas.php?id=580089100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 24</td>
                                            <td>CERRO BAYO 454</td>
                                            <td><a href="mailto:cfp024@neuquen.gov.ar"> cfp024@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944488483</td>
                                            <td><a href="./mapas.php?id=580089600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 24 ANEXO VILLA TRAFUL</td>
                                            <td>CARPINTERO GIGANTE</td>
                                            <td><a href="mailto:cfp024@neuquen.gov.ar"> cfp024@neuquen.gov.ar </a></td>
                                            <td>VILLA TRAFUL</td>
                                            <td>SUR</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580089601"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE MÚSICA DE JUNÍN DE LOS ANDES</td>
                                            <td>MENDOZA 280</td>
                                            <td><a href="mailto:escmusicajunin@gmail.com"> escmusicajunin@gmail.com </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972492145</td>
                                            <td><a href="./mapas.php?id=580089700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE MÚSICA DE SAN MARTÍN DE LOS ANDES</td>
                                            <td>BIBLIOTECAS POPULARES 74</td>
                                            <td><a href="mailto:escuelademusica@smandes.com.ar"> escuelademusica@smandes.com.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972427343</td>
                                            <td><a href="./mapas.php?id=580089800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 45</td>
                                            <td>RIVADAVIA BERNARDINO</td>
                                            <td><a href="mailto:jardin045@neuquen.gov.ar"> jardin045@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994920544</td>
                                            <td><a href="./mapas.php?id=580089900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 75</td>
                                            <td>SAN MARTIN GRL AV 171</td>
                                            <td><a href="mailto:cpem075@neuquen.gov.ar"> cpem075@neuquen.gov.ar </a></td>
                                            <td>LAS COLORADAS</td>
                                            <td>CENTRO</td>
                                            <td>2942495006</td>
                                            <td><a href="./mapas.php?id=580090100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 73</td>
                                            <td>RUTA PROVINCIAL 6</td>
                                            <td><a href="mailto:cpem073@neuquen.gov.ar"> cpem073@neuquen.gov.ar </a></td>
                                            <td>EL CHOLAR</td>
                                            <td>NORTE</td>
                                            <td>2948492905</td>
                                            <td><a href="./mapas.php?id=580090200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 43 MARÍA ELENA WALSH</td>
                                            <td>MORENO MARIANO 100</td>
                                            <td><a href="mailto:jardin043@neuquen.gov.ar"> jardin043@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972422278</td>
                                            <td><a href="./mapas.php?id=580093300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 341</td>
                                            <td>PAISIL JOSE MARIA 417</td>
                                            <td><a href="mailto:primaria341@neuquen.gov.ar"> primaria341@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494609</td>
                                            <td><a href="./mapas.php?id=580093500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>DIRECCIÓN GENERAL DE EDUCACIÓN Y TRABAJO</td>
                                            <td>BELGRANO MANUEL</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994494200</td>
                                            <td><a href="./mapas.php?id=580093700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ANEXO BIBLIOTECA POPULAR ELIEL ARAGÓN</td>
                                            <td>ASMAR GDOR 1836</td>
                                            <td><a href="mailto:biblioeliel@gmail.com"> biblioeliel@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994431180</td>
                                            <td><a href="./mapas.php?id=580093708"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>A.R.D.E.R. ASOCIACIÓN REGIONAL DEL ENFERMO RENAL</td>
                                            <td>MINAS 1321</td>
                                            <td><a href="mailto:arder_1997@yahoo.com.ar"> arder_1997@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155795079</td>
                                            <td><a href="./mapas.php?id=580093709"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>APADIC ASOCIACIÓN DE PADRES Y AMIGOS DEL DISCAPACITADO</td>
                                            <td>HONDURAS 1810</td>
                                            <td><a href="mailto:apadicnuevaesperanza@hotmail.com"> apadicnuevaesperanza@hotmail.com </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994894521</td>
                                            <td><a href="./mapas.php?id=580093711"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ASOC PROTALLERES DE FORM LABORAL PRODUC Y SERV INTEGRACIÓN</td>
                                            <td>ARGENTINA ANTARTIDA 2385</td>
                                            <td><a href="mailto:eluney2@hotmail.com"> eluney2@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994491200</td>
                                            <td><a href="./mapas.php?id=580093717"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 74</td>
                                            <td>LAS LENGAS 426</td>
                                            <td><a href="mailto:cpem074@neuquen.gov.ar"> cpem074@neuquen.gov.ar </a></td>
                                            <td>CAVIAHUE</td>
                                            <td>NORTE</td>
                                            <td>2948495184</td>
                                            <td><a href="./mapas.php?id=580093800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 342</td>
                                            <td>RIO NEUQUEN</td>
                                            <td><a href="mailto:primaria342@neuquen.gov.ar"> primaria342@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>2994855307</td>
                                            <td><a href="./mapas.php?id=580095100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 343</td>
                                            <td>SALCEDO 3435</td>
                                            <td><a href="mailto:primaria343@neuquen.gov.ar"> primaria343@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994463211</td>
                                            <td><a href="./mapas.php?id=580095200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 344 GLORIA ANDINA GALLARDO</td>
                                            <td>17 DE OCTUBRE</td>
                                            <td><a href="mailto:primaria344@neuquen.gov.ar"> primaria344@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491473</td>
                                            <td><a href="./mapas.php?id=580095300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA VIDA</td>
                                            <td>LAS PALOMAS 245</td>
                                            <td><a href="mailto:secretariaprimaria@escuelavida.edu.ar"> secretariaprimaria@escuelavida.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994469259</td>
                                            <td><a href="./mapas.php?id=580095400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO DOMINGO FAUSTINO SARMIENTO</td>
                                            <td>CABRAL SGTO 131</td>
                                            <td><a href="mailto:colegiodomingofaustinosarmiento@gmail.com"> colegiodomingofaustinosarmiento@gmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994935695</td>
                                            <td><a href="./mapas.php?id=580095500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO LINCOLN</td>
                                            <td>LOS AROMOS</td>
                                            <td><a href="mailto:administracion@colegiolincolnnqn.edu.ar"> administracion@colegiolincolnnqn.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994331286</td>
                                            <td><a href="./mapas.php?id=580095800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO MARÍA AUXILIADORA NIVEL INICIAL Y PRIMARIO</td>
                                            <td>PONTE GINES 451</td>
                                            <td><a href="mailto:imaipjunin@neuquen.gov.ar"> imaipjunin@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491119</td>
                                            <td><a href="./mapas.php?id=580096000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.I.A. 5</td>
                                            <td>MORENO MARIANO 1083</td>
                                            <td><a href="mailto:cia005@neuquen.gov.ar"> cia005@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972425565</td>
                                            <td><a href="./mapas.php?id=580096200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 345 IDENTIDAD NEUQUINA</td>
                                            <td>MISIONES</td>
                                            <td><a href="mailto:primaria345@neuquen.gov.ar"> primaria345@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948422457</td>
                                            <td><a href="./mapas.php?id=580096300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 13 NIVEL INICIAL Y PRIMARIO</td>
                                            <td>ITALIA 144</td>
                                            <td><a href="mailto:ifd013@neuquen.gov.ar"> ifd013@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942421942</td>
                                            <td><a href="./mapas.php?id=580096400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 1</td>
                                            <td>ROCA JULIO A GRL 935</td>
                                            <td><a href="mailto:cef001@neuquen.gov.ar"> cef001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994425711</td>
                                            <td><a href="./mapas.php?id=580096600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 6</td>
                                            <td>COMBATIENTES DE MALVINAS 35</td>
                                            <td><a href="mailto:ne006@neuquen.gov.ar"> ne006@neuquen.gov.ar </a></td>
                                            <td>PIEDRA DEL AGUILA</td>
                                            <td>CENTRO</td>
                                            <td>2942493430</td>
                                            <td><a href="./mapas.php?id=580096800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 1</td>
                                            <td>NOGOYA 2725</td>
                                            <td><a href="mailto:ne001@neuquen.gov.ar"> ne001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994468234</td>
                                            <td><a href="./mapas.php?id=580097000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ALBERGUE PROVINCIAL LAS COLORADAS</td>
                                            <td>ALVAREZ GREGORIO DR 345</td>
                                            <td><a href="mailto:aplascoloradas@neuquen.gov.ar"> aplascoloradas@neuquen.gov.ar </a></td>
                                            <td>LAS COLORADAS</td>
                                            <td>CENTRO</td>
                                            <td>2942495068</td>
                                            <td><a href="./mapas.php?id=580097100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 2</td>
                                            <td>TIERRA DEL FUEGO 365</td>
                                            <td><a href="mailto:ne002@neuquen.gov.ar"> ne002@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>29424018602</td>
                                            <td><a href="./mapas.php?id=580097300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 2 ANEXO MACHO NEGRO</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:ne002@neuquen.gov.ar"> ne002@neuquen.gov.ar </a></td>
                                            <td>BAJA MACHO NEGRO</td>
                                            <td>CENTRO</td>
                                            <td>2994018602</td>
                                            <td><a href="./mapas.php?id=580097301"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 2 ANEXO AGUA DEL OVERO</td>
                                            <td>RUTA PROVINCIAL 20</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>AGUA DEL OVERO</td>
                                            <td>CENTRO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580097302"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>RUPU QUINTULU HUECHE ALBERGUE PARROQUIAL ESTUDIANTIL</td>
                                            <td>REGIMIENTO 4 DE CABALLERIA AV</td>
                                            <td><a href="mailto:belensufan@hotmail.com"> belensufan@hotmail.com </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2994029104</td>
                                            <td><a href="./mapas.php?id=580097600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>TALLER LIHUE</td>
                                            <td>EL CEIBO 1899</td>
                                            <td><a href="mailto:asociacionlihue.nqn@gmail.com"> asociacionlihue.nqn@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994331352</td>
                                            <td><a href="./mapas.php?id=580097900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 68</td>
                                            <td>RIO MALLEO 50</td>
                                            <td><a href="mailto:cpem068@neuquen.gov.ar"> cpem068@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944495435</td>
                                            <td><a href="./mapas.php?id=580098300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA FUENTE SERENA</td>
                                            <td>DRURY CAP 754</td>
                                            <td><a href="mailto:escuela.fuenteserena@hotmail.com"> escuela.fuenteserena@hotmail.com </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972422190</td>
                                            <td><a href="./mapas.php?id=580098500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>RESIDENCIA ESTUDIANTIL CUMELEN DE NIVEL MEDIO</td>
                                            <td>SAPAG FELIPE GDOR AV 135</td>
                                            <td><a href="mailto:secretaria14cumelen@gmail.com"> secretaria14cumelen@gmail.com </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2948494311</td>
                                            <td><a href="./mapas.php?id=580098700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 02</td>
                                            <td>HUERGO LUIS A ING</td>
                                            <td><a href="mailto:cfp002@neuquen.gov.ar"> cfp002@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994413431</td>
                                            <td><a href="./mapas.php?id=580098800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 10</td>
                                            <td>CERRO CHAPELCO 355</td>
                                            <td><a href="mailto:cef010@neuquen.gov.ar"> cef010@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>2994855508</td>
                                            <td><a href="./mapas.php?id=580098900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 14</td>
                                            <td>VILLEGAS CONRADO 810</td>
                                            <td><a href="mailto:cef014@neuquen.gov.ar"> cef014@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2942496064</td>
                                            <td><a href="./mapas.php?id=580099200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTO EDUCATIVO 10 CHACHIN</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:pce010@neuquen.gov.ar"> pce010@neuquen.gov.ar </a></td>
                                            <td>COSTA DEL RIO CHACHIN</td>
                                            <td>SUR</td>
                                            <td>2972417026</td>
                                            <td><a href="./mapas.php?id=580099300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO DE CAPACITACIÓN TÉCNICA SAN JOSÉ OBRERO N. MEDIO</td>
                                            <td>PRIMEROS POBLADORES 1123</td>
                                            <td><a href="mailto:colsanjo58@gmail.com"> colsanjo58@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423957</td>
                                            <td><a href="./mapas.php?id=580099400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 347</td>
                                            <td>CABELLERA DEL FRIO 2300</td>
                                            <td><a href="mailto:primaria347@neuquen.gov.ar"> primaria347@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994451793</td>
                                            <td><a href="./mapas.php?id=580099500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO EDUCATIVO NAYAHUE</td>
                                            <td>BOERR ELISEO 1200</td>
                                            <td><a href="mailto:centronayahue@hotmail.com"> centronayahue@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994400697</td>
                                            <td><a href="./mapas.php?id=580099600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 5</td>
                                            <td>RIO COLORADO 382</td>
                                            <td><a href="mailto:ne005@neuquen.gov.ar"> ne005@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994887414</td>
                                            <td><a href="./mapas.php?id=580099700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 346</td>
                                            <td>CHUBUT</td>
                                            <td><a href="mailto:primaria346@neuquen.gov.ar"> primaria346@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886802</td>
                                            <td><a href="./mapas.php?id=580100100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 6</td>
                                            <td>AMANCAY 620</td>
                                            <td><a href="mailto:ifd006terciario@neuquen.gov.ar"> ifd006terciario@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994429996</td>
                                            <td><a href="./mapas.php?id=580100200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 47</td>
                                            <td>ALPATACO (CORDOBA)</td>
                                            <td><a href="mailto:jardin047@neuquen.gov.ar"> jardin047@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994167254</td>
                                            <td><a href="./mapas.php?id=580100300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO NICOLÁS AVELLANEDA</td>
                                            <td>BELGRANO MANUEL GRL 1408</td>
                                            <td><a href="mailto:secretaria@faena.edu.ar"> secretaria@faena.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994489934</td>
                                            <td><a href="./mapas.php?id=580100400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 46 LUGAR DEL SOL</td>
                                            <td>ASMAR GDOR 1790</td>
                                            <td><a href="mailto:jardin046@neuquen.gov.ar"> jardin046@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994431902</td>
                                            <td><a href="./mapas.php?id=580100500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 15</td>
                                            <td>12 DE JULIO AV</td>
                                            <td><a href="mailto:epet015@neuquen.gov.ar"> epet015@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942422136</td>
                                            <td><a href="./mapas.php?id=580100600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 2</td>
                                            <td>TUCUMAN</td>
                                            <td><a href="mailto:isfdn02@neuquen.gov.ar"> isfdn02@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421199</td>
                                            <td><a href="./mapas.php?id=580100700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 2 ANEXO LAS OVEJAS</td>
                                            <td>RUTA PROVINCIAL 43</td>
                                            <td><a href="mailto:ifd002anexo@neuquen.gov.ar"> ifd002anexo@neuquen.gov.ar </a></td>
                                            <td>LAS OVEJAS</td>
                                            <td>NORTE</td>
                                            <td>2664369398</td>
                                            <td><a href="./mapas.php?id=580100701"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE FORMACIÓN DOCENTE 1</td>
                                            <td>LOS ÑIRES 220</td>
                                            <td><a href="mailto:ifd001@neuquen.gov.ar"> ifd001@neuquen.gov.ar </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994965995</td>
                                            <td><a href="./mapas.php?id=580100800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA SUPERIOR DE COCINEROS PATAGÓNICOS</td>
                                            <td>JUAN XXIII 1255</td>
                                            <td><a href="mailto:info@cocinerospatagonicos.com"> info@cocinerospatagonicos.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994470897</td>
                                            <td><a href="./mapas.php?id=580101100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 348</td>
                                            <td>GOMEZ CASIMIRO 2200</td>
                                            <td><a href="mailto:primaria348@neuquen.gov.ar"> primaria348@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994450508</td>
                                            <td><a href="./mapas.php?id=580101200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 349</td>
                                            <td>SOSA E MSTRO AV</td>
                                            <td><a href="mailto:primaria349@neuquen.gov.ar"> primaria349@neuquen.gov.ar </a></td>
                                            <td>PICUN LEUFU</td>
                                            <td>SUR</td>
                                            <td>2942492178</td>
                                            <td><a href="./mapas.php?id=580101300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA EXPERIMENTAL DE DANZA CONTEMPORÁNEA</td>
                                            <td>PLANAS TEODORO 165</td>
                                            <td><a href="mailto:escueladedanza@muninqn.gov.ar"> escueladedanza@muninqn.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994491215</td>
                                            <td><a href="./mapas.php?id=580101400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO MARÍA AUXILIADORA NIVEL INICIAL Y PRIMARIO</td>
                                            <td>ROCA JULIO A GRL 855</td>
                                            <td><a href="mailto:nivelinicialyprimario@imaneuquen.edu.ar"> nivelinicialyprimario@imaneuquen.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422121</td>
                                            <td><a href="./mapas.php?id=580101600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO DON BOSCO NIVEL MEDIO</td>
                                            <td>CHANETON ABEL 599</td>
                                            <td><a href="mailto:secretariasecundariodonbosco@gmail.com"> secretariasecundariodonbosco@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422229</td>
                                            <td><a href="./mapas.php?id=580101700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>I.F.E.S.</td>
                                            <td>LASTRA J.J. 5600</td>
                                            <td><a href="mailto:informes@ifes.edu.ar"> informes@ifes.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440316</td>
                                            <td><a href="./mapas.php?id=580101800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>I.F.E.S. ANEXO ZAPALA</td>
                                            <td>ITALIA 327</td>
                                            <td><a href="mailto:informes@ifes.edu.ar"> informes@ifes.edu.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2994440316</td>
                                            <td><a href="./mapas.php?id=580101801"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 69 COMPAÑERO CARLOS FUENTEALBA</td>
                                            <td>DELEGADOS TERRITORIALES NQNOS 4900</td>
                                            <td><a href="mailto:cpem069@neuquen.gov.ar"> cpem069@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994452021</td>
                                            <td><a href="./mapas.php?id=580101900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 71</td>
                                            <td>COSTA RICA</td>
                                            <td><a href="mailto:cpem071@neuquen.gov.ar"> cpem071@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994896843</td>
                                            <td><a href="./mapas.php?id=580102000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 48</td>
                                            <td>PERON EVA 275</td>
                                            <td><a href="mailto:jardin048@neuquen.gov.ar"> jardin048@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948422870</td>
                                            <td><a href="./mapas.php?id=580102100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 70</td>
                                            <td>LAS GAVIOTAS 1690</td>
                                            <td><a href="mailto:cpem70@neuquen.gov.ar"> cpem70@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994460391</td>
                                            <td><a href="./mapas.php?id=580102200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO TERAP.EDUCAT.P/NIÑOS Y JOV.C/TRAST.SEVEROS DE LA PER.</td>
                                            <td>CABRAL SGTO</td>
                                            <td><a href="mailto:cetquelluen@neuquen.gov.ar"> cetquelluen@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435194</td>
                                            <td><a href="./mapas.php?id=580102300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 72</td>
                                            <td>PERI GDOR 690</td>
                                            <td><a href="mailto:cpem072@neuquen.gov.ar"> cpem072@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994451172</td>
                                            <td><a href="./mapas.php?id=580102400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 49 DEL SUR</td>
                                            <td>VIVANCO</td>
                                            <td><a href="mailto:jardin049@neuquen.gov.ar"> jardin049@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994400425</td>
                                            <td><a href="./mapas.php?id=580102500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 350</td>
                                            <td>CALLE 1</td>
                                            <td><a href="mailto:primaria350@neuquen.gov.ar"> primaria350@neuquen.gov.ar </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994904188</td>
                                            <td><a href="./mapas.php?id=580102600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 16</td>
                                            <td>AUCA MAHUIDA 1047</td>
                                            <td><a href="mailto:epet016@neuquen.gov.ar"> epet016@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886424</td>
                                            <td><a href="./mapas.php?id=580102700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO MUSICAL MELODÍAS</td>
                                            <td>SOSA JULIO 547</td>
                                            <td><a href="mailto:melodiasinstituto@hotmail.com"> melodiasinstituto@hotmail.com </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421610</td>
                                            <td><a href="./mapas.php?id=580102900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO TERCIARIO SÉNECA</td>
                                            <td>INDEPENDENCIA 744</td>
                                            <td><a href="mailto:info@seneca.edu.ar"> info@seneca.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994471610</td>
                                            <td><a href="./mapas.php?id=580103000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO PANAMERICANO DE ESTUDIOS SUPERIORES</td>
                                            <td>RIVADAVIA BERNARDINO 744</td>
                                            <td><a href="mailto:institucionales.ipes@eidec.com.ar"> institucionales.ipes@eidec.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994429063</td>
                                            <td><a href="./mapas.php?id=580103100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE MÚSICA DE PLOTTIER</td>
                                            <td>MOREAU DE JUSTO ALICIA DRA</td>
                                            <td><a href="mailto:esmplottier@neuquen.gov.ar"> esmplottier@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994937988</td>
                                            <td><a href="./mapas.php?id=580103200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.I.A. 6</td>
                                            <td>HUINGANCO</td>
                                            <td><a href="mailto:cia006@neuquen.gov.ar"> cia006@neuquen.gov.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2948418151</td>
                                            <td><a href="./mapas.php?id=580103300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 351 PIONEROS Y PIONERAS DE PLOTTIER</td>
                                            <td>RIO DIAMANTE 89</td>
                                            <td><a href="mailto:primaria351@neuquen.gov.ar"> primaria351@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994935565</td>
                                            <td><a href="./mapas.php?id=580103400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 17 RODOLFO ALEJANDRO TORRISI</td>
                                            <td>BUFFOLO JOSE</td>
                                            <td><a href="mailto:epet017@neuquen.gov.ar"> epet017@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994453493</td>
                                            <td><a href="./mapas.php?id=580103500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 18</td>
                                            <td>ALVAREZ GREGORIO DR</td>
                                            <td><a href="mailto:epet018@neuquen.gov.ar"> epet018@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994920819</td>
                                            <td><a href="./mapas.php?id=580103600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 76</td>
                                            <td>KILKA 3402</td>
                                            <td><a href="mailto:cpem076@neuquen.gov.ar"> cpem076@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994461496</td>
                                            <td><a href="./mapas.php?id=580103700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 77</td>
                                            <td>DE SAN MARTIN JOSE GRL 5202</td>
                                            <td><a href="mailto:cpem077@neuquen.gov.ar"> cpem077@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440564</td>
                                            <td><a href="./mapas.php?id=580103800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DEL SOL NIVEL MEDIO</td>
                                            <td>RODHE CNL 1068</td>
                                            <td><a href="mailto:secundariadelsol@smandes.com.ar"> secundariadelsol@smandes.com.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972428761</td>
                                            <td><a href="./mapas.php?id=580104000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 352</td>
                                            <td>KOESSLER BERTA 600</td>
                                            <td><a href="mailto:primaria352@neuquen.gov.ar"> primaria352@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972420533</td>
                                            <td><a href="./mapas.php?id=580104100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 353</td>
                                            <td>RIO DEL MACHETE 155</td>
                                            <td><a href="mailto:primaria353@neuquen.gov.ar"> primaria353@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944495949</td>
                                            <td><a href="./mapas.php?id=580104400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 354</td>
                                            <td>SORIANO</td>
                                            <td><a href="mailto:primaria354@neuquen.gov.ar"> primaria354@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299156321304</td>
                                            <td><a href="./mapas.php?id=580104500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 78</td>
                                            <td>GARDIN PADRE 21</td>
                                            <td><a href="mailto:cpem078@neuquen.gov.ar"> cpem078@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421348</td>
                                            <td><a href="./mapas.php?id=580104600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 79</td>
                                            <td>RUTA PROVINCIAL 23</td>
                                            <td><a href="mailto:cpem079@neuquen.gov.ar"> cpem079@neuquen.gov.ar </a></td>
                                            <td>LONCO LUAN</td>
                                            <td>SUR</td>
                                            <td>294215545000</td>
                                            <td><a href="./mapas.php?id=580104700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 80</td>
                                            <td>YUPANQUI ATAHUALPA</td>
                                            <td><a href="mailto:cpem080@neuquen.gov.ar"> cpem080@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948423165</td>
                                            <td><a href="./mapas.php?id=580104800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 81</td>
                                            <td>MATURANO FRANCISCO</td>
                                            <td><a href="mailto:cpem081@neuquen.gov.ar"> cpem081@neuquen.gov.ar </a></td>
                                            <td>BARRANCAS</td>
                                            <td>ANELO</td>
                                            <td>2948482129</td>
                                            <td><a href="./mapas.php?id=580104900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 82</td>
                                            <td>ALUMINE</td>
                                            <td><a href="mailto:cpem082@neuquen.gov.ar"> cpem082@neuquen.gov.ar </a></td>
                                            <td>TRICAO MALAL</td>
                                            <td>NORTE</td>
                                            <td>2942450187</td>
                                            <td><a href="./mapas.php?id=580105000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 83</td>
                                            <td>RUTA PROVINCIAL 29</td>
                                            <td><a href="mailto:cpem083@neuquen.gov.ar"> cpem083@neuquen.gov.ar </a></td>
                                            <td>TAQUIMILAN</td>
                                            <td>NORTE</td>
                                            <td>2948497202</td>
                                            <td><a href="./mapas.php?id=580105100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 84</td>
                                            <td>EL CEREZO</td>
                                            <td><a href="mailto:cpem084@neuquen.gov.ar"> cpem084@neuquen.gov.ar </a></td>
                                            <td>HUINGANCO</td>
                                            <td>NORTE</td>
                                            <td>2948499125</td>
                                            <td><a href="./mapas.php?id=580105200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 17</td>
                                            <td>CERRO BATEA MAHUIDA</td>
                                            <td><a href="mailto:especial017@neuquen.gov.ar"> especial017@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>299154393641</td>
                                            <td><a href="./mapas.php?id=580105300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 18</td>
                                            <td>RIO DEL MACHETE 111</td>
                                            <td><a href="mailto:especial018@neuquen.gov.ar"> especial018@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944495908</td>
                                            <td><a href="./mapas.php?id=580105400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 15</td>
                                            <td>STEFENELLI PADRE</td>
                                            <td><a href="mailto:esc.esp.15.neuquen@gmail.com"> esc.esp.15.neuquen@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994428224</td>
                                            <td><a href="./mapas.php?id=580105500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 16</td>
                                            <td>BELLA VISTA</td>
                                            <td><a href="mailto:especial016@neuquen.gov.ar"> especial016@neuquen.gov.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>294815411435</td>
                                            <td><a href="./mapas.php?id=580105600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CATÓLICA DIOCESANA NUESTRA SEÑORA DE LA GUARDIA</td>
                                            <td>CROUZEILLES CAP 2300</td>
                                            <td><a href="mailto:ecdnsdlaguardia@neuquen.gov.ar"> ecdnsdlaguardia@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994453289</td>
                                            <td><a href="./mapas.php?id=580105700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO NIVEL MEDIO NEUQUEN OESTE</td>
                                            <td>ANTARTIDA ARGENTINA 3955</td>
                                            <td><a href="mailto:colegioadultosnqnoeste@gmail.com"> colegioadultosnqnoeste@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994469745</td>
                                            <td><a href="./mapas.php?id=580105800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO CRISTIANO DE LA VILLA</td>
                                            <td>RUTA PROVINCIAL 13</td>
                                            <td><a href="mailto:ccvmanager@gmail.com"> ccvmanager@gmail.com </a></td>
                                            <td>VILLA PEHUENIA</td>
                                            <td>SUR</td>
                                            <td>2942498130</td>
                                            <td><a href="./mapas.php?id=580105900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO SAN PABLO APÓSTOL NIVEL MEDIO</td>
                                            <td>DE GINGINS CJON 285</td>
                                            <td><a href="mailto:secundaria@sanpablo.edu.ar"> secundaria@sanpablo.edu.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972426204</td>
                                            <td><a href="./mapas.php?id=580106000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO SUPERIOR EN SEGURIDAD</td>
                                            <td>CHUBUT 234</td>
                                            <td><a href="mailto:isspolicia@neuquen.gov.ar"> isspolicia@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994434367</td>
                                            <td><a href="./mapas.php?id=580106200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 19</td>
                                            <td>RIO DIAMANTE 304</td>
                                            <td><a href="mailto:epet019@neuquen.gov.ar"> epet019@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994934379</td>
                                            <td><a href="./mapas.php?id=580106500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 20</td>
                                            <td>LANIN 2036</td>
                                            <td><a href="mailto:epet020@neuquen.gov.ar"> epet020@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994478052</td>
                                            <td><a href="./mapas.php?id=580106600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 50</td>
                                            <td>ORTEGA Y GASSET</td>
                                            <td><a href="mailto:jardin050@neuquen.gov.ar"> jardin050@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994468177</td>
                                            <td><a href="./mapas.php?id=580106700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 03</td>
                                            <td>EL MAIZ</td>
                                            <td><a href="mailto:cfp003@neuquen.gov.ar"> cfp003@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155878727</td>
                                            <td><a href="./mapas.php?id=580106800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CRISTIANA VIDA NIVEL MEDIO</td>
                                            <td>LAS PALOMAS 245</td>
                                            <td><a href="mailto:secundariavida@neuquen.gov.ar"> secundariavida@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994469259</td>
                                            <td><a href="./mapas.php?id=580106900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 51</td>
                                            <td>CARREÑO GENARO</td>
                                            <td><a href="mailto:jardin051@neuquen.gov.ar"> jardin051@neuquen.gov.ar </a></td>
                                            <td>BUTA RANQUIL</td>
                                            <td>NORTE</td>
                                            <td>2948493096</td>
                                            <td><a href="./mapas.php?id=580107100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA INTEGRAL DE ADOLESCENTES Y JÓVENES CON DISCAPACIDAD 3</td>
                                            <td>LAS RETAMAS 364</td>
                                            <td><a href="mailto:eiaj003@neuquen.gov.ar"> eiaj003@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972420424</td>
                                            <td><a href="./mapas.php?id=580107200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 85</td>
                                            <td>DE ROSAS JUAN MANUEL 100</td>
                                            <td><a href="mailto:cpem085@neuquen.gov.ar"> cpem085@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994962026</td>
                                            <td><a href="./mapas.php?id=580107400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DEL SOL NIVEL PRIMARIO</td>
                                            <td>ROHDE CNL 1068</td>
                                            <td><a href="mailto:secretaria@escueladelsolsma.edu.ar"> secretaria@escueladelsolsma.edu.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972428761</td>
                                            <td><a href="./mapas.php?id=580107500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 11</td>
                                            <td>HUINGANCO</td>
                                            <td><a href="mailto:cef011@neuquen.gov.ar"> cef011@neuquen.gov.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td>2948494444</td>
                                            <td><a href="./mapas.php?id=580107600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 19</td>
                                            <td>CALLE 131</td>
                                            <td><a href="mailto:especial019@neuquen.gov.ar"> especial019@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>299156286859</td>
                                            <td><a href="./mapas.php?id=580107700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 3</td>
                                            <td>CAYASTA 1100</td>
                                            <td><a href="mailto:ne003@neuquen.gov.ar"> ne003@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994469384</td>
                                            <td><a href="./mapas.php?id=580107800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO TECNOLÓGICO PATAGONIA</td>
                                            <td>FOTHERINGHAM 334</td>
                                            <td><a href="mailto:consultas@itpneuquen.edu.ar"> consultas@itpneuquen.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994478626</td>
                                            <td><a href="./mapas.php?id=580107900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE CAPACITACIÓN Y EXTENSIÓN</td>
                                            <td>BELGRANO MANUEL GRL 1408</td>
                                            <td><a href="mailto:info@iuce.edu.ar"> info@iuce.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994428405</td>
                                            <td><a href="./mapas.php?id=580108100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES AIKE</td>
                                            <td>LOTE 2 FRACCION C6</td>
                                            <td><a href="mailto:direccionvalledelsol@yahoo.com.ar"> direccionvalledelsol@yahoo.com.ar </a></td>
                                            <td>CHINA MUERTA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154606800</td>
                                            <td><a href="./mapas.php?id=580108200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES CAPRICHITOS</td>
                                            <td>12 DE JULIO AV 679</td>
                                            <td><a href="mailto:jardincaprichitoszap@hotmail.com"> jardincaprichitoszap@hotmail.com </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942432032</td>
                                            <td><a href="./mapas.php?id=580108400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 355</td>
                                            <td>MOQUEHUE PSJE</td>
                                            <td><a href="mailto:primaria355@neuquen.gov.ar"> primaria355@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994887642</td>
                                            <td><a href="./mapas.php?id=580108700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 52 SOLES DEL FUTURO</td>
                                            <td>LOS HORNEROS (CALLE 5)</td>
                                            <td><a href="mailto:jardin052@neuquen.gov.ar"> jardin052@neuquen.gov.ar </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994904019</td>
                                            <td><a href="./mapas.php?id=580108900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CASA NUEVO NAZARET</td>
                                            <td>DRURY CAP 754</td>
                                            <td><a href="mailto:hogarnuevonazaretsma@gmail.com"> hogarnuevonazaretsma@gmail.com </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972410433</td>
                                            <td><a href="./mapas.php?id=580109000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 53</td>
                                            <td>QUINQUELA MARTIN BENITO</td>
                                            <td><a href="mailto:jardin053@neuquen.gov.ar"> jardin053@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972412446</td>
                                            <td><a href="./mapas.php?id=580109100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 54</td>
                                            <td>ACUÑA MARIO</td>
                                            <td><a href="mailto:jardin054@neuquen.gov.ar"> jardin054@neuquen.gov.ar </a></td>
                                            <td>LAS OVEJAS</td>
                                            <td>NORTE</td>
                                            <td>2948481030</td>
                                            <td><a href="./mapas.php?id=580109200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 55</td>
                                            <td>FORMOSA</td>
                                            <td><a href="mailto:jardin055@neuquen.gov.ar"> jardin055@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580109300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 56</td>
                                            <td>VALENZUELA SAMUEL</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580109400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE EDUCACIÓN MEDIA DON JAIME DE NEVARES</td>
                                            <td>CERRO BELVEDERE 472</td>
                                            <td><a href="mailto:secundariajaimenevares@neuquen.gov.ar"> secundariajaimenevares@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494504</td>
                                            <td><a href="./mapas.php?id=580109800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO SUPERIOR DE ESTUDIOS INTERDISCIPLINARIOS (I.S.E.I.)</td>
                                            <td>ANTARTIDA ARGENTINA 3955</td>
                                            <td><a href="mailto:institutosuperiorisei@gmail.com"> institutosuperiorisei@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994469745</td>
                                            <td><a href="./mapas.php?id=580109900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE ESTUDIOS PARA EL DESARROLLO ECONÓMICO DE LA PATAGONIA (CEDEP)</td>
                                            <td>FOTHERINGHAM 346</td>
                                            <td><a href="mailto:institutocedep@cedep.edu.ar"> institutocedep@cedep.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994436359</td>
                                            <td><a href="./mapas.php?id=580110100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 87</td>
                                            <td>BELGRANO MANUEL GRL AV 1000</td>
                                            <td><a href="mailto:cpem087@neuquen.gov.ar"> cpem087@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891117</td>
                                            <td><a href="./mapas.php?id=580110200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO SI JOLIE DE EDUCACIÓN SUPERIOR Y FORMACIÓN PROFESIONAL</td>
                                            <td>JUJUY 156</td>
                                            <td><a href="mailto:secretariasijolie@yahoo.com.ar"> secretariasijolie@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994427914</td>
                                            <td><a href="./mapas.php?id=580110400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 57 HUENI HUE</td>
                                            <td>RIO CODIHUE 75</td>
                                            <td><a href="mailto:jardin057@neuquen.gov.ar"> jardin057@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494720</td>
                                            <td><a href="./mapas.php?id=580110500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 58</td>
                                            <td>ESTRELLA DE NEUQUEN</td>
                                            <td><a href="mailto:jardin058@neuquen.gov.ar"> jardin058@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994570700</td>
                                            <td><a href="./mapas.php?id=580110600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL DE SERVICIOS MÚLTIPLES 20</td>
                                            <td>LANIN 2088</td>
                                            <td><a href="mailto:especial020@neuquen.gov.ar"> especial020@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994422205</td>
                                            <td><a href="./mapas.php?id=580110700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTO 7</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:pce007@neuquen.gov.ar"> pce007@neuquen.gov.ar </a></td>
                                            <td>LA MATANSILLA</td>
                                            <td>NORTE</td>
                                            <td>2942592679</td>
                                            <td><a href="./mapas.php?id=580110800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTO 7 ANEXO VILLU MALLIN</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:pce007@neuquen.gov.ar"> pce007@neuquen.gov.ar </a></td>
                                            <td>VILLU MALLIN</td>
                                            <td>NORTE</td>
                                            <td>2942592679</td>
                                            <td><a href="./mapas.php?id=580110801"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 356</td>
                                            <td>CALLE 7</td>
                                            <td><a href="mailto:primaria356@neuquen.gov.ar"> primaria356@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154728155</td>
                                            <td><a href="./mapas.php?id=580110900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO SUPERIOR DE INFORMÁTICA DEL VALLE</td>
                                            <td>SAN LUIS 325</td>
                                            <td><a href="mailto:direccion@institutoisiv.edu.ar"> direccion@institutoisiv.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994483612</td>
                                            <td><a href="./mapas.php?id=580111000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 04</td>
                                            <td>MAIZANI AZUCENA AV 670</td>
                                            <td><a href="mailto:cfp004@neuquen.gov.ar"> cfp004@neuquen.gov.ar </a></td>
                                            <td>PLAZA HUINCUL</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299156563164</td>
                                            <td><a href="./mapas.php?id=580111100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 05</td>
                                            <td>BUSTOS PEREZ JOSE</td>
                                            <td><a href="mailto:cfp005@neuquen.gov.ar"> cfp005@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440314</td>
                                            <td><a href="./mapas.php?id=580111200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 05 ANEXO AÑELO</td>
                                            <td>RUTA PROVINCIAL 17</td>
                                            <td><a href="mailto:centrodeformacionprofesional5@hotmail.com"> centrodeformacionprofesional5@hotmail.com </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994440314</td>
                                            <td><a href="./mapas.php?id=580111201"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 06 U.O.C.R.A.</td>
                                            <td>GONZALEZ MTRO 450</td>
                                            <td><a href="mailto:cfp006@neuquen.gov.ar"> cfp006@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994474995</td>
                                            <td><a href="./mapas.php?id=580111300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE LOS ANDES</td>
                                            <td>RIO MINERO 189</td>
                                            <td><a href="mailto:secretaria@escueladelosandes.com.ar"> secretaria@escueladelosandes.com.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944488488</td>
                                            <td><a href="./mapas.php?id=580111400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 59 COYUÑWE</td>
                                            <td>MAMA MARGARITA</td>
                                            <td><a href="mailto:jardin059@neuquen.gov.ar"> jardin059@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994891286</td>
                                            <td><a href="./mapas.php?id=580111500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES PEQUEÑOS INVESTIGADORES DE LA PATAGONIA</td>
                                            <td>PULMARI 65</td>
                                            <td><a href="mailto:jardinpip@hotmail.com"> jardinpip@hotmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994932181</td>
                                            <td><a href="./mapas.php?id=580111600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA NEUQUEN OESTE</td>
                                            <td>ANTARTIDA ARGENTINA 3955</td>
                                            <td><a href="mailto:primarianqnoeste@hotmail.com"> primarianqnoeste@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994469745</td>
                                            <td><a href="./mapas.php?id=580111700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 21 DE SERVICIOS MÚLTIPLES</td>
                                            <td>ALVAREZ GREGORIO DR</td>
                                            <td><a href="mailto:especial021@neuquen.gov.ar"> especial021@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994921002</td>
                                            <td><a href="./mapas.php?id=580111800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 88</td>
                                            <td>RUTA PROVINCIAL 7 KM 7</td>
                                            <td><a href="mailto:cpem088@neuquen.gov.ar"> cpem088@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994412907</td>
                                            <td><a href="./mapas.php?id=580111900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 21</td>
                                            <td>RUTA PROVINCIAL 48 KM 2</td>
                                            <td><a href="mailto:epet021@neuquen.gov.ar"> epet021@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972411691</td>
                                            <td><a href="./mapas.php?id=580112000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 7 ALUMINE</td>
                                            <td>ALVAREZ GREGORIO 536</td>
                                            <td><a href="mailto:ne007@neuquen.gov.ar"> ne007@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2942496106</td>
                                            <td><a href="./mapas.php?id=580112100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA AGROPECUARIA 3</td>
                                            <td>PICADA 5 NORTE</td>
                                            <td><a href="mailto:epea003@neuquen.gov.ar"> epea003@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>299155239364</td>
                                            <td><a href="./mapas.php?id=580112300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 358</td>
                                            <td>GUILLEN NICOLAS</td>
                                            <td><a href="mailto:primaria358@neuquen.gov.ar"> primaria358@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994870733</td>
                                            <td><a href="./mapas.php?id=580112400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA INTEGRAL DE ADOLESCENTES Y JÓVENES CON DISCAPACIDAD 4</td>
                                            <td>25 DE MAYO 175</td>
                                            <td><a href="mailto:laboralespecial@yahoo.com.ar"> laboralespecial@yahoo.com.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994938028</td>
                                            <td><a href="./mapas.php?id=580112500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA INTEGRAL DE ADOLESCENTES Y JÓVENES CON DISCAPACIDAD 6</td>
                                            <td>ELORDI GDOR 1315</td>
                                            <td><a href="mailto:eiaj006@neuquen.gov.ar"> eiaj006@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994474228</td>
                                            <td><a href="./mapas.php?id=580112600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>POTENCIAR EDUCACIÓN SUPERIOR</td>
                                            <td>BUENOS AIRES 57</td>
                                            <td><a href="mailto:laura.buduba@fundacionpotenciar.org"> laura.buduba@fundacionpotenciar.org </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2995722098</td>
                                            <td><a href="./mapas.php?id=580112800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 13</td>
                                            <td>BUSTOS PEREZ JOSE 784</td>
                                            <td><a href="mailto:cef013@neuquen.gov.ar"> cef013@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440166</td>
                                            <td><a href="./mapas.php?id=580112900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>I.F.E.S. COLEGIO SECUNDARIO</td>
                                            <td>LASTRA J.J. 5600</td>
                                            <td><a href="mailto:secretariasecundarioneuquen@ifes.edu.ar"> secretariasecundarioneuquen@ifes.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440307</td>
                                            <td><a href="./mapas.php?id=580113100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 60</td>
                                            <td>EL HOYO</td>
                                            <td><a href="mailto:jardin060@neuquen.gov.ar"> jardin060@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580113200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 61</td>
                                            <td>LOTE B MZA 12</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580113300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 63</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:jardin063@neuquen.gov.ar"> jardin063@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972411690</td>
                                            <td><a href="./mapas.php?id=580113500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO EDUCATIVO COMUNITARIO-ESCUELA DE GESTIÓN SOCIAL</td>
                                            <td>LOS CONDORES (PEHUENCO) 470</td>
                                            <td><a href="mailto:cecnivelprimario@gmail.com"> cecnivelprimario@gmail.com </a></td>
                                            <td>VILLA PEHUENIA</td>
                                            <td>SUR</td>
                                            <td>294215519029</td>
                                            <td><a href="./mapas.php?id=580113600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 15</td>
                                            <td>JADULL JOSE AV</td>
                                            <td><a href="mailto:cef.15.nqn@gmail.com"> cef.15.nqn@gmail.com </a></td>
                                            <td>BUTA RANQUIL</td>
                                            <td>NORTE</td>
                                            <td>2948493199</td>
                                            <td><a href="./mapas.php?id=580113800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO LÍDER</td>
                                            <td>RICCHIERI PABLO 435</td>
                                            <td><a href="mailto:secretaria@colegiolider.com.ar"> secretaria@colegiolider.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994436714</td>
                                            <td><a href="./mapas.php?id=580113900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO DE EDUCACIÓN SUPERIOR LOS CEREZOS SUR</td>
                                            <td>ANDALGALA 304</td>
                                            <td><a href="mailto:institutoloscerezossur@gmail.com"> institutoloscerezossur@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994469635</td>
                                            <td><a href="./mapas.php?id=580114100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 16</td>
                                            <td>LAINEZ MANUEL</td>
                                            <td><a href="mailto:cef016@neuquen.gov.ar"> cef016@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2996286585</td>
                                            <td><a href="./mapas.php?id=580114300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 07 DEL AULA A LA VIDA</td>
                                            <td>RUTA PROVINCIAL 6</td>
                                            <td><a href="mailto:cfp007@neuquen.gov.ar"> cfp007@neuquen.gov.ar </a></td>
                                            <td>EL CHOLAR</td>
                                            <td>NORTE</td>
                                            <td>2948492904</td>
                                            <td><a href="./mapas.php?id=580114400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO I.S.I. COLLEGE</td>
                                            <td>BELGRANO MANUEL GRL 516</td>
                                            <td><a href="mailto:colegio@isicollege.edu.ar"> colegio@isicollege.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994484812</td>
                                            <td><a href="./mapas.php?id=580114500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO NUESTRA SEÑORA DEL ROSARIO DE SAN NICOLÁS</td>
                                            <td>12 DE JULIO AV 679</td>
                                            <td><a href="mailto:jardincaprichitoszap@hotmail.com"> jardincaprichitoszap@hotmail.com </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942432032</td>
                                            <td><a href="./mapas.php?id=580114600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES Y MATERNAL ROSARIO VERA PEÑALOZA</td>
                                            <td>OBEID GABRIEL 414</td>
                                            <td><a href="mailto:jardinrosariovera@smandes.com.ar"> jardinrosariovera@smandes.com.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972410965</td>
                                            <td><a href="./mapas.php?id=580114800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 22</td>
                                            <td>SADOSKY MANUEL 322</td>
                                            <td><a href="mailto:epet022@neuquen.gov.ar"> epet022@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994876327</td>
                                            <td><a href="./mapas.php?id=580114900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CRISTIANA DESCUBRIR NIVEL INICIAL</td>
                                            <td>PERON JUAN D PTE 380</td>
                                            <td><a href="mailto:jardindescubrirrdls@hotmail.com"> jardindescubrirrdls@hotmail.com </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886082</td>
                                            <td><a href="./mapas.php?id=580115000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CRISTIANA DESCUBRIR NIVEL PRIMARIO</td>
                                            <td>PERON JUAN D PTE 380</td>
                                            <td><a href="mailto:escuelarincon2013@hotmail.com"> escuelarincon2013@hotmail.com </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886082</td>
                                            <td><a href="./mapas.php?id=580115100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CRISTIANA DESCUBRIR NIVEL MEDIO</td>
                                            <td>PERON JUAN D PTE 380</td>
                                            <td><a href="mailto:nivelmediodescubrir@gmail.com"> nivelmediodescubrir@gmail.com </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994886082</td>
                                            <td><a href="./mapas.php?id=580115200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 17</td>
                                            <td>LOS CERRITOS</td>
                                            <td><a href="mailto:cef017@neuquen.gov.ar"> cef017@neuquen.gov.ar </a></td>
                                            <td>PIEDRA DEL AGUILA</td>
                                            <td>CENTRO</td>
                                            <td>2942493699</td>
                                            <td><a href="./mapas.php?id=580115400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO MILLARAY NIVEL PRIMARIO</td>
                                            <td>ACONCAGUA 60</td>
                                            <td><a href="mailto:primariamillaray@yahoo.com.ar"> primariamillaray@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994480921</td>
                                            <td><a href="./mapas.php?id=580115700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA VALLE DEL SOL</td>
                                            <td>LOTE 2 FRACCION C6</td>
                                            <td><a href="mailto:direccionvalledelsol@yahoo.com.ar"> direccionvalledelsol@yahoo.com.ar </a></td>
                                            <td>CHINA MUERTA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154210680</td>
                                            <td><a href="./mapas.php?id=580115800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 64</td>
                                            <td>COMAHUE</td>
                                            <td><a href="mailto:jardin064@neuquen.gov.ar"> jardin064@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994404166</td>
                                            <td><a href="./mapas.php?id=580116000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>TALLER DIDÁCTICO</td>
                                            <td>ELORDI GDOR 1385</td>
                                            <td><a href="mailto:tallerdidacticonqn@hotmail.com"> tallerdidacticonqn@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994472752</td>
                                            <td><a href="./mapas.php?id=580116100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO MILLARAY NIVEL MEDIO</td>
                                            <td>ACONCAGUA 60</td>
                                            <td><a href="mailto:colegio.millaray@yahoo.com.ar"> colegio.millaray@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994480921</td>
                                            <td><a href="./mapas.php?id=580116300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES Y MATERNAL MOVERSE EN LIBERTAD</td>
                                            <td>LOS CIPRESES 1540</td>
                                            <td><a href="mailto:moverseenlibertad@smandes.com.ar"> moverseenlibertad@smandes.com.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972421857</td>
                                            <td><a href="./mapas.php?id=580116400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 359 GUSTAVO ROLDÁN</td>
                                            <td>LOS LAGOS AV 1729</td>
                                            <td><a href="mailto:primaria359@neuquen.gov.ar"> primaria359@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972414821</td>
                                            <td><a href="./mapas.php?id=580116600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO TRINIDAD - NIVEL INICIAL</td>
                                            <td>CARMEN DE PATAGONES 125</td>
                                            <td><a href="mailto:colegiotrinidad@live.com"> colegiotrinidad@live.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994485701</td>
                                            <td><a href="./mapas.php?id=580116700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA ESPECIAL 22 DE SERVICIOS MÚLTIPLES</td>
                                            <td>BATISTI DE PELAEZ 1409</td>
                                            <td><a href="mailto:escuelaespecial22.neuquen@gmail.com"> escuelaespecial22.neuquen@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994477561</td>
                                            <td><a href="./mapas.php?id=580116900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA CRISTIANA EVANGÉLICA DE NEUQUEN</td>
                                            <td>ALVAREZ GREGORIO DR 1209</td>
                                            <td><a href="mailto:senillosa@fecen.edu.ar"> senillosa@fecen.edu.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154766091</td>
                                            <td><a href="./mapas.php?id=580117000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO MILLARAY NIVEL INICIAL</td>
                                            <td>ACONCAGUA 60</td>
                                            <td><a href="mailto:colegio_millaray@yahoo.com.ar"> colegio_millaray@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994480698</td>
                                            <td><a href="./mapas.php?id=580117100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 65 TUTÚ MARAMBÁ</td>
                                            <td>REPUBLICA DE ITALIA 3200</td>
                                            <td><a href="mailto:jardin065@neuquen.gov.ar"> jardin065@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994462536</td>
                                            <td><a href="./mapas.php?id=580117400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA NUEVO MUNDO</td>
                                            <td>DE SAN MARTIN JOSE GRL 2802</td>
                                            <td><a href="mailto:escuelanuevomundo@yahoo.com.ar"> escuelanuevomundo@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994450232</td>
                                            <td><a href="./mapas.php?id=580117600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO RESEARCHERS</td>
                                            <td>LAINEZ MANUEL 55</td>
                                            <td><a href="mailto:jardinpip@yahoo.com.ar"> jardinpip@yahoo.com.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994935638</td>
                                            <td><a href="./mapas.php?id=580117700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO CRISTIANO EVANGÉLICO BAUTISTA LUZ Y ESPERANZA</td>
                                            <td>KOESSLER AV 1820</td>
                                            <td><a href="mailto:colegio@iceble.com.ar"> colegio@iceble.com.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972427693</td>
                                            <td><a href="./mapas.php?id=580117800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES CORDERITO BLANCO</td>
                                            <td>RICCHIERI PABLO TTE 1334</td>
                                            <td><a href="mailto:jardincorderitoblanco@hotmail.com"> jardincorderitoblanco@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994400885</td>
                                            <td><a href="./mapas.php?id=580117900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO EDUCATIVO ESPECIAL INTEGRADOR DEL SOL NIVEL MEDIO</td>
                                            <td>PUERTO GABOTO 4843</td>
                                            <td><a href="mailto:secundarioceidelsol@neuquen.gov.ar"> secundarioceidelsol@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994192520</td>
                                            <td><a href="./mapas.php?id=580118000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO NEUQUEN OESTE NIVEL MEDIO COMÚN</td>
                                            <td>ANTARTIDA ARGENTINA 3955</td>
                                            <td><a href="mailto:colegionqnoestenmcomun@neuquen.gov.ar"> colegionqnoestenmcomun@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994453856</td>
                                            <td><a href="./mapas.php?id=580118100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO TRINIDAD - NIVEL PRIMARIO</td>
                                            <td>CARMEN DE PATAGONES 125</td>
                                            <td><a href="mailto:colegiotrinidad@live.com"> colegiotrinidad@live.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994485701</td>
                                            <td><a href="./mapas.php?id=580118200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO SUPERIOR C.E.I. CENTRO DE ESTUDIOS INTEGRADOS</td>
                                            <td>BALLESTER INGENIERO 497</td>
                                            <td><a href="mailto:iscei@hotmail.com"> iscei@hotmail.com </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994894901</td>
                                            <td><a href="./mapas.php?id=580118300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE LA ESTEPA</td>
                                            <td>PONTE GINES 331</td>
                                            <td><a href="mailto:escueladelaestepa@hotmail.com"> escueladelaestepa@hotmail.com </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972492191</td>
                                            <td><a href="./mapas.php?id=580118400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO LINCOLN - NIVEL MEDIO</td>
                                            <td>LOS AROMOS</td>
                                            <td><a href="mailto:inivelmedio@colegiolincolnnqn.edu.ar"> inivelmedio@colegiolincolnnqn.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994331286</td>
                                            <td><a href="./mapas.php?id=580118500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 89</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:cpem089@neuquen.gov.ar"> cpem089@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2995786530</td>
                                            <td><a href="./mapas.php?id=580118600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE LOS ANDES - NIVEL MEDIO</td>
                                            <td>RIO MINERO 189</td>
                                            <td><a href="mailto:direccion@escueladelosandes.com.ar"> direccion@escueladelosandes.com.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944488488</td>
                                            <td><a href="./mapas.php?id=580118800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>I.F.E.S. COLEGIO SECUNDARIO</td>
                                            <td>ZABALETA M AV 1005</td>
                                            <td><a href="mailto:secundarioplottier@ifes.edu.ar"> secundarioplottier@ifes.edu.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155461016</td>
                                            <td><a href="./mapas.php?id=580118900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO I.F.E.S. NIVEL INICIAL Y PRIMARIO</td>
                                            <td>03-008 1035</td>
                                            <td><a href="mailto:direccionprimario@ifes.edu.ar"> direccionprimario@ifes.edu.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155461016</td>
                                            <td><a href="./mapas.php?id=580119000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 361</td>
                                            <td>LAS FRAMBUESAS</td>
                                            <td><a href="mailto:primaria361@neuquen.gov.ar"> primaria361@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944495706</td>
                                            <td><a href="./mapas.php?id=580119100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO SAGRADO CORAZÓN - INICIAL Y PRIMARIO</td>
                                            <td>OBRERO ARGENTINO 86</td>
                                            <td><a href="mailto:gustavopombo1966@gmail.com"> gustavopombo1966@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994404391</td>
                                            <td><a href="./mapas.php?id=580119300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>IFSSA INSTITUTO DE FORMACIÓN SUPERIOR</td>
                                            <td>MORENO PERITO 635</td>
                                            <td><a href="mailto:info@ifssa.edu.ar"> info@ifssa.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299156262767</td>
                                            <td><a href="./mapas.php?id=580119400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 90</td>
                                            <td>LOS CONDORES (PEHUENCO) 470</td>
                                            <td><a href="mailto:cpem090@neuquen.gov.ar"> cpem090@neuquen.gov.ar </a></td>
                                            <td>VILLA PEHUENIA</td>
                                            <td>SUR</td>
                                            <td>299155904294</td>
                                            <td><a href="./mapas.php?id=580119500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA DE EDUCACIÓN DOMICILIARIA Y HOSPITALARIA 1</td>
                                            <td>CALLE 4</td>
                                            <td><a href="mailto:escueladomiciliariayhospitalaria1@hotmail.com"> escueladomiciliariayhospitalaria1@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994471403</td>
                                            <td><a href="./mapas.php?id=580119700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 362</td>
                                            <td>BARROS NESTOR</td>
                                            <td><a href="mailto:primaria362@neuquen.gov.ar"> primaria362@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155779922</td>
                                            <td><a href="./mapas.php?id=580119800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 66</td>
                                            <td>SIN NOMBRE (CALLE 7)</td>
                                            <td><a href="mailto:jardin066@neuquen.gov.ar"> jardin066@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994194204</td>
                                            <td><a href="./mapas.php?id=580119900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES COLEGIO BAUTISTA</td>
                                            <td>SANTIAGO DEL ESTERO 330</td>
                                            <td><a href="mailto:jardinsecretaria@amen.org.ar"> jardinsecretaria@amen.org.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994434260</td>
                                            <td><a href="./mapas.php?id=580120000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 67</td>
                                            <td>RUCA CHOROY</td>
                                            <td><a href="mailto:jardin067@neuquen.gov.ar"> jardin067@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580120100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 360</td>
                                            <td>HONDURAS 750</td>
                                            <td><a href="mailto:primaria360@neuquen.gov.ar"> primaria360@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994875838</td>
                                            <td><a href="./mapas.php?id=580120200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 363</td>
                                            <td>ALPATACO</td>
                                            <td><a href="mailto:primaria363@neuquen.gov.ar"> primaria363@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2996302335</td>
                                            <td><a href="./mapas.php?id=580120300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>IDEAN</td>
                                            <td>SANTA FE 345</td>
                                            <td><a href="mailto:institutoidean@gmail.com"> institutoidean@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2995039997</td>
                                            <td><a href="./mapas.php?id=580120700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>RESIDENCIA ESTUDIANTIL DE NIVEL MEDIO DE TAQUIMILAN</td>
                                            <td>RUTA PROVINCIAL 29</td>
                                            <td><a href="mailto:residenciaestudtaquimilan@gmail.com"> residenciaestudtaquimilan@gmail.com </a></td>
                                            <td>TAQUIMILAN</td>
                                            <td>NORTE</td>
                                            <td>2948497092</td>
                                            <td><a href="./mapas.php?id=580120800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>RESIDENCIA ESTUDIANTIL NIVEL MEDIO LAS OVEJAS</td>
                                            <td>URRUTIA RAUL AV</td>
                                            <td><a href="mailto:renmlasovejas@neuquen.gov.ar"> renmlasovejas@neuquen.gov.ar </a></td>
                                            <td>LAS OVEJAS</td>
                                            <td>NORTE</td>
                                            <td>2948481137</td>
                                            <td><a href="./mapas.php?id=580120900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>RESIDENCIA ESTUDIANTIL NIVEL MEDIO LONCOPUE</td>
                                            <td>VILLEGAS CONRADO AV</td>
                                            <td><a href="mailto:resiloncopue@neuquen.gov.ar"> resiloncopue@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>299155111375</td>
                                            <td><a href="./mapas.php?id=580121000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 9</td>
                                            <td>BELGRANO MANUEL</td>
                                            <td><a href="mailto:ne009@neuquen.gov.ar"> ne009@neuquen.gov.ar </a></td>
                                            <td>LONCOPUE</td>
                                            <td>NORTE</td>
                                            <td>29424073776</td>
                                            <td><a href="./mapas.php?id=580121400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 9 ANEXO CAVIAHUE</td>
                                            <td>BIALOUS RICARDO AV</td>
                                            <td><a href="mailto:ne009@neuquen.gov.ar"> ne009@neuquen.gov.ar </a></td>
                                            <td>CAVIAHUE</td>
                                            <td>NORTE</td>
                                            <td>2942407376</td>
                                            <td><a href="./mapas.php?id=580121401"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 9 ANEXO EL HUECÚ</td>
                                            <td>DE SAN MARTIN JOSE GRL</td>
                                            <td><a href="mailto:ne009@neuquen.gov.ar"> ne009@neuquen.gov.ar </a></td>
                                            <td>EL HUECU</td>
                                            <td>NORTE</td>
                                            <td>2942407376</td>
                                            <td><a href="./mapas.php?id=580121402"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN MATERNO INFANTIL MONIGOTE</td>
                                            <td>MITRE BARTOLOME 851</td>
                                            <td><a href="mailto:jardin_monigote@hotmail.com"> jardin_monigote@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154661945</td>
                                            <td><a href="./mapas.php?id=580121600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES MI SOL</td>
                                            <td>RIO SALADO 1185</td>
                                            <td><a href="mailto:jardinmaternalmisol@gmail.com"> jardinmaternalmisol@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994423747</td>
                                            <td><a href="./mapas.php?id=580121700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 18</td>
                                            <td>DE GÜEMES MARTIN MIGUEL</td>
                                            <td><a href="mailto:cef018@neuquen.gov.ar"> cef018@neuquen.gov.ar </a></td>
                                            <td>EL HUECU</td>
                                            <td>NORTE</td>
                                            <td>2942697363</td>
                                            <td><a href="./mapas.php?id=580121800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN MATERNAL Y DE INFANTES SOLCITOS KIDS</td>
                                            <td>CHRESTIA 535</td>
                                            <td><a href="mailto:solcitoskids@hotmail.com"> solcitoskids@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994473238</td>
                                            <td><a href="./mapas.php?id=580121900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN MATERNAL Y DE INFANTES TIERRA ALEGRE</td>
                                            <td>LOS ARRAYANES AV 1810</td>
                                            <td><a href="mailto:jardintierralegre@neuquen.gov.ar"> jardintierralegre@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>294154532263</td>
                                            <td><a href="./mapas.php?id=580122000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 91</td>
                                            <td>CARPINTERO GIGANTE</td>
                                            <td><a href="mailto:cpem091@neuquen.gov.ar"> cpem091@neuquen.gov.ar </a></td>
                                            <td>VILLA TRAFUL</td>
                                            <td>SUR</td>
                                            <td>294479082</td>
                                            <td><a href="./mapas.php?id=580122200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN MATERNAL Y DE INFANTES OLITA</td>
                                            <td>ALASKA 6445</td>
                                            <td><a href="mailto:jardinolita@hotmail.com"> jardinolita@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440447</td>
                                            <td><a href="./mapas.php?id=580122300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 68</td>
                                            <td>SADOSKY MANUEL</td>
                                            <td><a href="mailto:jardin068@neuquen.gov.ar"> jardin068@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994876324</td>
                                            <td><a href="./mapas.php?id=580122400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 69</td>
                                            <td>MARTELLOTTA 187</td>
                                            <td><a href="mailto:jardin69plottier@gmail.com"> jardin69plottier@gmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994389259</td>
                                            <td><a href="./mapas.php?id=580122500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 69 ANEXO BARRIO LOS ÁLAMOS</td>
                                            <td>PRIMEROS PINOS 25</td>
                                            <td><a href="mailto:jardin69@neuquen.gov.ar"> jardin69@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154389013</td>
                                            <td><a href="./mapas.php?id=580122501"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 69 ANEXO BARRIO LOS HORNOS</td>
                                            <td>ILI OMAR 979</td>
                                            <td><a href="mailto:jardin69plottier@gmail.com"> jardin69plottier@gmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154387388</td>
                                            <td><a href="./mapas.php?id=580122502"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 70</td>
                                            <td>LOS CHAÑARES (CALLE 3)</td>
                                            <td><a href="mailto:jardin070@neuquen.gov.ar"> jardin070@neuquen.gov.ar </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994904101</td>
                                            <td><a href="./mapas.php?id=580122600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>DIRECCIÓN GENERAL DOMICILIARIA HOSPITALARIA</td>
                                            <td>BELGRANO MANUEL</td>
                                            <td><a href="mailto:educdomiciliariahospitalaria@neuquen.gov.ar"> educdomiciliariahospitalaria@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994494355</td>
                                            <td><a href="./mapas.php?id=580122700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO REGIONAL DE EDUCACIÓN TECNOLÓGICA (CeRET)</td>
                                            <td>DE SAN MARTIN JOSE GRL 3293</td>
                                            <td><a href="mailto:ceretnqn2016@yahoo.com"> ceretnqn2016@yahoo.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994467154</td>
                                            <td><a href="./mapas.php?id=580122900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>UNIDAD DE CULTURA TECNOLÓGICA AULA TALLER MÓVIL DE INSTALACIONES DOMICILIARIAS</td>
                                            <td>RUTA PROVINCIAL 18 KM 23</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>RUCA-CHOROI</td>
                                            <td>SUR</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580122901"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>UNIDAD DE CULTURA TECNOLÓGICA AULA TALLER MÓVIL SOLDADURA</td>
                                            <td>JOSE JADULL AV</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>BUTA RANQUIL</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580122902"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>UNIDAD DE CULTURA TECNOLÓGICA AULA TALLER MÓVIL METALMECÁNICA</td>
                                            <td>EL PORTON</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580122903"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>UNIDAD DE CULTURA TECNOLÓGICA AULA TALLER MÓVIL ENERGÍAS RENOVABLES</td>
                                            <td>RUTA PROVINCIAL 43</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>LAS OVEJAS</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580122904"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>UNIDAD DE CULTURA TECNOLÓGICA AULA TALLER MÓVIL TEXTIL E INDUMENTARIA</td>
                                            <td>EL CHOCON 35</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435680</td>
                                            <td><a href="./mapas.php?id=580122905"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>UNIDAD DE CULTURA TECNOLÓGICA AULA TALLER MÓVIL MECÁNICA DE MOTOS</td>
                                            <td>PAISIL JOSE</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2996040329</td>
                                            <td><a href="./mapas.php?id=580122906"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES AMADEUS</td>
                                            <td>ANTARTIDA ARGENTINA 607</td>
                                            <td><a href="mailto:colegioamadeus1@gmail.com"> colegioamadeus1@gmail.com </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994876307</td>
                                            <td><a href="./mapas.php?id=580123000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO PRIMARIO LOLA MORA</td>
                                            <td>LA RIOJA 765</td>
                                            <td><a href="mailto:colegiololamora@outlook.com"> colegiololamora@outlook.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994305698</td>
                                            <td><a href="./mapas.php?id=580123100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO EDUCATIVO COMUNITARIO - ESCUELA DE GESTIÓN SOCIAL - NIVEL MEDIO</td>
                                            <td>LOS CONDORES (PEHUENCO) 470</td>
                                            <td><a href="mailto:secundariocecsocial@neuquen.gov.ar"> secundariocecsocial@neuquen.gov.ar </a></td>
                                            <td>VILLA PEHUENIA</td>
                                            <td>SUR</td>
                                            <td>1130244042</td>
                                            <td><a href="./mapas.php?id=580123200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO SUPERIOR DE FORMACIÓN DOCENTE 11</td>
                                            <td>CHUBUT</td>
                                            <td><a href="mailto:ifd011@neuquen.gov.ar"> ifd011@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2996010041</td>
                                            <td><a href="./mapas.php?id=580123300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº39</td>
                                            <td>COLON CRISTOBAL 338</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580123500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº39 ANEXO I  - UD 11</td>
                                            <td>HUERGO LUIS A ING</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580123501"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº39 ANEXO II - UD 12</td>
                                            <td>VENADO TUERTO</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580123502"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº39 ANEXO III - UD 16</td>
                                            <td>DE SAN MARTIN JOSE GRL 6325</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580123503"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº39 ANEXO IV - PF 5</td>
                                            <td>ESPINOZA BENITO</td>
                                            <td><a href="mailto:cepinivelsecundario@neuquen.gov.ar"> cepinivelsecundario@neuquen.gov.ar </a></td>
                                            <td>SENILLOSA</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580123504"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº39 ANEXO V - Inst.Rehabilitacion ARROYITO</td>
                                            <td>RUTA NACIONAL 22</td>
                                            <td><a href="mailto:cepinivelprimario@neuquen.gov.ar"> cepinivelprimario@neuquen.gov.ar </a></td>
                                            <td>ARROYITO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580123505"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA INTEGRAL DE ADOLESCENTES Y JÓVENES CON DISCAPACIDAD 8</td>
                                            <td>JUSTO GRL 850</td>
                                            <td><a href="mailto:eiajdchosmalal@neuquen.gov.ar"> eiajdchosmalal@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580123700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA INTEGRAL DE ADOLESCENTES Y JÓVENES CON DISCAPACIDAD 7</td>
                                            <td>GODOY DIAZ ALFREDO 181</td>
                                            <td><a href="mailto:eiajdcentenario@neuquen.gov.ar"> eiajdcentenario@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994873919</td>
                                            <td><a href="./mapas.php?id=580123800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 38</td>
                                            <td>LOS CONDORES (PEHUENCO) 470</td>
                                            <td><a href="mailto:cfp038@neuquen.gov.ar"> cfp038@neuquen.gov.ar </a></td>
                                            <td>VILLA PEHUENIA</td>
                                            <td>SUR</td>
                                            <td>2942650796</td>
                                            <td><a href="./mapas.php?id=580124000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA AMADEUS</td>
                                            <td>ANTARTIDA ARGENTINA 607</td>
                                            <td><a href="mailto:colegioamadeusprimaria@gmail.com"> colegioamadeusprimaria@gmail.com </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994876307</td>
                                            <td><a href="./mapas.php?id=580124200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 364</td>
                                            <td>GASPARRI ING SUR 250</td>
                                            <td><a href="mailto:primaria364@neuquen.gov.ar"> primaria364@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>299154221705</td>
                                            <td><a href="./mapas.php?id=580124400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.I.A. 7</td>
                                            <td>VILLEGAS CONRADO 279</td>
                                            <td><a href="mailto:cia007@neuquen.gov.ar"> cia007@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>299154016489</td>
                                            <td><a href="./mapas.php?id=580124600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.I.A. 8</td>
                                            <td>HONDURAS 750</td>
                                            <td><a href="mailto:cia008@neuquen.gov.ar"> cia008@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994877059</td>
                                            <td><a href="./mapas.php?id=580124700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 365</td>
                                            <td>COSTA RICA</td>
                                            <td><a href="mailto:primaria365@neuquen.gov.ar"> primaria365@neuquen.gov.ar </a></td>
                                            <td>CENTENARIO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994899233</td>
                                            <td><a href="./mapas.php?id=580124800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 94</td>
                                            <td>CORDILLERA DEL VIENTO</td>
                                            <td><a href="mailto:cpem094@neuquen.gov.ar"> cpem094@neuquen.gov.ar </a></td>
                                            <td>VARVARCO</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580124900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 95</td>
                                            <td>PRIMEROS POBLADORES</td>
                                            <td><a href="mailto:cpem095@neuquen.gov.ar; cpem95manzanoamargo@gmail.com"> cpem095@neuquen.gov.ar; cpem95manzanoamargo@gmail.com </a></td>
                                            <td>MANZANO AMARGO</td>
                                            <td>NORTE</td>
                                            <td>294215409530</td>
                                            <td><a href="./mapas.php?id=580125000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 71</td>
                                            <td>ELORDI GDOR</td>
                                            <td><a href="mailto:jardin071@neuquen.gov.ar"> jardin071@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994934486</td>
                                            <td><a href="./mapas.php?id=580125200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>FUNDACIÓN COLEGIO CUMBRES</td>
                                            <td>EDELMAN ANGEL 450</td>
                                            <td><a href="mailto:info@colegiocumbres.com.ar"> info@colegiocumbres.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2996122017</td>
                                            <td><a href="./mapas.php?id=580125500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA VALLE DEL SOL NIVEL MEDIO</td>
                                            <td>TROMEN 1045</td>
                                            <td><a href="mailto:secundariovalledelsol@gmail.com"> secundariovalledelsol@gmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580125600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO I.F.E.S. NIVEL INICIAL Y PRIMARIO</td>
                                            <td>LASTRA J.J. 5600</td>
                                            <td><a href="mailto:direccionprimarioneuquen@ifes.edu.ar"> direccionprimarioneuquen@ifes.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994440305</td>
                                            <td><a href="./mapas.php?id=580125700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO SAGRADO CORAZÓN NIVEL MEDIO</td>
                                            <td>OBRERO ARGENTINO 86</td>
                                            <td><a href="mailto:secretaria@sagradocorazonnqn.com.ar"> secretaria@sagradocorazonnqn.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2995042259</td>
                                            <td><a href="./mapas.php?id=580125800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 366</td>
                                            <td>EL LUPULO</td>
                                            <td><a href="mailto:primaria366@neuquen.gov.ar"> primaria366@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994495000 INT 6783</td>
                                            <td><a href="./mapas.php?id=580125900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 23</td>
                                            <td>RUTA PROVINCIAL 17</td>
                                            <td><a href="mailto:epet23@neuquen.gov.ar"> epet23@neuquen.gov.ar </a></td>
                                            <td>ANELO</td>
                                            <td>ANELO</td>
                                            <td>2994058314</td>
                                            <td><a href="./mapas.php?id=580126000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 10</td>
                                            <td>SAPAG FELIPE GDOR AV</td>
                                            <td><a href="mailto:ne010@neuquen.gov.ar"> ne010@neuquen.gov.ar </a></td>
                                            <td>ANDACOLLO</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580126100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 10 ANEXO LOS MICHES</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:ne010@neuquen.gov.ar"> ne010@neuquen.gov.ar </a></td>
                                            <td>LOS MICHES</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580126101"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 10 ANEXO LAS OVEJAS</td>
                                            <td>SANCHEZ MODESTO PSJE</td>
                                            <td><a href="mailto:ne010@neuquen.gov.ar"> ne010@neuquen.gov.ar </a></td>
                                            <td>LAS OVEJAS</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580126102"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 10 ANEXO TRICAO MALAL</td>
                                            <td>EL LIBERTADOR AV</td>
                                            <td><a href="mailto:ne010@neuquen.gov.ar"> ne010@neuquen.gov.ar </a></td>
                                            <td>TRICAO MALAL</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580126103"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO MANUEL BELGRANO NIVEL MEDIO</td>
                                            <td>SOLALIQUE 1070</td>
                                            <td><a href="mailto:colegiombelgranonqn@yahoo.com.ar"> colegiombelgranonqn@yahoo.com.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299155778716</td>
                                            <td><a href="./mapas.php?id=580126200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES HABÍA UNA VEZ</td>
                                            <td>SALTA 434</td>
                                            <td><a href="mailto:jardin-habiaunavez@hotmail.com"> jardin-habiaunavez@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994435929</td>
                                            <td><a href="./mapas.php?id=580126300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 96</td>
                                            <td>LOS LAGOS AV 1729</td>
                                            <td><a href="mailto:cpem096@neuquen.gov.ar"> cpem096@neuquen.gov.ar </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972414821</td>
                                            <td><a href="./mapas.php?id=580126400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 74</td>
                                            <td>9 DE ENERO AV</td>
                                            <td><a href="mailto:jardin074@neuquen.gov.ar"> jardin074@neuquen.gov.ar </a></td>
                                            <td>VILLA EL CHOCON</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154219896</td>
                                            <td><a href="./mapas.php?id=580126500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA TIERRA ALEGRE NIVEL PRIMARIO</td>
                                            <td>LOS ARRAYANES AV 1810</td>
                                            <td><a href="mailto:primariatierralegre@neuquen.gov.ar"> primariatierralegre@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944296363</td>
                                            <td><a href="./mapas.php?id=580126600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>INSTITUTO SUPERIOR DE FORMACIÓN DOCENTE 15</td>
                                            <td>RIO DEL MACHETE 155</td>
                                            <td><a href="mailto:ifd015terciario@neuquen.gov.ar"> ifd015terciario@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944495943</td>
                                            <td><a href="./mapas.php?id=580126700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO I.S.I. COLLEGE NIVEL MEDIO</td>
                                            <td>BELGRANO MANUEL GRL 555</td>
                                            <td><a href="mailto:secretarianivelmedio@isicollege.edu.ar"> secretarianivelmedio@isicollege.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994484812</td>
                                            <td><a href="./mapas.php?id=580126800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>COLEGIO AMANCAY</td>
                                            <td>BATTILANA AGUSTIN 121</td>
                                            <td><a href="mailto:colegioamancayplottier@hotmail.com"> colegioamancayplottier@hotmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933740</td>
                                            <td><a href="./mapas.php?id=580126900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 367</td>
                                            <td>RACEDO</td>
                                            <td><a href="mailto:primaria367@neuquen.gov.ar"> primaria367@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154572833</td>
                                            <td><a href="./mapas.php?id=580127000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE EDUCACIÓN TÉCNICA 24</td>
                                            <td>EL PORTON</td>
                                            <td><a href="mailto:epet024@neuquen.gov.ar"> epet024@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>299155866948</td>
                                            <td><a href="./mapas.php?id=580127300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 75</td>
                                            <td>CORDILLERA DEL VIENTO AV</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580127500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 76</td>
                                            <td>BOERR ELISEO</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580127600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 77</td>
                                            <td>MARTINEZ GREGORIO</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580127700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 78</td>
                                            <td>BARROS NESTOR</td>
                                            <td><a href="mailto:jardin078@neuquen.gov.ar"> jardin078@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580127800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 79</td>
                                            <td>BOLIVAR SIMON AV 950</td>
                                            <td><a href="mailto:jardin079@neuquen.gov.ar"> jardin079@neuquen.gov.ar </a></td>
                                            <td>VISTA ALEGRE NORTE</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299156594913</td>
                                            <td><a href="./mapas.php?id=580127900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 80</td>
                                            <td>LONCOPUE 550</td>
                                            <td><a href="mailto:jardin080@neuquen.gov.ar"> jardin080@neuquen.gov.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2942422114</td>
                                            <td><a href="./mapas.php?id=580128000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 81</td>
                                            <td>MOQUEHUE PSJE</td>
                                            <td><a href="mailto:jardin081@neuquen.gov.ar"> jardin081@neuquen.gov.ar </a></td>
                                            <td>RINCON DE LOS SAUCES</td>
                                            <td>ANELO</td>
                                            <td>2994887642</td>
                                            <td><a href="./mapas.php?id=580128100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN MATERNAL Y DE INFANTES PILPILIHUE</td>
                                            <td>RODRIGUEZ CARLOS H 1265</td>
                                            <td><a href="mailto:jardinpilpilihue@neuquen.edu.ar"> jardinpilpilihue@neuquen.edu.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994420017</td>
                                            <td><a href="./mapas.php?id=580128400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES CONSTRUYENDO</td>
                                            <td>BUENOS AIRES SUR 412</td>
                                            <td><a href="mailto:jardinconstruyendo@neuquen.gov.ar"> jardinconstruyendo@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994938070</td>
                                            <td><a href="./mapas.php?id=580128500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN MATERNAL Y DE INFANTES EUREKA</td>
                                            <td>LA RIOJA 959</td>
                                            <td><a href="mailto:jardinmaternaleureka@hotmail.com"> jardinmaternaleureka@hotmail.com </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299482377</td>
                                            <td><a href="./mapas.php?id=580128600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA SECUNDARIA DE ARTE PARA EL ALMA ALMA LIBRE</td>
                                            <td>AYUNTUN HUE 3891</td>
                                            <td><a href="mailto:secretariaalmalibre@gmail.com"> secretariaalmalibre@gmail.com </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299156049461</td>
                                            <td><a href="./mapas.php?id=580128800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>JARDÍN DE INFANTES 82</td>
                                            <td>PEREZ MAESTRO 570</td>
                                            <td><a href="mailto:jardin082@neuquen.gov.ar"> jardin082@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 4348</td>
                                            <td><a href="./mapas.php?id=580128900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PROVINCIAL DE ENSEÑANZA TÉCNICA 26</td>
                                            <td>ALERCE</td>
                                            <td><a href="mailto:SIN DATO"> SIN DATO </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580129300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 41
</td>
                                            <td>LONCOPUE 550,  (Q8340)</td>
                                            <td><a href="mailto:cfp041@neuquen.edu.ar"> cfp041@neuquen.edu.ar </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>0299 5234696</td>
                                            <td><a href="./mapas.php?id=580131600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº41 ANEXO I - UD 21</td>
                                            <td>RODRIGUEZ CARLOS H 230</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994964984</td>
                                            <td><a href="./mapas.php?id=580131601"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº41 ANEXO II - UD 22</td>
                                            <td>CONQUISTADORES DEL DESIERTO</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>CUTRAL CO</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994964984</td>
                                            <td><a href="./mapas.php?id=580131602"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº41 ANEXO III - UD 31</td>
                                            <td>TORRES MAYOR</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580131603"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº41 ANEXO IV - UD 32</td>
                                            <td>FORTABAT ALFREDO</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580131604"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº41 ANEXO V - UD 41</td>
                                            <td>LAMADRID GRL</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2994479304</td>
                                            <td><a href="./mapas.php?id=580131605"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº41 ANEXO VI - UD 42</td>
                                            <td>ELORRIAGA DAMIAN</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>SAN MARTIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580131606"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL Nº41 ANEXO VII - UD 51</td>
                                            <td>SOBERANIA</td>
                                            <td><a href="mailto:cepinivelmedio@gmail.com"> cepinivelmedio@gmail.com </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580131607"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 42</td>
                                            <td>RUTA PROVINCIAL 2</td>
                                            <td><a href="mailto:cfp042@neuquen.edu.ar"> cfp042@neuquen.edu.ar </a></td>
                                            <td>TRICAO MALAL</td>
                                            <td>NORTE</td>
                                            <td>0299 5157952</td>
                                            <td><a href="./mapas.php?id=580133000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 310 ALBERGUE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria310@neuquen.gov.ar"> primaria310@neuquen.gov.ar </a></td>
                                            <td>COCHICO</td>
                                            <td>NORTE</td>
                                            <td>2948496800</td>
                                            <td><a href="./mapas.php?id=580000200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 84</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria084@neuquen.gov.ar"> primaria084@neuquen.gov.ar </a></td>
                                            <td>CARRAN CURA</td>
                                            <td>CENTRO</td>
                                            <td>2942493189</td>
                                            <td><a href="./mapas.php?id=580004400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 233 RAMÓN SOLANO PUERTAS</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria233@neuquen.gov.ar"> primaria233@neuquen.gov.ar </a></td>
                                            <td>PASO YUNCON</td>
                                            <td>CENTRO</td>
                                            <td>2972490450</td>
                                            <td><a href="./mapas.php?id=580008100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 126</td>
                                            <td>RUTA PROVINCIAL 50</td>
                                            <td><a href="mailto:primaria126@neuquen.gov.ar"> primaria126@neuquen.gov.ar </a></td>
                                            <td>SAÑICO</td>
                                            <td>CENTRO</td>
                                            <td>2942663016</td>
                                            <td><a href="./mapas.php?id=580008300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 27</td>
                                            <td>RUTA PROVINCIAL 50</td>
                                            <td><a href="mailto:primaria027@neuquen.gov.ar"> primaria027@neuquen.gov.ar </a></td>
                                            <td>PIEDRA PINTADA</td>
                                            <td>CENTRO</td>
                                            <td>2942493227</td>
                                            <td><a href="./mapas.php?id=580008400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 155</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria155@neuquen.gov.ar"> primaria155@neuquen.gov.ar </a></td>
                                            <td>PIL-PIL</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1141</td>
                                            <td><a href="./mapas.php?id=580022900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 33</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria033@neuquen.gov.ar"> primaria033@neuquen.gov.ar </a></td>
                                            <td>QUILA-QUINA</td>
                                            <td>SUR</td>
                                            <td>2972425073</td>
                                            <td><a href="./mapas.php?id=580023500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 236 GENDARMERÍA NACIONAL</td>
                                            <td>RUTA PROVINCIAL 54</td>
                                            <td><a href="mailto:primaria236@neuquen.gov.ar"> primaria236@neuquen.gov.ar </a></td>
                                            <td>PICHI NEUQUEN</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1115</td>
                                            <td><a href="./mapas.php?id=580029000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 251 PROVINCIA DE LA RIOJA</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:primaria251@neuquen.gov.ar"> primaria251@neuquen.gov.ar </a></td>
                                            <td>LAGUNA AUQUINCO</td>
                                            <td>ANELO</td>
                                            <td>2994495200 INT 1139</td>
                                            <td><a href="./mapas.php?id=580029600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 58 JUAN BENIGAR</td>
                                            <td>RUTA PROVINCIAL 18 KM 23</td>
                                            <td><a href="mailto:primaria058@neuquen.gov.ar"> primaria058@neuquen.gov.ar </a></td>
                                            <td>RUCA-CHOROI</td>
                                            <td>SUR</td>
                                            <td>2942550995</td>
                                            <td><a href="./mapas.php?id=580031400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 278</td>
                                            <td>RUTA PROVINCIAL 18</td>
                                            <td><a href="mailto:primaria278@neuquen.gov.ar"> primaria278@neuquen.gov.ar </a></td>
                                            <td>POI-PUCON</td>
                                            <td>SUR</td>
                                            <td>2942519071</td>
                                            <td><a href="./mapas.php?id=580031600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 65</td>
                                            <td>RUTA PROVINCIAL 46</td>
                                            <td><a href="mailto:primaria065@neuquen.gov.ar"> primaria065@neuquen.gov.ar </a></td>
                                            <td>QUILLEN</td>
                                            <td>SUR</td>
                                            <td>2942528981</td>
                                            <td><a href="./mapas.php?id=580032800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 209 MAESTRA MARÍA AMALIA CAYROL</td>
                                            <td>RUTA PROVINCIAL 23</td>
                                            <td><a href="mailto:primaria209@neuquen.gov.ar"> primaria209@neuquen.gov.ar </a></td>
                                            <td>ABRA ANCHA</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1104</td>
                                            <td><a href="./mapas.php?id=580032900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 72</td>
                                            <td>RUTA PROVINCIAL 11 KM 56</td>
                                            <td><a href="mailto:primaria072@neuquen.gov.ar"> primaria072@neuquen.gov.ar </a></td>
                                            <td>LONCO MULA</td>
                                            <td>SUR</td>
                                            <td>2942496264</td>
                                            <td><a href="./mapas.php?id=580033000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 145</td>
                                            <td>RUTA PROVINCIAL 18</td>
                                            <td><a href="mailto:primaria145@neuquen.gov.ar"> primaria145@neuquen.gov.ar </a></td>
                                            <td>CARRI LIL</td>
                                            <td>SUR</td>
                                            <td>2942496192</td>
                                            <td><a href="./mapas.php?id=580033200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 250</td>
                                            <td>RUTA PROVINCIAL 20</td>
                                            <td><a href="mailto:primaria250@neuquen.gov.ar"> primaria250@neuquen.gov.ar </a></td>
                                            <td>MEDIA LUNA</td>
                                            <td>CENTRO</td>
                                            <td>2994495000 INT 1112</td>
                                            <td><a href="./mapas.php?id=580039700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 139 SEGUNDO HILARIO HUENUQUIR</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria139@neuquen.gov.ar"> primaria139@neuquen.gov.ar </a></td>
                                            <td>COSTA DEL MALLEO</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1123</td>
                                            <td><a href="./mapas.php?id=580048700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 259 SOBERANÍA NACIONAL</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria259@neuquen.gov.ar"> primaria259@neuquen.gov.ar </a></td>
                                            <td>ATREUCO (RAI)</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1120</td>
                                            <td><a href="./mapas.php?id=580048800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 252</td>
                                            <td>RUTA PROVINCIAL 61</td>
                                            <td><a href="mailto:primaria252@neuquen.gov.ar"> primaria252@neuquen.gov.ar </a></td>
                                            <td>PAIMUN</td>
                                            <td>SUR</td>
                                            <td>294245953</td>
                                            <td><a href="./mapas.php?id=580048900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 222 ARTILLEROS DE LOS ANDES</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria222@neuquen.gov.ar"> primaria222@neuquen.gov.ar </a></td>
                                            <td>CHIQUILIHUIN (RAI)</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1170</td>
                                            <td><a href="./mapas.php?id=580049000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 213 GUARDIA NACIONAL</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria213@neuquen.gov.ar"> primaria213@neuquen.gov.ar </a></td>
                                            <td>AUCAPAN (RAI)</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1121</td>
                                            <td><a href="./mapas.php?id=580049100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN INTEGRAL SAN IGNACIO</td>
                                            <td>RUTA PROVINCIAL 61 KM 6,5</td>
                                            <td><a href="mailto:ceisanignacio@cruzadapatagonica.org"> ceisanignacio@cruzadapatagonica.org </a></td>
                                            <td>SAN CABAO</td>
                                            <td>SUR</td>
                                            <td>2972429765</td>
                                            <td><a href="./mapas.php?id=580049200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 308 QUIÑE PEHUEN</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria308@neuquen.gov.ar"> primaria308@neuquen.gov.ar </a></td>
                                            <td>ATREUCO (RAI)</td>
                                            <td>SUR</td>
                                            <td>2944563547</td>
                                            <td><a href="./mapas.php?id=580049300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 287</td>
                                            <td>LOS ÑIRES</td>
                                            <td><a href="mailto:primaria287@neuquen.gov.ar"> primaria287@neuquen.gov.ar </a></td>
                                            <td>NAHUEL MAPI ABAJO</td>
                                            <td>SUR</td>
                                            <td>2972490740</td>
                                            <td><a href="./mapas.php?id=580049400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 242 CORONEL MANUEL NAMUNCURA</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria242@neuquen.gov.ar"> primaria242@neuquen.gov.ar </a></td>
                                            <td>HUILQUI MENUCO</td>
                                            <td>SUR</td>
                                            <td>2972491793</td>
                                            <td><a href="./mapas.php?id=580049600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 357 PAMPA DEL MALLEO</td>
                                            <td>RUTA PROVINCIAL 23</td>
                                            <td><a href="mailto:primaria357@neuquen.gov.ar"> primaria357@neuquen.gov.ar </a></td>
                                            <td>PAMPA DEL MALLEO</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1147</td>
                                            <td><a href="./mapas.php?id=580049800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 306</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria306@neuquen.gov.ar"> primaria306@neuquen.gov.ar </a></td>
                                            <td>NAHUEL MAPE ARRIBA</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1173</td>
                                            <td><a href="./mapas.php?id=580050000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>E.P.A. 11 - ANEXO CHIQUILIHUIN</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:epa011@neuquen.gov.ar"> epa011@neuquen.gov.ar </a></td>
                                            <td>CHIQUILIHUIN (RAI)</td>
                                            <td>SUR</td>
                                            <td>2972492102</td>
                                            <td><a href="./mapas.php?id=580050803"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 210 ALBERGUE</td>
                                            <td>RUTA PROVINCIAL 53 40</td>
                                            <td><a href="mailto:primaria210@neuquen.gov.ar"> primaria210@neuquen.gov.ar </a></td>
                                            <td>COYUCO</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1114</td>
                                            <td><a href="./mapas.php?id=580058700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 57 ALBERGUE IDA FIUMANI DE ARELLANO</td>
                                            <td>RUTA PROVINCIAL 15</td>
                                            <td><a href="mailto:primaria057@neuquen.gov.ar"> primaria057@neuquen.gov.ar </a></td>
                                            <td>QUILCA</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1100</td>
                                            <td><a href="./mapas.php?id=580060500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 130</td>
                                            <td>RUTA NACIONAL 40</td>
                                            <td><a href="mailto:primaria130@neuquen.gov.ar"> primaria130@neuquen.gov.ar </a></td>
                                            <td>EL SALITRAL</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1113</td>
                                            <td><a href="./mapas.php?id=580064200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 51 ALBERGUE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria051@neuquen.gov.ar"> primaria051@neuquen.gov.ar </a></td>
                                            <td>PILOLIL</td>
                                            <td>CENTRO</td>
                                            <td>2972490630</td>
                                            <td><a href="./mapas.php?id=580064400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 43 CEFERINO NAMUNCURA</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria043@neuquen.gov.ar"> primaria043@neuquen.gov.ar </a></td>
                                            <td>SAN IGNACIO</td>
                                            <td>CENTRO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580064500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 319</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria319@neuquen.gov.ar"> primaria319@neuquen.gov.ar </a></td>
                                            <td>AUCAPAN ABAJO</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1185</td>
                                            <td><a href="./mapas.php?id=580072200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 317</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria317@neuquen.gov.ar"> primaria317@neuquen.gov.ar </a></td>
                                            <td>CONFLUENCIA DEL MALLEO</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1194</td>
                                            <td><a href="./mapas.php?id=580072300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 320</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria320@neuquen.gov.ar"> primaria320@neuquen.gov.ar </a></td>
                                            <td>COSTA DEL CATAN LIL</td>
                                            <td>CENTRO</td>
                                            <td>2994495200 INT 1176</td>
                                            <td><a href="./mapas.php?id=580072400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 338</td>
                                            <td>RUTA PROVINCIAL 2</td>
                                            <td><a href="mailto:primaria338@neuquen.gov.ar"> primaria338@neuquen.gov.ar </a></td>
                                            <td>LEUTO CABALLO</td>
                                            <td>NORTE</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580090000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 2 ANEXO EL SAUCE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:ne002@neuquen.gov.ar"> ne002@neuquen.gov.ar </a></td>
                                            <td>EL SAUCE</td>
                                            <td>SUR</td>
                                            <td>2994018602</td>
                                            <td><a href="./mapas.php?id=580097305"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>C.E.I. SAN IGNACIO NIVEL ADULTOS</td>
                                            <td>RUTA PROVINCIAL 61 KM 6,5</td>
                                            <td><a href="mailto:ceisanignacio@cruzadapatagonica.org"> ceisanignacio@cruzadapatagonica.org </a></td>
                                            <td>SAN CABAO</td>
                                            <td>SUR</td>
                                            <td>2972429765</td>
                                            <td><a href="./mapas.php?id=580102800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA AGROTÉCNICA SAGRADA FAMILIA</td>
                                            <td>PARRA RAMON</td>
                                            <td><a href="mailto:escuelasagradafamilia@neuquen.gov.ar"> escuelasagradafamilia@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>294215400405</td>
                                            <td><a href="./mapas.php?id=580106100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 86</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:cpem086@neuquen.gov.ar"> cpem086@neuquen.gov.ar </a></td>
                                            <td>COSTA DEL MALLEO</td>
                                            <td>SUR</td>
                                            <td>2972413775</td>
                                            <td><a href="./mapas.php?id=580109700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 7 ANEXO RUCA CHOROI</td>
                                            <td>RUTA PROVINCIAL 18 KM 23</td>
                                            <td><a href="mailto:ne007@neuquen.gov.ar"> ne007@neuquen.gov.ar </a></td>
                                            <td>RUCA-CHOROI</td>
                                            <td>SUR</td>
                                            <td>2942496106</td>
                                            <td><a href="./mapas.php?id=580112101"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 7 ANEXO CARRI LIL</td>
                                            <td>RUTA PROVINCIAL 18</td>
                                            <td><a href="mailto:ne007@neuquen.gov.ar"> ne007@neuquen.gov.ar </a></td>
                                            <td>CARRI LIL</td>
                                            <td>SUR</td>
                                            <td>2942496106</td>
                                            <td><a href="./mapas.php?id=580112102"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 7 ANEXO QUILCA</td>
                                            <td>RUTA PROVINCIAL 15</td>
                                            <td><a href="mailto:ne007quilca@neuquen.gov.ar"> ne007quilca@neuquen.gov.ar </a></td>
                                            <td>QUILCA</td>
                                            <td>SUR</td>
                                            <td>2942496106</td>
                                            <td><a href="./mapas.php?id=580112103"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 7 ANEXO LONCO MULA</td>
                                            <td>RUTA PROVINCIAL 11 KM 56</td>
                                            <td><a href="mailto:ne007@neuquen.gov.ar"> ne007@neuquen.gov.ar </a></td>
                                            <td>LONCO MULA</td>
                                            <td>SUR</td>
                                            <td>2942496106</td>
                                            <td><a href="./mapas.php?id=580112104"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>NUCLEAMIENTO EDUCATIVO 7 ANEXO ABRA ANCHA</td>
                                            <td>RUTA PROVINCIAL 23</td>
                                            <td><a href="mailto:ne007@neuquen.gov.ar"> ne007@neuquen.gov.ar </a></td>
                                            <td>ABRA ANCHA</td>
                                            <td>SUR</td>
                                            <td>2942496106</td>
                                            <td><a href="./mapas.php?id=580112105"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO PROVINCIAL DE ENSEÑANZA MEDIA 93</td>
                                            <td>RUTA PROVINCIAL 18 KM 23</td>
                                            <td><a href="mailto:cpem093@neuquen.gov.ar"> cpem093@neuquen.gov.ar </a></td>
                                            <td>RUCA-CHOROI</td>
                                            <td>SUR</td>
                                            <td>29426204143</td>
                                            <td><a href="./mapas.php?id=580124500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 96 PACÍFICO TISSERA</td>
                                            <td>RUTA PROVINCIAL 2</td>
                                            <td><a href="mailto:primaria096@neuquen.gov.ar"> primaria096@neuquen.gov.ar </a></td>
                                            <td>CHAPUA</td>
                                            <td>NORTE</td>
                                            <td>2942402346</td>
                                            <td><a href="./mapas.php?id=580014300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 79 ALBERGUE BATALLA DE CHACABUCO</td>
                                            <td>RUTA PROVINCIAL 41</td>
                                            <td><a href="mailto:primaria079@neuquen.gov.ar"> primaria079@neuquen.gov.ar </a></td>
                                            <td>CAJON CURILEUVU</td>
                                            <td>NORTE</td>
                                            <td>2948490200</td>
                                            <td><a href="./mapas.php?id=580014400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 23 JOSÉ MANUEL LABARDEN</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria023@neuquen.gov.ar"> primaria023@neuquen.gov.ar </a></td>
                                            <td>LOS MENUCOS</td>
                                            <td>NORTE</td>
                                            <td>2942672194</td>
                                            <td><a href="./mapas.php?id=580014700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 25</td>
                                            <td>RUTA PROVINCIAL 41</td>
                                            <td><a href="mailto:primaria025@neuquen.gov.ar"> primaria025@neuquen.gov.ar </a></td>
                                            <td>CANCHA HUINGANCO</td>
                                            <td>NORTE</td>
                                            <td>2948496400</td>
                                            <td><a href="./mapas.php?id=580014900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 297</td>
                                            <td>RUTA PROVINCIAL 38</td>
                                            <td><a href="mailto:primaria297@neuquen.gov.ar"> primaria297@neuquen.gov.ar </a></td>
                                            <td>LOS CHACAYES</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1131</td>
                                            <td><a href="./mapas.php?id=580015300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 47</td>
                                            <td>RUTA PROVINCIAL 43</td>
                                            <td><a href="mailto:primaria047@neuquen.gov.ar"> primaria047@neuquen.gov.ar </a></td>
                                            <td>CAYANTA</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1171</td>
                                            <td><a href="./mapas.php?id=580015900"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 48 FRANCISCO PASCACIO MORENO</td>
                                            <td>RUTA NACIONAL 40 KM 2179</td>
                                            <td><a href="mailto:primaria048@neuquen.gov.ar"> primaria048@neuquen.gov.ar </a></td>
                                            <td>LAGO HERMOSO</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1125</td>
                                            <td><a href="./mapas.php?id=580017400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 77 JULIANA ORTÍZ DE ÁLVAREZ</td>
                                            <td>RUTA PROVINCIAL 43</td>
                                            <td><a href="mailto:primaria077@neuquen.gov.ar"> primaria077@neuquen.gov.ar </a></td>
                                            <td>CHACAY MELEHUE/EL ALAMITO</td>
                                            <td>NORTE</td>
                                            <td>2995885143</td>
                                            <td><a href="./mapas.php?id=580018700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 161</td>
                                            <td>RUTA PROVINCIAL 19</td>
                                            <td><a href="mailto:primaria161@neuquen.gov.ar"> primaria161@neuquen.gov.ar </a></td>
                                            <td>PUENTE BLANCO</td>
                                            <td>SUR</td>
                                            <td>2995774876</td>
                                            <td><a href="./mapas.php?id=580020100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 116 ALBERGUE</td>
                                            <td>DOÑA EMA</td>
                                            <td><a href="mailto:primaria116@neuquen.gov.ar"> primaria116@neuquen.gov.ar </a></td>
                                            <td>LAGO LOLOG</td>
                                            <td>SUR</td>
                                            <td>2972423351</td>
                                            <td><a href="./mapas.php?id=580023700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 246 DIEGO LEÓN GONZÁLEZ</td>
                                            <td>RUTA PROVINCIAL 39</td>
                                            <td><a href="mailto:primaria246@neuquen.gov.ar"> primaria246@neuquen.gov.ar </a></td>
                                            <td>BUTALON NORTE</td>
                                            <td>NORTE</td>
                                            <td>2948496700</td>
                                            <td><a href="./mapas.php?id=580029100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 284</td>
                                            <td>RUTA PROVINCIAL 39</td>
                                            <td><a href="mailto:primaria284@neuquen.gov.ar"> primaria284@neuquen.gov.ar </a></td>
                                            <td>COLOMICHICO</td>
                                            <td>NORTE</td>
                                            <td>2994495200 INT 1199</td>
                                            <td><a href="./mapas.php?id=580029300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 253</td>
                                            <td>PRIMEROS POBLADORES</td>
                                            <td><a href="mailto:primaria253@neuquen.gov.ar"> primaria253@neuquen.gov.ar </a></td>
                                            <td>MANZANO AMARGO</td>
                                            <td>NORTE</td>
                                            <td>299154129087</td>
                                            <td><a href="./mapas.php?id=580035100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 174</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria174@neuquen.gov.ar"> primaria174@neuquen.gov.ar </a></td>
                                            <td>LILEO</td>
                                            <td>NORTE</td>
                                            <td>2942490153</td>
                                            <td><a href="./mapas.php?id=580047800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 263</td>
                                            <td>RUTA PROVINCIAL 44</td>
                                            <td><a href="mailto:primaria263@neuquen.gov.ar"> primaria263@neuquen.gov.ar </a></td>
                                            <td>TIERRAS BLANCAS</td>
                                            <td>NORTE</td>
                                            <td>2948494088</td>
                                            <td><a href="./mapas.php?id=580054300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 303 ALBERGUE GUARDAPARQUE AURELIO PARGADE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria303@neuquen.gov.ar; escuela303islavictoria@gmail.com"> primaria303@neuquen.gov.ar; escuela303islavictoria@gmail.com </a></td>
                                            <td>ISLA VICTORIA</td>
                                            <td>SUR</td>
                                            <td>2944638704</td>
                                            <td><a href="./mapas.php?id=580055500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 11 ALBERGUE</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria011@neuquen.gov.ar"> primaria011@neuquen.gov.ar </a></td>
                                            <td>CUYIN MANZANO</td>
                                            <td>SUR</td>
                                            <td>2994495200 INT 1192</td>
                                            <td><a href="./mapas.php?id=580056100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 21</td>
                                            <td>RUTA PROVINCIAL 44</td>
                                            <td><a href="mailto:primaria021@neuquen.gov.ar"> primaria021@neuquen.gov.ar </a></td>
                                            <td>BELLA VISTA</td>
                                            <td>NORTE</td>
                                            <td>294815411023</td>
                                            <td><a href="./mapas.php?id=580058600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTO EDUCATIVO NONTHUE</td>
                                            <td>RUTA PROVINCIAL 48 KM 35</td>
                                            <td><a href="mailto:pcenonthue@neuquen.gov.ar"> pcenonthue@neuquen.gov.ar </a></td>
                                            <td>NONTHUE</td>
                                            <td>SUR</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580077200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA PRIMARIA 337</td>
                                            <td>SIN NOMBRE</td>
                                            <td><a href="mailto:primaria337@neuquen.gov.ar"> primaria337@neuquen.gov.ar </a></td>
                                            <td>TROMPUL (RAI)</td>
                                            <td>SUR</td>
                                            <td>2972431825</td>
                                            <td><a href="./mapas.php?id=580093600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL AGROPECUARIA 1</td>
                                            <td>RUTA NACIONAL 22 1233</td>
                                            <td><a href="mailto:cfpa001@neuquen.gov.ar"> cfpa001@neuquen.gov.ar </a></td>
                                            <td>PLOTTIER</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994933758</td>
                                            <td><a href="./mapas.php?id=580094500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL AGROPECUARIA 2</td>
                                            <td>ALERCE</td>
                                            <td><a href="mailto:cfpa002@neuquen.gov.ar"> cfpa002@neuquen.gov.ar </a></td>
                                            <td>SAN PATRICIO DEL CHAÑAR</td>
                                            <td>ANELO</td>
                                            <td>2994855103</td>
                                            <td><a href="./mapas.php?id=580094600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL AGROPECUARIA 3</td>
                                            <td>LOS ALAMOS PSJE 210</td>
                                            <td><a href="mailto:cfpa003@neuquen.gov.ar"> cfpa003@neuquen.gov.ar </a></td>
                                            <td>PICUN LEUFU</td>
                                            <td>SUR</td>
                                            <td>2942492077</td>
                                            <td><a href="./mapas.php?id=580094700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL AGROPECUARIA 5</td>
                                            <td>SAN MARTIN</td>
                                            <td><a href="mailto:cfpa005@neuquen.gov.ar"> cfpa005@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948421202</td>
                                            <td><a href="./mapas.php?id=580094800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL AGROPECUARIA 4</td>
                                            <td>R.I.M. 26 AV 1118</td>
                                            <td><a href="mailto:cfpa004@neuquen.gov.ar"> cfpa004@neuquen.gov.ar </a></td>
                                            <td>ALUMINE</td>
                                            <td>SUR</td>
                                            <td>2942496346</td>
                                            <td><a href="./mapas.php?id=580096100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTOS EDUCATIVOS 1</td>
                                            <td>LINARES INTD 1980</td>
                                            <td><a href="mailto:pce001@neuquen.gov.ar"> pce001@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994401125</td>
                                            <td><a href="./mapas.php?id=580097500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTOS EDUCATIVOS 3</td>
                                            <td>NAHUEL HUAPI AV 1900</td>
                                            <td><a href="mailto:pce003@neuquen.gov.ar"> pce003@neuquen.gov.ar </a></td>
                                            <td>VILLA LA ANGOSTURA</td>
                                            <td>SUR</td>
                                            <td>2944494182</td>
                                            <td><a href="./mapas.php?id=580099000"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 4</td>
                                            <td>ROSA JOSE 950</td>
                                            <td><a href="mailto:cef004@neuquen.gov.ar"> cef004@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994430640</td>
                                            <td><a href="./mapas.php?id=580099100"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTOS EDUCATIVOS 11</td>
                                            <td>RUTA PROVINCIAL 13</td>
                                            <td><a href="mailto:pce011@neuquen.gov.ar"> pce011@neuquen.gov.ar </a></td>
                                            <td>LA ANGOSTURA DE ICALMA</td>
                                            <td>SUR</td>
                                            <td>2942547591</td>
                                            <td><a href="./mapas.php?id=580112200"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTOS EDUCATIVOS 9</td>
                                            <td>RUTA PROVINCIAL 20 9</td>
                                            <td><a href="mailto:pce009@neuquen.gov.ar"> pce009@neuquen.gov.ar </a></td>
                                            <td>CERRO DEL LEON</td>
                                            <td>SUR</td>
                                            <td>294215470121</td>
                                            <td><a href="./mapas.php?id=580112700"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>PLANTA DE CAMPAMENTOS EDUCATIVOS 2</td>
                                            <td>COSTANERA AV 450</td>
                                            <td><a href="mailto:pce002@neuquen.gov.ar"> pce002@neuquen.gov.ar </a></td>
                                            <td>JUNIN DE LOS ANDES</td>
                                            <td>SUR</td>
                                            <td>2972491440</td>
                                            <td><a href="./mapas.php?id=580115300"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA SUPERIOR DE MÚSICA - CHOS MALAL</td>
                                            <td>25 DE MAYO</td>
                                            <td><a href="mailto:esmchosmalal@neuquen.gov.ar"> esmchosmalal@neuquen.gov.ar </a></td>
                                            <td>CHOS MALAL</td>
                                            <td>NORTE</td>
                                            <td>2948422127</td>
                                            <td><a href="./mapas.php?id=580119600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>ESCUELA SUPERIOR DE MÚSICA DE ZAPALA</td>
                                            <td>SAN JUAN 50</td>
                                            <td><a href="mailto:musicazapala41@hotmail.com"> musicazapala41@hotmail.com </a></td>
                                            <td>ZAPALA</td>
                                            <td>CENTRO</td>
                                            <td>29424282777</td>
                                            <td><a href="./mapas.php?id=580120400"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 35</td>
                                            <td>EL CHOCON 2575</td>
                                            <td><a href="mailto:cfp035@neuquen.gov.ar"> cfp035@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>2994402754</td>
                                            <td><a href="./mapas.php?id=580120500"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE FORMACIÓN PROFESIONAL 36</td>
                                            <td>CABELLERA DEL FRIO 2300</td>
                                            <td><a href="mailto:cfp036@neuquen.gov.ar"> cfp036@neuquen.gov.ar </a></td>
                                            <td>NEUQUEN</td>
                                            <td>CONFLUENCIA</td>
                                            <td>299154197178 </td>
                                            <td><a href="./mapas.php?id=580120600"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                        <tr>
                                            <td>CENTRO DE EDUCACIÓN FÍSICA 19</td>
                                            <td>SAAVEDRA CORNELIO 140</td>
                                            <td><a href="mailto:cef019@neuquen.gov.ar"> cef019@neuquen.gov.ar </a></td>
                                            <td>LAS LAJAS</td>
                                            <td>CENTRO</td>
                                            <td></td>
                                            <td><a href="./mapas.php?id=580122800"  aria-current="true">
                                            <img src="https://www.google.com/images/branding/lockups/1x/lockup_maps_color_131x24dp.png" alt="" height="10"></a></td>                                           
                                        </tr>                                    </tbody>
                                        
                                    <tfoot>
                                        <tr>
                                            <th>Centro</th>
                                            <th>Domicilio</th>
                                            <th>Email</th>
                                            <th>Localidad</th>
                                            <th>Zona</th>
                                            <th>Telefono</th>
                                            <th>Ubicacion</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>   


        
        
                        </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; ST3 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<!--         <script src="assets/demo/chart-area-demo.js"></script> Ejemplo-->
<!--        <script src="assets/demo/chart-bar-demo.js"></script> Ejemplo--> 
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<!--         <script src="js/datatables-simple-demo.js"></script> Ejemplo--> -->
    </body>
</html>  