

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-D23TBS0BCN"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-D23TBS0BCN');
    </script>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Web de consulta de Centros de Formacion Profesional" />
    <meta name="author" content="Silvio Stenta" />
    <title>Formacion Profesional WEB</title>
    <link rel="icon" type="image/png" href="img/logofp.png">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
 <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 --></head>

<body class="sb-nav-fixed">
    <nav class="navbar navbar-expand-lg navbar-dark ">
        <!-- Navbar Brand-->
        <button class="btn btn-link btn-sm order-1 order-lg-1 me-4 me-lg-1" id="sidebarToggle" href="index.php">
            <i class="fas fa-bars fa-lg "></i></button>
        <a class="navbar-brand ps-3" href="index.php"><img src="img/logo fp 288x271.png" class="img-fluid" alt="max-width: 30%;height: auto" width="20%"></a>
        <!-- Sidebar Toggle-->

        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <!-- <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button> -->
            </div>
        </form>
        <!-- Navbar User-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="login.php">Login</a></li>
                    <li><a class="dropdown-item" href="./administrador/inicio.php">Settings</a></li>
                    <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="cerrar.php">Cerrar</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <!-- Navbar Lateral -->

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-primary" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Todas las Escuelas
                        </a>
                        <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                            </nav>
                        </div>
                        <!-- <div class="sb-sidenav-menu-heading">Addons</div> -->
                        <!--                         <a class="nav-link" href="charts.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Graficos
                        </a> -->


                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseCFP" aria-expanded="false" aria-controls="collapseCFP">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Centros
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseCFP" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="table.php"><i class="fa fa-book" aria-hidden="true"></i>Listado por Zona</a>
                                <a class="nav-link" href="centrosxzonas.php"><i class="fas fa-map-pin" aria-hidden="true"></i>Ubicacion por Zona</a>
                            </nav>
                        </div>


                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseTray" aria-expanded="false" aria-controls="collapseTray">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Trayectos Formativos
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseTray" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="Sectores.php">
                                    <div class="sb-nav-link-icon"> <i class="fa-brands fa-bandcamp"></i></div>
                                    Sectores Productivos
                                </a>
                                <a class="nav-link" href="SubSectores.php">
                                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                    Sub-Sectores
                                </a>
                                <a class="nav-link" href="TrayectosFormativos.php">
                                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                    Trayectos Formativos
                                </a>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>

                    invitado                </div>
            </nav>
        </div>
        <!-- Principal -->



        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="js/scripts.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.css" />
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/fc-4.0.2/r-2.2.9/rr-1.2.8/sc-2.0.5/sl-1.3.4/datatables.min.css" />

        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/fc-4.0.2/r-2.2.9/rr-1.2.8/sc-2.0.5/sl-1.3.4/datatables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.1/b-2.2.3/b-colvis-2.2.3/b-html5-2.2.3/b-print-2.2.3/datatables.min.js"></script>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

        <div id="layoutSidenav_content">
            <main>

<script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
<!-- <script type="module" src="./mapa.js"></script> -->
<script src="https://unpkg.com/@googlemaps/markerclusterer/dist/index.min.js"></script>

<div class="container-fluid px-2">
    <h1 class="mt-2">Escuelas</h1>
    <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="index.php">Escritorio</a></li>
        <li class="breadcrumb-item active">Tablas</li>
    </ol>


    <!-- Botonera -->
    <form method="POST" enctype="multipart/form-data">
        <div class="btn-group" role="group" aria-label="Basic outlined example">
                            <input name="znelegida" class="btn btn-primary" type="submit" value="Confluencia 1">
                            <input name="znelegida" class="btn btn-primary" type="submit" value="Confluencia 2">
                            <input name="znelegida" class="btn btn-primary" type="submit" value="Centro">
                            <input name="znelegida" class="btn btn-primary" type="submit" value="Norte">
                            <input name="znelegida" class="btn btn-primary" type="submit" value="Sur">
                            <input name="znelegida" class="btn btn-primary" type="submit" value="Sede Central">
                            <input name="znelegida" class="btn btn-primary" type="submit" value="ECPL">
                        <input name="znelegida" class="btn btn-primary" type="submit" value="Todos">
        </div>
    </form>

    

    <!-- Listado -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Listado de Escuelas         </div>

        <div id="mapa" style="width: 100%; height: 800px;"></div>

        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Centro</th>
                        <th>Domicilio</th>
                        <th>Email</th>
                        <th>Localidad</th>
                        <th>Telefono</th>
                        <th>Tipo</th>
                    </tr>
                </thead>


                <tbody>                        <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580093711">
                                    Apadic                                </a>
                            </td>
                            <td>HONDURAS 1810</td>
                            <td>
                                <a href="mailto:apadicnuevaesperanza@hotmail.com">
                                    apadicnuevaesperanza@hotmail.com                                </a>
                            </td>
                            <td>CENTENARIO</td>
                            <td>2994894521</td>
                            <td>ASOC</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580093709">
                                    Asoc. Arder.                                </a>
                            </td>
                            <td>MINAS 1321</td>
                            <td>
                                <a href="mailto:arder_1997@yahoo.com.ar">
                                    arder_1997@yahoo.com.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>299155795079</td>
                            <td>ASOC</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580084000">
                                    Cea. 1 Las Coloradas                                </a>
                            </td>
                            <td>SIN NOMBRE</td>
                            <td>
                                <a href="mailto:cea001@neuquen.gov.ar">
                                    cea001@neuquen.gov.ar                                </a>
                            </td>
                            <td>LAS COLORADAS</td>
                            <td>2942495038</td>
                            <td>CEMOE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580083100">
                                    Cecalab. 134                                </a>
                            </td>
                            <td>MITRE BARTOLOME 675</td>
                            <td>
                                <a href="mailto:jorgecristian@gmail.com">
                                    jorgecristian@gmail.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>299155212115</td>
                            <td>CECALAB</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580083700">
                                    Cecalab. 135                                </a>
                            </td>
                            <td>MITRE BARTOLOME 675</td>
                            <td>
                                <a href="mailto:fabianmonzon84@hotmail.com">
                                    fabianmonzon84@hotmail.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>299155311450</td>
                            <td>CECALAB</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580083900">
                                    Cecalab. 178                                </a>
                            </td>
                            <td>SAN MARTIN AV 593</td>
                            <td>
                                <a href="mailto:epa012@neuquen.gov.ar">
                                    epa012@neuquen.gov.ar                                </a>
                            </td>
                            <td>PLAZA HUINCUL</td>
                            <td>2994968184</td>
                            <td>CECALAB</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580083300">
                                    Cecalab. 59                                </a>
                            </td>
                            <td>MITRE BARTOLOME 675</td>
                            <td>
                                <a href="mailto:sainzgustavo@hotmail.com">
                                    sainzgustavo@hotmail.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994424698</td>
                            <td>CECALAB</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580102800">
                                    Cei. San Ignacio N. Adultos - San Cabao                                </a>
                            </td>
                            <td>RUTA PROVINCIAL 61 KM 6,5</td>
                            <td>
                                <a href="mailto:ceisanignacio@cruzadapatagonica.org">
                                    ceisanignacio@cruzadapatagonica.org                                </a>
                            </td>
                            <td>SAN CABAO</td>
                            <td>2972429765</td>
                            <td>ASOC</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580049500">
                                    Cemoe. Cef. Namuncura                                </a>
                            </td>
                            <td>PONTE GINES 571</td>
                            <td>
                                <a href="mailto:cemoeceferino@neuquen.gov.ar">
                                    cemoeceferino@neuquen.gov.ar                                </a>
                            </td>
                            <td>JUNIN DE LOS ANDES</td>
                            <td>2972491178</td>
                            <td>CEMOE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580067500">
                                    Cemoe. Hueche Las Coloradas                                </a>
                            </td>
                            <td>SIN NOMBRE</td>
                            <td>
                                <a href="mailto:huechelascoloradas@yahoo.com.ar">
                                    huechelascoloradas@yahoo.com.ar                                </a>
                            </td>
                            <td>LAS COLORADAS</td>
                            <td>2942495038</td>
                            <td>CEMOE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580070900">
                                    Cemoe. M. Champagnat                                </a>
                            </td>
                            <td>ANTARTIDA ARGENTINA 1774</td>
                            <td>
                                <a href="mailto:cemoechampagnat@neuquen.gov.ar">
                                    cemoechampagnat@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994435223</td>
                            <td>CEMOE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580070901">
                                    Cemoe. M. Champagnat Anexo                                </a>
                            </td>
                            <td>CAYASTA</td>
                            <td>
                                <a href="mailto:cemoechampagnat@neuquen.gov.ar">
                                    cemoechampagnat@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994435223</td>
                            <td>CEMOE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580000100">
                                    Cemoe. S.J. Obrero                                </a>
                            </td>
                            <td>PRIMEROS POBLADORES 1123</td>
                            <td>
                                <a href="mailto:cemoesanjoseobrero@gmail.com">
                                    cemoesanjoseobrero@gmail.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994423957</td>
                            <td>CEMOE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580122900">
                                    Ceret                                </a>
                            </td>
                            <td>DE SAN MARTIN JOSE GRL 3293</td>
                            <td>
                                <a href="mailto:ceretnqn2016@yahoo.com">
                                    ceretnqn2016@yahoo.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994467154</td>
                            <td>SUPERIOR</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580123501">
                                    CFP 39 (U 11)                                </a>
                            </td>
                            <td>HUERGO LUIS A ING</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994479304</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580123502">
                                    CFP 39 (U 12)                                </a>
                            </td>
                            <td>VENADO TUERTO</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994479304</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580123503">
                                    CFP 39 (U 16)                                </a>
                            </td>
                            <td>DE SAN MARTIN JOSE GRL 6325</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994479304</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580123505">
                                    CFP 39 Arroyito                                </a>
                            </td>
                            <td>RUTA NACIONAL 22</td>
                            <td>
                                <a href="mailto:cepinivelprimario@neuquen.gov.ar">
                                    cepinivelprimario@neuquen.gov.ar                                </a>
                            </td>
                            <td>ARROYITO</td>
                            <td>2994479304</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580123504">
                                    CFP 39 Senillosa                                </a>
                            </td>
                            <td>ESPINOZA BENITO</td>
                            <td>
                                <a href="mailto:cepinivelsecundario@neuquen.gov.ar">
                                    cepinivelsecundario@neuquen.gov.ar                                </a>
                            </td>
                            <td>SENILLOSA</td>
                            <td>2994479304</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580131600">
                                    CFP 41                                </a>
                            </td>
                            <td>LONCOPUE 550,  (Q8340)</td>
                            <td>
                                <a href="mailto:cfp041@neuquen.edu.ar">
                                    cfp041@neuquen.edu.ar                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>0299 5234696</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580131606">
                                    CFP 41 (CAD) S.M. de los Andes                                </a>
                            </td>
                            <td>ELORRIAGA DAMIAN</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>SAN MARTIN DE LOS ANDES</td>
                            <td></td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580131601">
                                    CFP 41 (U 21)                                </a>
                            </td>
                            <td>RODRIGUEZ CARLOS H 230</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>CUTRAL CO</td>
                            <td>2994964984</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580131602">
                                    CFP 41 (U 22)                                </a>
                            </td>
                            <td>CONQUISTADORES DEL DESIERTO</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>CUTRAL CO</td>
                            <td>2994964984</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580131603">
                                    CFP 41 (U 31)                                </a>
                            </td>
                            <td>TORRES MAYOR</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>2994479304</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580131604">
                                    CFP 41 (U 32)                                </a>
                            </td>
                            <td>FORTABAT ALFREDO</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>2994479304</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580131605">
                                    CFP 41 (U 41)                                </a>
                            </td>
                            <td>LAMADRID GRL</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>JUNIN DE LOS ANDES</td>
                            <td>2994479304</td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580131607">
                                    CFP 41 (U 51)                                </a>
                            </td>
                            <td>SOBERANIA</td>
                            <td>
                                <a href="mailto:cepinivelmedio@gmail.com">
                                    cepinivelmedio@gmail.com                                </a>
                            </td>
                            <td>CHOS MALAL</td>
                            <td></td>
                            <td>CEPI</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580081600">
                                    Cfp. 01                                </a>
                            </td>
                            <td>SANTA CRUZ 742</td>
                            <td>
                                <a href="mailto:cfp001@neuquen.gov.ar">
                                    cfp001@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994430874</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580098800">
                                    Cfp. 02                                </a>
                            </td>
                            <td>HUERGO LUIS A ING</td>
                            <td>
                                <a href="mailto:cfp002@neuquen.gov.ar">
                                    cfp002@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994413431</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580106800">
                                    Cfp. 03                                </a>
                            </td>
                            <td>EL MAIZ</td>
                            <td>
                                <a href="mailto:cfp003@neuquen.gov.ar">
                                    cfp003@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>299155878727</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580111100">
                                    Cfp. 04                                </a>
                            </td>
                            <td>MAIZANI AZUCENA AV 670</td>
                            <td>
                                <a href="mailto:cfp004@neuquen.gov.ar">
                                    cfp004@neuquen.gov.ar                                </a>
                            </td>
                            <td>PLAZA HUINCUL</td>
                            <td>299156563164</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580111200">
                                    Cfp. 05                                </a>
                            </td>
                            <td>BUSTOS PEREZ JOSE</td>
                            <td>
                                <a href="mailto:cfp005@neuquen.gov.ar">
                                    cfp005@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994440314</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580111201">
                                    Cfp. 05 Anexo Añelo                                </a>
                            </td>
                            <td>RUTA PROVINCIAL 17</td>
                            <td>
                                <a href="mailto:centrodeformacionprofesional5@hotmail.com">
                                    centrodeformacionprofesional5@hotmail.com                                </a>
                            </td>
                            <td>ANELO</td>
                            <td>2994440314</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580111300">
                                    Cfp. 06 Uocra.                                </a>
                            </td>
                            <td>GONZALEZ MTRO 450</td>
                            <td>
                                <a href="mailto:cfp006@neuquen.gov.ar">
                                    cfp006@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994474995</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580114400">
                                    Cfp. 07 El Cholar                                </a>
                            </td>
                            <td>RUTA PROVINCIAL 6</td>
                            <td>
                                <a href="mailto:cfp007@neuquen.gov.ar">
                                    cfp007@neuquen.gov.ar                                </a>
                            </td>
                            <td>EL CHOLAR</td>
                            <td>2948492904</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580084900">
                                    Cfp. 08                                </a>
                            </td>
                            <td>BELGRANO MANUEL</td>
                            <td>
                                <a href="mailto:cfp008@neuquen.gov.ar">
                                    cfp008@neuquen.gov.ar                                </a>
                            </td>
                            <td>LONCOPUE</td>
                            <td>2948498068</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580077700">
                                    Cfp. 09                                </a>
                            </td>
                            <td>OLASCOAGA MANUEL AV 1282</td>
                            <td>
                                <a href="mailto:cfp009@neuquen.gov.ar">
                                    cfp009@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994439714</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580084600">
                                    Cfp. 10                                </a>
                            </td>
                            <td>CARREÑO GENARO</td>
                            <td>
                                <a href="mailto:cfp010@neuquen.gov.ar">
                                    cfp010@neuquen.gov.ar                                </a>
                            </td>
                            <td>BUTA RANQUIL</td>
                            <td>2948493238</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580077600">
                                    Cfp. 11                                </a>
                            </td>
                            <td>PETRY MARTIN 534</td>
                            <td>
                                <a href="mailto:cfp011@neuquen.gov.ar">
                                    cfp011@neuquen.gov.ar                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>2942421890</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580081700">
                                    Cfp. 12                                </a>
                            </td>
                            <td>INDEPENDENCIA 446</td>
                            <td>
                                <a href="mailto:cfp012@neuquen.gov.ar; cfp_n12@hotmail.com">
                                    cfp012@neuquen.gov.ar; cfp_n12@hotmail.com                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994483567</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580079100">
                                    Cfp. 13                                </a>
                            </td>
                            <td>LAGO VIEDMA 5826</td>
                            <td>
                                <a href="mailto:cfp013@neuquen.gov.ar">
                                    cfp013@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994467388</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580081200">
                                    Cfp. 14                                </a>
                            </td>
                            <td>CHILE</td>
                            <td>
                                <a href="mailto:cfp014@neuquen.gov.ar">
                                    cfp014@neuquen.gov.ar                                </a>
                            </td>
                            <td>PLOTTIER</td>
                            <td>2994933858</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580074000">
                                    Cfp. 15                                </a>
                            </td>
                            <td>COPAHUE 650</td>
                            <td>
                                <a href="mailto:cfp015@neuquen.gov.ar">
                                    cfp015@neuquen.gov.ar                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>2942423569</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580080300">
                                    Cfp. 16                                </a>
                            </td>
                            <td>SAPAG FELIPE GDOR AV 120</td>
                            <td>
                                <a href="mailto:cfp016@neuquen.gov.ar">
                                    cfp016@neuquen.gov.ar                                </a>
                            </td>
                            <td>ANDACOLLO</td>
                            <td>2948494204</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580077800">
                                    Cfp. 17                                </a>
                            </td>
                            <td>OLASCOAGA MANUEL 363</td>
                            <td>
                                <a href="mailto:cfp017@neuquen.gov.ar">
                                    cfp017@neuquen.gov.ar                                </a>
                            </td>
                            <td>LAS LAJAS</td>
                            <td>2942499585</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580084800">
                                    Cfp. 18 Huinganco                                </a>
                            </td>
                            <td>LOS HUINGANES</td>
                            <td>
                                <a href="mailto:cfp018@neuquen.gov.ar">
                                    cfp018@neuquen.gov.ar                                </a>
                            </td>
                            <td>HUINGANCO</td>
                            <td>2948499049</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580084500">
                                    Cfp. 19                                </a>
                            </td>
                            <td>BROWN ALMTE 717</td>
                            <td>
                                <a href="mailto:cfp019@neuquen.gov.ar">
                                    cfp019@neuquen.gov.ar                                </a>
                            </td>
                            <td>SAN MARTIN DE LOS ANDES</td>
                            <td>2972428891</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580077900">
                                    Cfp. 20                                </a>
                            </td>
                            <td>JAIME DE NEVAREZ Y ATAHUALA YUPANQUI </td>
                            <td>
                                <a href="mailto:cfp020@neuquen.gov.ar">
                                    cfp020@neuquen.gov.ar                                </a>
                            </td>
                            <td>CHOS MALAL</td>
                            <td>2948422998</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580087400">
                                    Cfp. 21                                </a>
                            </td>
                            <td>BELGRANO MANUEL GRL 3385</td>
                            <td>
                                <a href="mailto:cfp021@neuquen.gov.ar">
                                    cfp021@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994450145</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580078000">
                                    Cfp. 22                                </a>
                            </td>
                            <td>SALTA 650</td>
                            <td>
                                <a href="mailto:cfp022@neuquen.gov.ar">
                                    cfp022@neuquen.gov.ar                                </a>
                            </td>
                            <td>CUTRAL CO</td>
                            <td>2994965789</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580085000">
                                    Cfp. 23                                </a>
                            </td>
                            <td>Colon y Mariano Moreno</td>
                            <td>
                                <a href="mailto:cfp023@neuquen.gov.ar">
                                    cfp023@neuquen.gov.ar                                </a>
                            </td>
                            <td>CENTENARIO</td>
                            <td>2994890791</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580089600">
                                    Cfp. 24                                </a>
                            </td>
                            <td>CERRO BAYO 454</td>
                            <td>
                                <a href="mailto:cfp024@neuquen.gov.ar">
                                    cfp024@neuquen.gov.ar                                </a>
                            </td>
                            <td>VILLA LA ANGOSTURA</td>
                            <td>2944488483</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580089601">
                                    Cfp. 24 Anexo Villa Traful                                </a>
                            </td>
                            <td>CARPINTERO GIGANTE</td>
                            <td>
                                <a href="mailto:cfp024@neuquen.gov.ar">
                                    cfp024@neuquen.gov.ar                                </a>
                            </td>
                            <td>VILLA TRAFUL</td>
                            <td></td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580075400">
                                    Cfp. 25                                </a>
                            </td>
                            <td>EMMA CARLOS MAESTRO PSJE 965</td>
                            <td>
                                <a href="mailto:cfp025@neuquen.gov.ar">
                                    cfp025@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994437367</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580080100">
                                    Cfp. 26                                </a>
                            </td>
                            <td>SARMIENTO DOMINGO F</td>
                            <td>
                                <a href="mailto:cfp026@neuquen.gov.ar">
                                    cfp026@neuquen.gov.ar                                </a>
                            </td>
                            <td>CUTRAL CO</td>
                            <td>2994966123</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580082600">
                                    Cfp. 27                                </a>
                            </td>
                            <td>DON BOSCO AV</td>
                            <td>
                                <a href="mailto:cfp027@neuquen.gov.ar">
                                    cfp027@neuquen.gov.ar                                </a>
                            </td>
                            <td>CHOS MALAL</td>
                            <td>2948421121</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580084700">
                                    Cfp. 28                                </a>
                            </td>
                            <td>ITALIA 969</td>
                            <td>
                                <a href="mailto:cfp028@neuquen.gov.ar">
                                    cfp028@neuquen.gov.ar                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>2942431359</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580080200">
                                    Cfp. 29                                </a>
                            </td>
                            <td>DARRIEUX JUAN B 470</td>
                            <td>
                                <a href="mailto:cfp029@neuquen.gov.ar">
                                    cfp029@neuquen.gov.ar                                </a>
                            </td>
                            <td>CENTENARIO</td>
                            <td>2994898762</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580083500">
                                    Cfp. 30                                </a>
                            </td>
                            <td>CANDELARIA TTE 926</td>
                            <td>
                                <a href="mailto:cfp030@neuquen.gov.ar">
                                    cfp030@neuquen.gov.ar                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>2942422243</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580069900">
                                    Cfp. 31                                </a>
                            </td>
                            <td>BELGRANO MANUEL GRL 2250</td>
                            <td>
                                <a href="mailto:cfp031@neuquen.gov.ar">
                                    cfp031@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994432203</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580085300">
                                    Cfp. 32                                </a>
                            </td>
                            <td>OLASCOAGA 385</td>
                            <td>
                                <a href="mailto:cfp032@neuquen.gov.ar">
                                    cfp032@neuquen.gov.ar                                </a>
                            </td>
                            <td>LAS LAJAS</td>
                            <td>2942499468</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580081000">
                                    Cfp. 33                                </a>
                            </td>
                            <td>LEVALLE NICOLAS AV</td>
                            <td>
                                <a href="mailto:cfp033@neuquen.gov.ar">
                                    cfp033@neuquen.gov.ar                                </a>
                            </td>
                            <td>MARIANO MORENO</td>
                            <td>2942490137</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580085700">
                                    Cfp. 34                                </a>
                            </td>
                            <td>ALVAREZ GREGORIO DR 449</td>
                            <td>
                                <a href="mailto:cfp034@neuquen.gov.ar">
                                    cfp034@neuquen.gov.ar                                </a>
                            </td>
                            <td>SENILLOSA</td>
                            <td>2994920810</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580120500">
                                    Cfp. 35                                </a>
                            </td>
                            <td>EL CHOCON 2575</td>
                            <td>
                                <a href="mailto:cfp035@neuquen.gov.ar">
                                    cfp035@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994402754</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580120600">
                                    Cfp. 36                                </a>
                            </td>
                            <td>CABELLERA DEL FRIO 2300</td>
                            <td>
                                <a href="mailto:cfp036@neuquen.gov.ar">
                                    cfp036@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>299154197178 </td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580088600">
                                    Cfp. 37                                </a>
                            </td>
                            <td>SANCHEZ MODESTO PSJE</td>
                            <td>
                                <a href="mailto:cfp16andacollo@gmail.com">
                                    cfp16andacollo@gmail.com                                </a>
                            </td>
                            <td>LAS OVEJAS</td>
                            <td>2948494204</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580124000">
                                    Cfp. 38 Villa Pehuenia                                </a>
                            </td>
                            <td>LOS CONDORES (PEHUENCO) 470</td>
                            <td>
                                <a href="mailto:cfp038@neuquen.gov.ar">
                                    cfp038@neuquen.gov.ar                                </a>
                            </td>
                            <td>VILLA PEHUENIA</td>
                            <td>2942650796</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580133000">
                                    Cfp. 42                                </a>
                            </td>
                            <td>RUTA PROVINCIAL 2</td>
                            <td>
                                <a href="mailto:cfp042@neuquen.edu.ar">
                                    cfp042@neuquen.edu.ar                                </a>
                            </td>
                            <td>TRICAO MALAL</td>
                            <td>0299 5157952</td>
                            <td>CFP</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580094500">
                                    Cfp. Agrop. 1                                </a>
                            </td>
                            <td>RUTA NACIONAL 22 1233</td>
                            <td>
                                <a href="mailto:cfpa001@neuquen.gov.ar">
                                    cfpa001@neuquen.gov.ar                                </a>
                            </td>
                            <td>PLOTTIER</td>
                            <td>2994933758</td>
                            <td>CFPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580094600">
                                    Cfp. Agrop. 2                                </a>
                            </td>
                            <td>ALERCE</td>
                            <td>
                                <a href="mailto:cfpa002@neuquen.gov.ar">
                                    cfpa002@neuquen.gov.ar                                </a>
                            </td>
                            <td>SAN PATRICIO DEL CHAÑAR</td>
                            <td>2994855103</td>
                            <td>CFPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580094700">
                                    Cfp. Agrop. 3                                </a>
                            </td>
                            <td>LOS ALAMOS PSJE 210</td>
                            <td>
                                <a href="mailto:cfpa003@neuquen.gov.ar">
                                    cfpa003@neuquen.gov.ar                                </a>
                            </td>
                            <td>PICUN LEUFU</td>
                            <td>2942492077</td>
                            <td>CFPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580096100">
                                    Cfp. Agrop. 4                                </a>
                            </td>
                            <td>R.I.M. 26 AV 1118</td>
                            <td>
                                <a href="mailto:cfpa004@neuquen.gov.ar">
                                    cfpa004@neuquen.gov.ar                                </a>
                            </td>
                            <td>ALUMINE</td>
                            <td>2942496346</td>
                            <td>CFPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580094800">
                                    Cfp. Agrop. 5                                </a>
                            </td>
                            <td>SAN MARTIN</td>
                            <td>
                                <a href="mailto:cfpa005@neuquen.gov.ar">
                                    cfpa005@neuquen.gov.ar                                </a>
                            </td>
                            <td>CHOS MALAL</td>
                            <td>2948421202</td>
                            <td>CFPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580059200">
                                    Epa. 1                                </a>
                            </td>
                            <td>RICCHIERI PABLO 1095</td>
                            <td>
                                <a href="mailto:epa001@neuquen.gov.ar">
                                    epa001@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994404287</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580017300">
                                    Epa. 10                                </a>
                            </td>
                            <td>RODRIGUEZ LEOPOLDO INTD</td>
                            <td>
                                <a href="mailto:epa010@neuquen.gov.ar">
                                    epa010@neuquen.gov.ar                                </a>
                            </td>
                            <td>SAN MARTIN DE LOS ANDES</td>
                            <td>2972412836</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580050800">
                                    Epa. 11                                </a>
                            </td>
                            <td>LAMADRID GRL 430</td>
                            <td>
                                <a href="mailto:epa011@neuquen.gov.ar">
                                    epa011@neuquen.gov.ar                                </a>
                            </td>
                            <td>JUNIN DE LOS ANDES</td>
                            <td>2972492102</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580061600">
                                    Epa. 14                                </a>
                            </td>
                            <td>ROCA GRL AV 230</td>
                            <td>
                                <a href="mailto:epa014@neuquen.gov.ar">
                                    epa014@neuquen.gov.ar                                </a>
                            </td>
                            <td>PLOTTIER</td>
                            <td>2994938340</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580053600">
                                    Epa. 2                                </a>
                            </td>
                            <td>BROWN ALMTE 1651</td>
                            <td>
                                <a href="mailto:epa002@neuquen.gov.ar">
                                    epa002@neuquen.gov.ar                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>2942421446</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580016100">
                                    Epa. 6                                </a>
                            </td>
                            <td>MISIONES 397</td>
                            <td>
                                <a href="mailto:epa006@neuquen.gov.ar">
                                    epa006@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994422920</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580072700">
                                    Epa. 8                                </a>
                            </td>
                            <td>HONDURAS</td>
                            <td>
                                <a href="mailto:epa008@neuquen.gov.ar">
                                    epa008@neuquen.gov.ar                                </a>
                            </td>
                            <td>CENTENARIO</td>
                            <td>2994894399</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580028200">
                                    Epa. 9                                </a>
                            </td>
                            <td>BUSTOS PEREZ JOSE 750</td>
                            <td>
                                <a href="mailto:epa009@neuquen.gov.ar">
                                    epa009@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994440627</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580007600">
                                    Epa.12                                </a>
                            </td>
                            <td>SAN MARTIN AV 593</td>
                            <td>
                                <a href="mailto:epa012@neuquen.gov.ar">
                                    epa012@neuquen.gov.ar                                </a>
                            </td>
                            <td>PLAZA HUINCUL</td>
                            <td>2994963287</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580045700">
                                    Epa.5                                </a>
                            </td>
                            <td>PAZ GRL 157</td>
                            <td>
                                <a href="mailto:epa005@neuquen.gov.ar">
                                    epa005@neuquen.gov.ar                                </a>
                            </td>
                            <td>CUTRAL CO</td>
                            <td>2994962493</td>
                            <td>EPA</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580042300">
                                    Inst. Salec. Talleres D. Bosco                                </a>
                            </td>
                            <td>PRIMEROS POBLADORES 151</td>
                            <td>
                                <a href="mailto:talleresdonbosco@neuquen.gov.ar">
                                    talleresdonbosco@neuquen.gov.ar                                </a>
                            </td>
                            <td>ZAPALA</td>
                            <td>2942422325</td>
                            <td>INST.PRIVADO</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580097000">
                                    Nuc. Educ. 1                                </a>
                            </td>
                            <td>NOGOYA 2725</td>
                            <td>
                                <a href="mailto:ne001@neuquen.gov.ar">
                                    ne001@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994468234</td>
                            <td>NE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580107800">
                                    Nuc. Educ. 3                                </a>
                            </td>
                            <td>CAYASTA 1100</td>
                            <td>
                                <a href="mailto:ne003@neuquen.gov.ar">
                                    ne003@neuquen.gov.ar                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994469384</td>
                            <td>NE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580099700">
                                    Nuc. Educ. 5                                </a>
                            </td>
                            <td>RIO COLORADO 382</td>
                            <td>
                                <a href="mailto:ne005@neuquen.gov.ar">
                                    ne005@neuquen.gov.ar                                </a>
                            </td>
                            <td>RINCON DE LOS SAUCES</td>
                            <td>2994887414</td>
                            <td>NE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580096800">
                                    Nuc. Educ. 6                                </a>
                            </td>
                            <td>COMBATIENTES DE MALVINAS 35</td>
                            <td>
                                <a href="mailto:ne006@neuquen.gov.ar">
                                    ne006@neuquen.gov.ar                                </a>
                            </td>
                            <td>PIEDRA DEL AGUILA</td>
                            <td>2942493430</td>
                            <td>NE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580112100">
                                    Nuc. Educ. 7 Alumine                                </a>
                            </td>
                            <td>ALVAREZ GREGORIO 536</td>
                            <td>
                                <a href="mailto:ne007@neuquen.gov.ar">
                                    ne007@neuquen.gov.ar                                </a>
                            </td>
                            <td>ALUMINE</td>
                            <td>2942496106</td>
                            <td>NE</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580122904">
                                    UCTATM Energías ren.                                </a>
                            </td>
                            <td>RUTA PROVINCIAL 43</td>
                            <td>
                                <a href="mailto:SIN DATO">
                                    SIN DATO                                </a>
                            </td>
                            <td>LAS OVEJAS</td>
                            <td></td>
                            <td>ATM</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580122901">
                                    UCTATM Inst. dom.                                </a>
                            </td>
                            <td>RUTA PROVINCIAL 18 KM 23</td>
                            <td>
                                <a href="mailto:SIN DATO">
                                    SIN DATO                                </a>
                            </td>
                            <td>RUCA-CHOROI</td>
                            <td></td>
                            <td>ATM</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580122906">
                                    UCTATM Mecánica motos.                                </a>
                            </td>
                            <td>PAISIL JOSE</td>
                            <td>
                                <a href="mailto:SIN DATO">
                                    SIN DATO                                </a>
                            </td>
                            <td>VILLA LA ANGOSTURA</td>
                            <td>2996040329</td>
                            <td>ATM</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580122903">
                                    UCTATM Metalmecánica                                </a>
                            </td>
                            <td>EL PORTON</td>
                            <td>
                                <a href="mailto:SIN DATO">
                                    SIN DATO                                </a>
                            </td>
                            <td>RINCON DE LOS SAUCES</td>
                            <td></td>
                            <td>ATM</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580122902">
                                    UCTATM Soldadura                                </a>
                            </td>
                            <td>JOSE JADULL AV</td>
                            <td>
                                <a href="mailto:SIN DATO">
                                    SIN DATO                                </a>
                            </td>
                            <td>BUTA RANQUIL</td>
                            <td></td>
                            <td>ATM</td>
                        </tr>
                                            <tr>
                            <td>
                                <a class="btn btn-outline-primary btn-sm" href="./datoscentro.php?id=580122905">
                                    UCTATM Textil e indum.                                </a>
                            </td>
                            <td>EL CHOCON 35</td>
                            <td>
                                <a href="mailto:SIN DATO">
                                    SIN DATO                                </a>
                            </td>
                            <td>NEUQUEN</td>
                            <td>2994435680</td>
                            <td>ATM</td>
                        </tr>
                                    </tbody>

                <tfoot>
                    <tr>
                        <th>Centro</th>
                        <th>Domicilio</th>
                        <th>Email</th>
                        <th>Localidad</th>
                        <th>Telefono</th>
                        <th>Tipo</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

</div>


<script>
    function initMap() {
        var latitud = -38.969117;
        var longitud = -68.058615;
        coordenadas = {
            lng: longitud,
            lat: latitud
        }
        generarMapa(coordenadas);
    }

    function generarMapa(coordenadas) {
        var mapa = new google.maps.Map(document.getElementById('mapa'), {
            zoom: 10,
            center: new google.maps.LatLng(coordenadas.lat, coordenadas.lng)
        });
        
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Apadic",
            position: new google.maps.LatLng(-38.81915, -68.146834)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Asoc. Arder.",
            position: new google.maps.LatLng(-38.971285, -68.041111)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cea. 1 Las Coloradas",
            position: new google.maps.LatLng(-39.554613, -70.586946)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cecalab. 134",
            position: new google.maps.LatLng(-38.957293, -68.049802)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cecalab. 135",
            position: new google.maps.LatLng(-38.957293, -68.049802)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cecalab. 178",
            position: new google.maps.LatLng(-38.93084, -69.201923)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cecalab. 59",
            position: new google.maps.LatLng(-38.957293, -68.049802)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cei. San Ignacio N. Adultos - San Cabao",
            position: new google.maps.LatLng(-39.902062, -71.136504)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cemoe. Cef. Namuncura",
            position: new google.maps.LatLng(-39.953219, -71.068499)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cemoe. Hueche Las Coloradas",
            position: new google.maps.LatLng(-39.554613, -70.586946)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cemoe. M. Champagnat",
            position: new google.maps.LatLng(-38.947629, -68.083983)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cemoe. M. Champagnat Anexo",
            position: new google.maps.LatLng(-38.943616, -68.125531)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cemoe. S.J. Obrero",
            position: new google.maps.LatLng(-38.95573, -68.043653)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Ceret",
            position: new google.maps.LatLng(-38.954565, -68.105149)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 39 (U 11)",
            position: new google.maps.LatLng(-38.894687, -68.099047)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 39 (U 12)",
            position: new google.maps.LatLng(-38.943274, -68.124541)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 39 (U 16)",
            position: new google.maps.LatLng(-38.955126, -68.145653)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 39 Arroyito",
            position: new google.maps.LatLng(-39.075522, -68.572348)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 39 Senillosa",
            position: new google.maps.LatLng(-39.001519, -68.435865)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 41",
            position: new google.maps.LatLng(-38.89449384235294, -70.06984257845527)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 41 (CAD) S.M. de los Andes",
            position: new google.maps.LatLng(-40.148583, -71.31528)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 41 (U 21)",
            position: new google.maps.LatLng(-38.933903, -69.231549)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 41 (U 22)",
            position: new google.maps.LatLng(-38.929795, -69.268275)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 41 (U 31)",
            position: new google.maps.LatLng(-38.903565, -70.066555)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 41 (U 32)",
            position: new google.maps.LatLng(-38.881888, -70.053028)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 41 (U 41)",
            position: new google.maps.LatLng(-39.949698, -71.073161)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "CFP 41 (U 51)",
            position: new google.maps.LatLng(-37.375365, -70.277686)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 01",
            position: new google.maps.LatLng(-38.9631, -68.053419)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 02",
            position: new google.maps.LatLng(-38.911157, -68.084814)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 03",
            position: new google.maps.LatLng(-38.906603, -68.13593)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 04",
            position: new google.maps.LatLng(-38.926056, -69.194045)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 05",
            position: new google.maps.LatLng(-38.964462, -68.120393)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 05 Anexo Añelo",
            position: new google.maps.LatLng(-38.344849, -68.781384)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 06 Uocra.",
            position: new google.maps.LatLng(-38.951803, -68.05276)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 07 El Cholar",
            position: new google.maps.LatLng(-37.440461, -70.658115)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 08",
            position: new google.maps.LatLng(-38.072512, -70.61416)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 09",
            position: new google.maps.LatLng(-38.968505, -68.058969)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 10",
            position: new google.maps.LatLng(-37.052722, -69.880845)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 11",
            position: new google.maps.LatLng(-38.899391, -70.053048)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 12",
            position: new google.maps.LatLng(-38.954976, -68.052855)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 13",
            position: new google.maps.LatLng(-38.932787, -68.139316)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 14",
            position: new google.maps.LatLng(-38.949757, -68.23056)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 15",
            position: new google.maps.LatLng(-38.893866, -70.067961)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 16",
            position: new google.maps.LatLng(-37.178651, -70.668393)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 17",
            position: new google.maps.LatLng(-38.525367, -70.361777)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 18 Huinganco",
            position: new google.maps.LatLng(-37.158137, -70.620407)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 19",
            position: new google.maps.LatLng(-40.160472, -71.350259)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 20",
            position: new google.maps.LatLng(-37.35791984239116, -70.27011824389633)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 21",
            position: new google.maps.LatLng(-38.950259, -68.106189)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 22",
            position: new google.maps.LatLng(-38.932557, -69.238305)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 23",
            position: new google.maps.LatLng(-38.83772151006666, -68.13061601861979)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 24",
            position: new google.maps.LatLng(-40.766759, -71.642209)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 24 Anexo Villa Traful",
            position: new google.maps.LatLng(-40.654703, -71.399362)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 25",
            position: new google.maps.LatLng(-38.944553, -68.082613)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 26",
            position: new google.maps.LatLng(-38.937278, -69.235988)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 27",
            position: new google.maps.LatLng(-37.389122, -70.254817)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 28",
            position: new google.maps.LatLng(-38.909981, -70.061301)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 29",
            position: new google.maps.LatLng(-38.828802, -68.122516)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 30",
            position: new google.maps.LatLng(-38.908086, -70.058278)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 31",
            position: new google.maps.LatLng(-38.950392, -68.090488)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 32",
            position: new google.maps.LatLng(-38.52559, -70.362225)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 33",
            position: new google.maps.LatLng(-38.76033, -70.03464)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 34",
            position: new google.maps.LatLng(-39.019992, -68.425399)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 35",
            position: new google.maps.LatLng(-38.969338, -68.02378)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 36",
            position: new google.maps.LatLng(-38.927474, -68.131766)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 37",
            position: new google.maps.LatLng(-36.988861, -70.749957)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 38 Villa Pehuenia",
            position: new google.maps.LatLng(-38.880791, -71.173422)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. 42",
            position: new google.maps.LatLng(-37.048844, -70.326578)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. Agrop. 1",
            position: new google.maps.LatLng(-38.956692, -68.192584)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. Agrop. 2",
            position: new google.maps.LatLng(-38.625889, -68.296632)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. Agrop. 3",
            position: new google.maps.LatLng(-39.5213, -69.295346)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. Agrop. 4",
            position: new google.maps.LatLng(-39.237896, -70.925374)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Cfp. Agrop. 5",
            position: new google.maps.LatLng(-37.369798, -70.271311)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa. 1",
            position: new google.maps.LatLng(-38.962868, -68.044464)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa. 10",
            position: new google.maps.LatLng(-40.150076, -71.357211)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa. 11",
            position: new google.maps.LatLng(-39.950519, -71.069555)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa. 14",
            position: new google.maps.LatLng(-38.951369, -68.237971)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa. 2",
            position: new google.maps.LatLng(-38.896721, -70.054236)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa. 6",
            position: new google.maps.LatLng(-38.958928, -68.063883)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa. 8",
            position: new google.maps.LatLng(-38.825165, -68.137969)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa. 9",
            position: new google.maps.LatLng(-38.962693, -68.122106)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa.12",
            position: new google.maps.LatLng(-38.93084, -69.201923)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Epa.5",
            position: new google.maps.LatLng(-38.938778, -69.22931)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Inst. Salec. Talleres D. Bosco",
            position: new google.maps.LatLng(-38.898391, -70.05723)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Nuc. Educ. 1",
            position: new google.maps.LatLng(-38.949082, -68.096697)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Nuc. Educ. 3",
            position: new google.maps.LatLng(-38.942958, -68.125933)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Nuc. Educ. 5",
            position: new google.maps.LatLng(-37.386774, -68.930185)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Nuc. Educ. 6",
            position: new google.maps.LatLng(-40.049246, -70.075691)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "Nuc. Educ. 7 Alumine",
            position: new google.maps.LatLng(-39.235369, -70.917899)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "UCTATM Energías ren.",
            position: new google.maps.LatLng(-36.983832, -70.746221)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "UCTATM Inst. dom.",
            position: new google.maps.LatLng(-39.21464, -71.138231)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "UCTATM Mecánica motos.",
            position: new google.maps.LatLng(-40.76329, -71.65487)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "UCTATM Metalmecánica",
            position: new google.maps.LatLng(-37.38627, -68.91771)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "UCTATM Soldadura",
            position: new google.maps.LatLng(-37.050987, -69.879111)
        });
                    marcador = new google.maps.Marker({
            map: mapa,
            label: "UCTATM Textil e indum.",
            position: new google.maps.LatLng(-38.969117, -68.058615)
        });
        

    }
</script>

<script async src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmzYlW1ZyJ-eFISPzdq7pt-kxowI5QF-4&callback=initMap"> 
</script>
<!-- Google -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="js/scripts.js"></script>


        
        
                        </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; ST3 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<!--         <script src="assets/demo/chart-area-demo.js"></script> Ejemplo-->
<!--        <script src="assets/demo/chart-bar-demo.js"></script> Ejemplo--> 
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<!--         <script src="js/datatables-simple-demo.js"></script> Ejemplo--> -->
    </body>
</html>