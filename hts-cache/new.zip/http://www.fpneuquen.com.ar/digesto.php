

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-D23TBS0BCN"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-D23TBS0BCN');
    </script>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Web de consulta de Centros de Formacion Profesional" />
    <meta name="author" content="Silvio Stenta" />
    <title>Formacion Profesional WEB</title>
    <link rel="icon" type="image/png" href="img/logofp.png">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
 <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 --></head>

<body class="sb-nav-fixed">
    <nav class="navbar navbar-expand-lg navbar-dark ">
        <!-- Navbar Brand-->
        <button class="btn btn-link btn-sm order-1 order-lg-1 me-4 me-lg-1" id="sidebarToggle" href="index.php">
            <i class="fas fa-bars fa-lg "></i></button>
        <a class="navbar-brand ps-3" href="index.php"><img src="img/logo fp 288x271.png" class="img-fluid" alt="max-width: 30%;height: auto" width="20%"></a>
        <!-- Sidebar Toggle-->

        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <!-- <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button> -->
            </div>
        </form>
        <!-- Navbar User-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="login.php">Login</a></li>
                    <li><a class="dropdown-item" href="./administrador/inicio.php">Settings</a></li>
                    <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="cerrar.php">Cerrar</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <!-- Navbar Lateral -->

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-primary" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Todas las Escuelas
                        </a>
                        <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                            </nav>
                        </div>
                        <!-- <div class="sb-sidenav-menu-heading">Addons</div> -->
                        <!--                         <a class="nav-link" href="charts.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Graficos
                        </a> -->


                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseCFP" aria-expanded="false" aria-controls="collapseCFP">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Centros
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseCFP" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="table.php"><i class="fa fa-book" aria-hidden="true"></i>Listado por Zona</a>
                                <a class="nav-link" href="centrosxzonas.php"><i class="fas fa-map-pin" aria-hidden="true"></i>Ubicacion por Zona</a>
                            </nav>
                        </div>


                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseTray" aria-expanded="false" aria-controls="collapseTray">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Trayectos Formativos
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseTray" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="Sectores.php">
                                    <div class="sb-nav-link-icon"> <i class="fa-brands fa-bandcamp"></i></div>
                                    Sectores Productivos
                                </a>
                                <a class="nav-link" href="SubSectores.php">
                                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                    Sub-Sectores
                                </a>
                                <a class="nav-link" href="TrayectosFormativos.php">
                                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                    Trayectos Formativos
                                </a>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>

                    invitado                </div>
            </nav>
        </div>
        <!-- Principal -->



        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="js/scripts.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.css" />
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/fc-4.0.2/r-2.2.9/rr-1.2.8/sc-2.0.5/sl-1.3.4/datatables.min.css" />

        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/fc-4.0.2/r-2.2.9/rr-1.2.8/sc-2.0.5/sl-1.3.4/datatables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.1/b-2.2.3/b-colvis-2.2.3/b-html5-2.2.3/b-print-2.2.3/datatables.min.js"></script>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

        <div id="layoutSidenav_content">
            <main>


<form method="POST" enctype="multipart/form-data">

    <div class="form-group row">
        <label for="txtNormaLegal"class="col-sm-2 col-form-label">Norma Legal</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="txtNormaLegal" id="txtNormaLegal"  aria-describedby="emailHelp" placeholder="Norma Legal">
        </div>
    </div>

    <div class="form-group row">
        <label for="txtAnio" class="col-sm-2 col-form-label">Año</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="txtAnio"id="txtAnio"  aria-describedby="emailHelp" placeholder="Año">
        </div>
    </div>

    <div class="form-group row">
        <label for="txtSector"class="col-sm-2 col-form-label">Sector</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="txtSector"id="txtSector"  aria-describedby="emailHelp" placeholder="Sector">
        </div>
    </div>

    <div class="form-group row">
        <label for="txtTipo"class="col-sm-2 col-form-label">Tipo</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="txtTipo" id="txtTipo" aria-describedby="emailHelp" placeholder="Tipo de Norma">
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>

</form>

<div class="container-fluid px-2">
    <h1 class="">Digesto de la E.T.P.</h1>
    <ol class="breadcrumb mb-1">
        <li class="breadcrumb-item"><a href="index.php">Escritorio</a></li>
        <li class="breadcrumb-item active">Listado </li>
    </ol>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Normativas de la Educación Tecnico Profesional //
            <a href="https://www.argentina.gob.ar/educacion/documentos-cfe/resoluciones">Normativas Nacionales de Educación</a>
        </div>

        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Norma Legal</th>
                        <th>año</th>
                        <th>Contenido</th>
                        <th>Sector</th>
                        <th>Tipo</th>
                        <th>Descargar</th>
                    </tr>
                </thead>


                <tbody>
                                            <tr>
                            <td>
                                422
                            </td>
                            <td>
                                2022                            </td>
                            <td>
                                Aprueba la actualización para el Programa federal de Aulas Talleres Móviles                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="http://www.bnm.me.gov.ar/giga1/normas/RCFE_422-22.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=1">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                410
                            </td>
                            <td>
                                2021                            </td>
                            <td>
                                Aprueba los Referenciales de Evaluación de FINESTEC de las especialidades correspondientes a Técnico/a en Industrialización de la Madera y el Mueble y a Técnico/a en Energías Renovables que, como Anexos I y II integran la presente, a efectos de orientar el desarrollo y procesos de evaluación de los espacios formativos del segundo ciclo de la educación técnica de nivel secundario de las mencionadas especialidades.                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/rcfe_410-21.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=2">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                409
                            </td>
                            <td>
                                2021                            </td>
                            <td>
                                Establece una nueva trayectoria formativa propia de la modalidad de Educación Técnico Profesional cuyo diseńo, desde la perspectiva de la Formación Profesional, integra a ella los núcleos de aprendizaje prioritarios de la Educación Secundaria para el cumplimiento del nivel obligatorio establecido en la Ley de Educación Nacional N° 26.206.                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/rcfe_409-21.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=3">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                408
                            </td>
                            <td>
                                2021                            </td>
                            <td>
                                Aprueba el documento “APORTE ECONÓMICO DIRECTO PARA LAS INSTITUCIONESDE ETP”, que es el considerado como Fodo escolar y transferido mediante ticket nación.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/rcfe_408-21.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=4">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                399
                            </td>
                            <td>
                                2021                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia para los procesos de homologación de Formación Profesional Inicial, correspondientes a los certificados de: “Bombera/o” de nivel II, “Instalador/a y Reparador/a de equipos de climatización” de nivel III, “Maquillador/a” de nivel II, “Guardavidas” de nivel III, “Inventariador/a” de nivel II, “Operador/a de clasificación, corte y armado de bastidores de maderas” de nivel II, “Productor/a de porcinos” de nivel III, “Asistente de la producción porcina” de nivel II, y “Elaborador/a de chacinados y salazones” de nivel III, ( anexos I, II, III, IV, V, VI, VII, VIII y IX respectivamente)                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/rcfe_399-21.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=5">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                395
                            </td>
                            <td>
                                2021                            </td>
                            <td>
                                Aprobar la continuidad del Programa "Capacitación Laboral de Alcance Nacional" (CLAN)                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/rcfe_395-21.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=6">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                385
                            </td>
                            <td>
                                2020                            </td>
                            <td>
                                Aprobar la renovación de la vigencia PROGRAMA FEDERAL DE ENFERMERÍA                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_385_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=7">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                384
                            </td>
                            <td>
                                2020                            </td>
                            <td>
                                Aprobar el documento “DOCUMENTO MARCO PARA LA REALIZACIÓN DE PRÁCTICAS PROFESIONALIZANTES DE TERCER AŃO ENINSTITUCIONES DE EDUCACIÓN TÉCNICA SUPERIOR FORMADORAS DE ENFERMERÍA”                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res-cfe-384_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=8">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                381
                            </td>
                            <td>
                                2020                            </td>
                            <td>
                                Aprobar el documento "Recomendado de Diseńo Curricular de la Trayectoria Formativa de Formación Profesional Continua de especialización del Gestor Energético en Inmuebles” y Aprobar el documento “Módulos Iniciales complementarios de sugerencia para el ingreso a esta formación con diversos ttulos y certificados”                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe-381_y_anexos.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=9">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                380
                            </td>
                            <td>
                                2020                            </td>
                            <td>
                                Aprobar el documento del marco de referencia correspondiente a la especialidad de “Electromecánica naval” de nivel secundario                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe-380_y-anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=10">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                379
                            </td>
                            <td>
                                2020                            </td>
                            <td>
                                Aprobar, en función de lo establecido en la Resolución CFE Nş 368/2020 en cuanto a la evaluación, acreditación y graduación de los estudiantes del último ańo de la Educación Técnico Profesional de nivel secundario y Aprobar los documentos orientadores construidos y acordados por la Comisión Federal de Educación Técnico Profesional, “Evaluación y acreditación en contexto de pandemia para la ETP”, “Las prácticasprofesionalizantes en contexto de pandemia”                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_379_y_anexos.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=11">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                371
                            </td>
                            <td>
                                2020                            </td>
                            <td>
                                Aprobar el documento “Protocolo específico y recomendaciones para la realización de prácticas en los entornos formativos de la Educación Técnico Profesional – ETP (Talleres, Laboratorios y Espacios Productivos)”                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_371_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=12">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                355
                            </td>
                            <td>
                                2019                            </td>
                            <td>
                                Aprobar los lineamientos comunes para la organización e implementación de ofertas formativas entre la Formación Profesional y Secundaria parajóvenes entre 15 y 18 ańos.                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_355_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=13">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                354
                            </td>
                            <td>
                                2019                            </td>
                            <td>
                                Aprobación del marco de referencia correspondiente a la especialidad de "Seguridad Pública -Oficial de Policía" de nivel superior                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_354_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=14">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                353
                            </td>
                            <td>
                                2019                            </td>
                            <td>
                                Aprobación de los marcos de referencia para la formación profesional inicial de los perfiles profesionales: instalador de sistemas de automatización,elaborador de quesos, elaborador de helados y bombero voluntario                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_353_y_anexos.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=15">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                352
                            </td>
                            <td>
                                2019                            </td>
                            <td>
                                Aprobación de los marcos de referencia de las especialidades de Ciencia de datos e inteligencia artificial, Diseńo y desarrollo de productos mecánicos,Mecatrónica, y Gestión de energías renovables de nivel superior                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_352_19_y_anexos.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=16">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                351
                            </td>
                            <td>
                                2019                            </td>
                            <td>
                                Aprobación de los documentos recomendados de diseńo curricular de la Trayectoria Formativa de Formación Profesional Continua de programador web,programador de dispositivos móviles y programador de videojuegos                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_351_19_y_anexos.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=17">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                344
                            </td>
                            <td>
                                2018                            </td>
                            <td>
                                Aprueba el documento: Dispositivo de acreditación y certificación de saberes socio-laborales en la ETP                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_344_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=18">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                341
                            </td>
                            <td>
                                2018                            </td>
                            <td>
                                Aprueba el documento: La educación técnico profesional de nivel secundario: orientaciones para su innovación                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_341_18_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=19">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                336
                            </td>
                            <td>
                                2018                            </td>
                            <td>
                                Aprueba el Marco de referencia de Instalador Sistemas Eléctricos de Energías Renovables                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_336_18_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=20">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                335
                            </td>
                            <td>
                                2018                            </td>
                            <td>
                                Aprueba el marco de referencia de Instalador de Sistemas Solares Térmicos para Agua Caliente Sanitaria                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_335_18_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=21">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                334
                            </td>
                            <td>
                                2018                            </td>
                            <td>
                                Aprueba el marco de referncia del agente de policía                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res_cfe_334_18_y_anexo.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=22">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                309
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba aporte económico básico destinado a la adquisición de herramental menor de propósito general para las prácticas formativas de taller, laboratorioo espacios productivos de las instituciones de Educación Técnica Profesional de gestión estatal y de gestión privada                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/309-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=23">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                308
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Documento “Criterios de orientación para la articulación entre Formación Profesional – Educación Permanente de Jóvenes y Adultos” Anexo I Criterios de orientación para la articulación entre FP - EPJA. Anexo II Criterios y orientaciones: dispositivos de acreditación de Educación Secundaria EDJA para formación profesional.                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/308-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=24">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                307
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                creación del “Programa Federal de Promoción y Capacitación Docente en Energías Renovables”, cuya características y condiciones de implementación se detallan en el anexo I..                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/307-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=25">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                306
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el Programa Federal “Provisión de textos escolares para Instituciones de Educación Técnico Profesional”                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/306-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=26">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                305
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el Programa Federal “Unidades Integrales de la Educación Técnico Profesional”                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/305-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=27">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                304
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el Programa Federal Aulas Talleres Móviles para la Formación Profesional (ATMETP) (2016/2019)                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/304-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=28">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                297
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el Perfil Profesional de “Docente de Educación Técnico Profesional de nivel secundario”                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/297-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=29">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                296
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba la modificación del “PROGRAMA NACIONAL DE FORMACIÓN DOCENTE INICIAL PARA LA EDUCACIÓN TÉCNICO PROFESIONAL”                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/296-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=30">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                295
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el Documento “CRITERIOS PARA LA ORGANIZACIÓN INSTITUCIONAL Y LINEAMIENTOS PARA LA ORGANIZACIÓN DE LA OFERTA FORMATIVA PARA LA EDUCACIÓN TÉCNICO PROFESIONAL DE NIVEL SUPERIOR"                            </td>
                            <td>
                                Superior                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/295-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=31">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                290
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba la Creación PROGRAMA FEDERAL DE ENFERMERÍA                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/290-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=32">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                289
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba los documentos Marco de Referencia para la Formación Profesional Inicial de la figura formativa de Programador nivel de certificación III y el Diseńo Curricular para dicha figura formativa.                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/289-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=33">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                288
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el documento de orientaciones y criterios para el desarrollo de la Formación Profesional Continua y la Capacitación Laboral                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/288-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=34">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                287
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el documento de lineamientos y criterios curriculares para la Formación Profesional                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/287-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=35">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                283
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el documento “Mejora Integral de la Calidad de la Educación Técnico Profesional”                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/283-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=36">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                279
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el documento “Mejora continua de las condiciones de la infraestructura física educativa de las instituciones de Educación Técnico Profesional“                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/279-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=37">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                278
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Aprueba el programa “Capacitación Laboral de Alcance Nacional” (CLAN) 2016-2017, para el fortalecimiento de la Educación Secundaria Orientada, enel marco de la Formación Complementaria                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res16/278-16.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=38">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                274
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Aprueba el marco del calendario académico anual, las instancias escolares y regionales y la instancia nacional, de las “Olimpiadas de Construcciones y Electromecánica”                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/274-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=39">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                273
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Incorporación de proyectos tecnológicos de dispositivos asistidos para personas con discapacidad a las actividades formativas de planes de estudio dela Educación Técnico Profesional.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/273-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=40">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                272
                            </td>
                            <td>
                                2020                            </td>
                            <td>
                                Declara de Interés Educativo el Campeonato Argentino de Autos Ecológicos "DESAFIO ECO".                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res20/272-20.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=41">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                267
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Aprueba aporte económico básico destinado a la adquisición de herramental menor de propósito general para las prácticas formativas.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/267-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=42">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                266
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Aprueba referenciales de evaluación para finalización de estudios y documento de evaluación de capacidades                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/266-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=43">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                264
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Aprueba continuidad del Programa “Capacitación Laboral de Alcance Nacional” (CLAN) 2015- 2016, para el fortalecimiento de la Educación SecundariaOrientada, en el marco de la Formación Complementaria.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/264-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=44">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                259
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Documento de entorno formativo de la especialidad “Producción agropecuaria” de nivel secundario.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/259-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=45">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                258
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Programa Federal “Adquisición de impresoras 3D para las Escuelas Secundarias Técnicas y los Institutos Superiores Técnicos."                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/258-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=46">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                250
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Aprueba entornos formativos de fp                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/250-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=47">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                249
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Extender el plazo de vigencia del Programa Nacional de FormaciónDocente Inicial para la Educación Técnico Profesional, aprobado por la Resolución CFE Nş 64/08, hasta la finalización del ańo 2015                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/249-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=48">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                246
                            </td>
                            <td>
                                2015                            </td>
                            <td>
                                Reconocer que los Planes de Estudio de Gasista de Unidades Unifuncionales y de Gasista Domiciliario, correspondientes al instalador de gas matriculado de tercera y segunda categoría respectivamente, se ajustan en un todo a la estructura curricular, perfil profesional y trayectoria formativa,establecidos en la Resolución CFE N° 204/13.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res15/246-15.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=49">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                243
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Aprobar Lineamientos y Criterios para el Funcionamiento de la RED NACIONAL DE AULAS TALLERES MOVILES.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/243-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=50">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                238
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Extender mecanismo de ejecución aprobado por la Resolución CFE Nş 213/13 incluyendo a las instituciones de ETP de gestión estatal como de gestiónprivada que cumplan con apartado 56 de la Resolución CFE N° 175/12 e incorporadas al Registro Federal de Instituciones de Educación Técnico Profesional. Aprobar criterios y procedimientos generales y fórmula para distribución del aporte económico.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/238-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=51">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                237
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Aprobar mecanismo de ejecución para que las instituciones de ETP de gestión estatal dispongan de aporte económico básico para reparacionesmenores y/o la adquisición de mobiliario escolar. Criterios y procedimientos generales para la implementación.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/237-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=52">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                236
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Aprobar las “Condiciones para el desarrollo del Régimen de Alternancia en Instituciones de Educación Técnico Profesional de Nivel Secundario”                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/236-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=53">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                235
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Aprobar el documento “Lineamientos y criterios para la planificación didáctico productiva en las Escuelas Técnicas Agropecuarias”.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/235-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=54">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                234
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Incorporar desde el ańo 2015 como efeméride educativa, el día 7 de septiembre como “Día de la Recuperación de la Educación Técnica”, enconmemoración de los 10 ańos de la sanción de la Ley Nş 26.058 de Educación Técnico Profesional. Organización de actividades conmemorativas.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/234-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=55">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                231
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Prorroga alcances de la Resolución CFE N°216/14 para primer trimestre de 2015. Desarrollo e implementación de cursos en el marco del Programa"Capacitación Laboral de Alcance Nacional (CLAN)" para el fortalecimiento de la Educación Secundaria Orientada.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/231-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=56">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                230
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Aprueba el documento “Disposición de los Bienes y Servicios Producidos en las Instituciones de Educación Técnico Profesional”.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/230-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=57">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                229
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Aprueba el documento “Criterios federales para la organización institucional y lineamientos curriculares de la ETP del nivel secundario y superior”.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/229-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=58">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                216
                            </td>
                            <td>
                                2014                            </td>
                            <td>
                                Aprobación del Programa “Capacitación Laboral de Alcance Nacional (CLAN)” para el fortalecimiento de la Educación Secundaria Orientada en el marcode la Formación Complementaria.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res14/216-14.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=59">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                213
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Aprobar, para el ciclo lectivo 2014, un mecanismo de ejecución que permita a las instituciones de ETP de gestión estatal, disponer de un aporteeconómico básico, destinado a la adquisición de insumos para la realización de prácticas formativas.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/213-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=60">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                211
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Prorroga hasta el 31 de diciembre de 2015 los plazos de vigencia de los dictámenes expedidos por la Comisión Federal de Registro y Evaluación Permanente de las Ofertas de Educación a Distancia de aprobación plena y con reservas por dos ańos, que caduquen en el ańo 2014, las que deberán presentarse a una nueva evaluación en la convocatoria 2015. Para la convocatoria 2014 sólo podrán presentarse aquellas instituciones cuyas ofertas tengan antecedentes de implementación y hayan obtenido dictámenes de no aprobación o aprobación con reservas por un ańo emitidos hasta diciembre de 2013 y nuevas propuestas formativas a distancia correspondientes a estudios de nivel secundario, postítulos docentes y tecnicaturas con marcos dereferencia aprobados hasta la fecha por el Consejo Federal.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/211-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=61">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                209
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Sustituye el párrafo 68 del anexo I de la Resolución CFE N° 47/08, por el que queda establecido en el Anexo I de la presente resolución.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/209-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=62">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                208
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Aprueba el Documento “Estrategia federal de acompańamiento pedagógico a los estudiantes con materias pendientes de aprobación de la EducaciónTécnico Profesional de nivel secundario, FinEsTec” (Anexo I).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/208-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=63">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                207
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Aprueba los documentos de los marcos de referencia correspondientes a las especialidades de nivel superior de: “Gestión y mantenimiento deequipamiento biomédico”, “Radiología”, “Laboratorio de análisis clínicos” y “Enfermería”. (Anexos I, II, III y IV respectivamente).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/207-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=64">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                204
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Aprueba los documentos de estructura de la trayectoria formativa “Gasista Domiciliario” y los marcos de referencia para la Formación Profesional Inicialde los siguientes perfiles profesionales: Auxiliar en instalaciones sanitarias y de gas domiciliarias, Montador de instalaciones domiciliarias de gas, gasista de unidades unifuncionales y gasista domiciliario (Anexos I, II, III, IV y V respectivamente).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/204-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=65">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                203
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Aprueba el Programa Federal “Construcción de edificios nuevos para instituciones de Educación Técnico Profesional” (Anexo),                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/203-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=66">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                197
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Aprueba, extendiendo los alcances de la Res. CFE N° 175/12, el Programa Federal de “Asistencia Técnica Institucional y Jurisdiccional” a serimplementado en instituciones de Educación Técnico Profesional de nivel secundario de gestión estatal, cuyos objetivos y principales líneas de acción del plan de trabajo 2013 se explicitan en el Anexo I de la presente resolución.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/197-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=67">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                196
                            </td>
                            <td>
                                2013                            </td>
                            <td>
                                Aprueba la generación e implementación de un programa federal que posibilite completar, actualizar y perfeccionar los pisos de tecnología de lainformación y la comunicación existentes en las escuelas secundarias técnicas de gestión estatal.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res13/196-13.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=68">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                178
                            </td>
                            <td>
                                2012                            </td>
                            <td>
                                Aprueba los documentos de los marcos de referencia para la Formación Profesional Inicial, de los siguientes perfiles profesionales, según el nivel de certificación que en cada caso corresponda: Gasista de Unidades Unifuncionales; Mecánico de Motores de Combustión Interna; Mecánico de Transmisiones; Mecánico de Sistemas de Suspensión y Dirección del Automotor; Chapista de Automotores; Pintor de Automotores; Electricista de Centrales de Generación de Energía Eléctrica; Electricista de Redes de Alta Tensión; Instalador de Sistemas Eléctricos de Energía Renovable; Instalador de Sistemas de Muy Baja Tensión; Montador Tablerista en Sistemas de Potencia; Bobinador de Máquinas Eléctricas; Horticultor; Operario Hortícola; Moldeador; Modelista en Madera; Operador de Matricería; Operador deHornos para Tratamientos Térmicos; Operador de Horno a Inducción para la Fusión de Metales; Operador de Horno Cubilote; Operador de Máquinas e Instrumentos de Medición y Auxiliar de Laboratorio. (Anexos I a XXII)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res12/178-12.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=69">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                177
                            </td>
                            <td>
                                2012                            </td>
                            <td>
                                Aprueba los documentos de los marcos de referencia correspondientes a las especialidades de “Gestión ambiental” de nivel superior y de “Comerciointernacional” de nivel superior. (Anexos I y II, respectivamente)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res12/177-12.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=70">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                176
                            </td>
                            <td>
                                2012                            </td>
                            <td>
                                Aprueba el “Programa Federal Red de Aulas Talleres Móviles de ETP”. (Anexo I)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res12/176-12.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=71">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                175
                            </td>
                            <td>
                                2012                            </td>
                            <td>
                                Aprueba el documento “Mejora continua de la calidad de los entornos formativos y las condiciones institucionales de la Educación Técnico Profesional”en remplazo del documento aprobado por Resolución CFE Nş 62/08 Anexo I y de las Resoluciones CFE Nos. 106/10, 125/10, 145/11 y 146/11. (Anexo I) Aprueba el coeficiente de distribución del Fondo Nacional para la Educación Técnico Profesional. (Anexo II)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res12/175-12.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=72">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                158
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Aprueba los documentos de los marcos de referencia para la Formación Profesional Inicial, de los siguientes perfiles profesionales según el nivel decertificación que en cada caso corresponda: Auxiliar de aserradero, Operador de sala de afilado, Operador de máquina principal de aserradero, Operador de moldurera, Operador de secado y tratamiento térmico de la madera y Gasista domiciliario. (Anexos I al VI)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/158-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=73">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                157
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Aprueba los documentos de los marcos de referencia correspondientes a las especialidades de “Indumentaria y productos de confección textil” de nivelsecundario y de “Industrialización de la madera y el mueble” de nivel secundario. (Anexos I y II)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/157-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=74">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                150
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Aprueba los documentos de los marcos de referencia para la Formación Profesional Inicial de: Asistente de producción lechera; Operario en producciónlechera; Armador y montador de andamios para obras civiles; Armador y montador de componentes metálicos livianos; Armador y montador de paneles y cielorrasos de placas de roca de yeso; Auxiliar en construcciones en seco con componentes livianos; Colocador de revestimientos decorativos y funcionales; Pintor de obra; Yesero; Confeccionista a medida: Modista/o; Modelista – Patronista; Operador cortador de industria indumentaria yOperador de máquinas para la confección de indumentaria (Anexos I al XIII).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/150-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=75">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                149
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Aprueba los marcos de referencia para la Formación Profesional Inicial de: Electricista de automotores, Mecánico de motos, Mecánico electrónico deautomotores, Rectificador de motores de combustión interna, Electricista de redes de distribución de media y baja tensión, Electricista en inmuebles, Electricista industrial, Ama de llaves, Cocinero, Mozo/Camarero de salón, Mucama, Organizador de eventos, Organizador de operaciones hoteleras, Panadero, Pastelero, Recepcionista, Plegador, Programador y Operador de máquinas comandadas a control numérico computarizado para el conformado de materiales y Auxiliar en cuidados gerontológico (Anexos I al XIX).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/149-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=76">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                148
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Aprueba el marco de referencia de “Técnico en Programación” de nivel secundario (Anexo I).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/148-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=77">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                147
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Aprueba la ampliación del plan de estudios "Profesorado de educación secundaria de la modalidad técnico profesional en concurrencia con título debase" (Anexo I).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/147-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=78">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                146
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                En el marco de la línea de acción relativa a la refacción integral de edificios contemplado en el Programa de Mejora Continua de la Calidad de laEducación Técnico Profesional, modifica el monto de inversión en proyectos de refacción integral indicado como máximo en el artículo 1° de la Resolución CFE N° 125/10 y la superficie máxima a construir para ampliación de la superficie disponible indicado como máximo en el apartado 46 del Anexo I de la Resolución CFE N° 62/08 y el apartado 5 de la Resolución N° 51/08.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/146-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=79">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                145
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Incorpora en el Anexo I de la Resolución CFE N° 62/08, Capítulo IV. Líneas de Acción, apartado 46, inciso f), el componente: “Asesoramiento, asistencia técnica y capacitación en normativas bromatológicas y de bioseguridad, en laboratorios, talleres y espacios productivos” (Anexo I) Introduce modificaciones en el Anexo I de la Resolución CFE N° 62/08, Capítulo IV. Líneas de Acción, apartado 46, incisos f) y g), relativas a los componentes:“Condiciones de higiene y seguridad en talleres, laboratorios y espacios productivos en que se desarrollan las prácticas pre profesionales yprofesionalizantes” y “Acondicionamiento edilicio”.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/145-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=80">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                131
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Extender el plazo de vigencia del Programa Nacional de Formación Docente Inicial para la Educación Técnico Profesional, aprobado por la ResoluciónCFE 64/08, hasta la finalización del primer semestre del ańo 2014.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/131-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=81">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                130
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia para la Formación Profesional Inicial de los siguientes perfiles profesionales, según el nivel de certificación que en cada caso corresponda: Carpintero metálico y de PVC- Nivel II; Programador de máquinas comandadas a control numérico computarizado para el arranque de viruta-Nivel III; Operador de máquinas comandadas a control numérico computarizado para el arranque de viruta- Nivel II; Zinguero -Nivel II; Gomero balanceador –Nivel II; Auxiliar electricista de redes de distribución de media y baja tensión-Nivel II y Auxiliarelectricista industrial-Nivel II (Anexos N°s I al VII)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/130-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=82">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                129
                            </td>
                            <td>
                                2011                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia correspondientes a las especialidades de “Administración y gestión” de nivel secundario y de“Prácticas cardiológicas”, “Neurofisiología”, “Forestal”, “Desarrollo de software”, “Tecnología de los alimentos” y “Bromatología” de nivel superior (AnexosN°s I al VII)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res11/129-11.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=83">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                126
                            </td>
                            <td>
                                2010                            </td>
                            <td>
                                Aprueba la prórroga del Programa Nacional de Formación Docente Inicial para la Educación Técnico Profesional en los términos indicados para cada provincia en el Anexo I,Establece que el Programa tendrá vigencia hasta la finalización del primer semestre del ańo 2013, aplicándose este término a las cohortes que se inician en el segundo semestre de 2010 y que su continuidad estará sujeta a una evaluación de resultados.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res10/126-10.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=84">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                125
                            </td>
                            <td>
                                2010                            </td>
                            <td>
                                Modifica el monto de inversión en proyectos de refacción integral indicado como máximo en los apartados 46 del Anexo I de la Resolución CFE N° 62/08y 7 del Anexo I de la Resolución CFE N° 51/08, elevándolo a TRES MILLONES SETECIENTOS MIL ($3.700.000).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res10/125-10.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=85">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                121
                            </td>
                            <td>
                                2010                            </td>
                            <td>
                                Declarar de interés educativo la “Conferencia Nacional de Educación Técnico Profesional en el Bicentenario”, que tendrá lugar en la ciudad de Córdobalos días 3 al 5 de noviembre de 2010.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res10/121-10.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=86">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                115
                            </td>
                            <td>
                                2010                            </td>
                            <td>
                                Aprobar el Documento “Lineamientos y criterios para la organización institucional y curricular de la Educación Técnico Profesional correspondiente a laFormación Profesional”. (Anexo I)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res10/115-10.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=87">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                114
                            </td>
                            <td>
                                2010                            </td>
                            <td>
                                Subsumir el Programa Nacional “UNA COMPUTADORA PARA CADA ALUMNO” como parte del Programa “CONECTAR IGUALDAD.COM.AR”.Establecer que, a partir de la aprobación de la presente Resolución, el Programa Nacional “UNA COMPUTADORA PARA CADA ALUMNO” adopta como criterios de operación los establecidos por el Comité Ejecutivo del Programa “CONECTAR IGUALDAD.COM.AR” y se enmarca en los compromisos de las partes expresados en los convenios refrendados por las máximas autoridades provinciales y de la Ciudad Autónoma de Buenos Aires. Conservar dentro del Programa de Mejora Continua de la Calidad de la Educación Técnico Profesional, aprobado por Resolución CFE N° 62/08, las líneas de acción que brinden apoyo al desarrollo del Programa CONECTAR IGUALDAD.COM.AR, en los establecimientos de ETP de nivel secundario, en términos similares a los establecidos en la Resolución CFE N° 82/09.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res10/114-10.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=88">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                108
                            </td>
                            <td>
                                2010                            </td>
                            <td>
                                siguientes perfiles profesionales, según el nivel de certificación que en cada caso corresponda: Albańil-Nivel II; Armador de Hierros para HormigónArmado- Nivel II; Auxiliar en Construcciones-Nivel I; Auxiliar en Instalaciones Eléctricas Domiciliarias Nivel I; Auxiliar en Instalaciones Sanitarias y de Gas Domiciliarias-Nivel I; Carpintero de Obra Fina- Nivel II; Carpintero para Hormigón Armado- Nivel II; Colocador de Revestimientos de Base Húmeda Nivel II; Montador de Instalaciones Domiciliarias de Gas Nivel II; Montador de Instalaciones Sanitarias Domiciliarias- Nivel II; Techista de Faldones Inclinados-Nivel II; Montador Electricista Domiciliario-Nivel II; Mecánico Instalador de Equipos de GNC Nivel II; Herrero- Nivel II; Rectificador- Nivel II;Soldador Básico y Soldador Nivel II (Anexos I a XVII respectivamente).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res10/108-10.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=89">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                107
                            </td>
                            <td>
                                2010                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia correspondientes a las especialidades de “Óptica” de nivel secundario y de “Soporte deinfraestructura de tecnología de la información” de nivel superior, que se (Anexos I y II, respectivamente)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res10/107-10.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=90">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                106
                            </td>
                            <td>
                                2010                            </td>
                            <td>
                                Aprobar la incorporación de una línea de acción denominada “Aulas Móviles de ETP” en el Documento: Mejora Continua de la Calidad de la EducaciónTécnico Profesional, aprobado por Resolución CFE N° 62/08, Anexo I                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res10/106-10.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=91">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                91
                            </td>
                            <td>
                                2009                            </td>
                            <td>
                                Aprobar los "Lineamientos y criterios para la inclusión de títulos técnicos de nivel secundario y de nivel superior y certificados de formación profesional en el proceso de homologación" (Anexo I). Establecer la primera nómina de títulos técnicos y certificados de formación profesional, de carácter taxativo,a ser incorporados al proceso de homologación (Anexo II).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res09/91-09.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=92">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                90
                            </td>
                            <td>
                                2009                            </td>
                            <td>
                                Encomendar al MINISTERIO DE EDUCACIÓN de la NACIÓN, la elaboración de un anteproyecto de decreto del PODER EJECUTIVO NACIONAL, conel objeto de establecer las pautas para el régimen de pasantías para el ámbito del nivel de Educación Secundaria del Sistema Educativo Nacional (Anexo I). Encomendar al MINISTERIO DE EDUCACIÓN de la NACIÓN, la elaboración de un anteproyecto de Decreto del PODER EJECUTIVO NACIONAL, con el objeto de modificar el artículo 3° del Decreto PEN Nş 491/97 y de la derogación del Decreto PEN Nş 340/92, conforme los términos y condiciones del documento acordado como Anexo I.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res09/90-09.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=93">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                84
                            </td>
                            <td>
                                2009                            </td>
                            <td>
                                Aprobar el documento "Lineamientos políticos y estratégicos de la educación secundaria obligatoria" (Anexo I).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res09/84-09.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=94">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                82
                            </td>
                            <td>
                                2009                            </td>
                            <td>
                                Aprobar el Programa Nacional “Una computadora para cada alumno” a ser implementado en escuelas técnicas públicas de gestión estatal dependientesde las provincias y de la Ciudad Autónoma de Buenos Aires (Anexo I).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res09/82-09.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=95">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                79
                            </td>
                            <td>
                                2009                            </td>
                            <td>
                                Aprobar el Plan Nacional de Educación Obligatoria (Anexos I y II).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res09/79-09.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=96">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                78
                            </td>
                            <td>
                                2009                            </td>
                            <td>
                                Aprobar el documento “Curso de capacitación para construcciones sismorresistentes en mampostería” (Anexo I).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res09/78-09.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=97">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                77
                            </td>
                            <td>
                                2009                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia correspondientes a las especialidades de Gestión de la Producción Agropecuaria de nivel superiory de Tecnología de los Alimentos de nivel secundario (Anexos I y II).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res09/77-09.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=98">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                65
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Promover la conformación de un sistema de seguimiento de egresados de la Educación Técnico Profesional, regido por el INSTITUTO NACIONAL DE EDUCACIÓN TECNOLÓGICA (INET) del MINISTERIO DE EDUCACIÓN DE LA NACIÓN.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/65-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=99">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                64
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Aprobar el “Programa Nacional de Formación Docente Inicial para la Educación Técnico Profesional” (Anexo I). Aprobar los perfiles profesionalesrequeridos para la implementación del Programa (Anexo II).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/64-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=100">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                63
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Aprobar el plan de estudios "Profesorado de educación secundaria de la modalidad técnico profesional en concurrencia con título de base" (Anexo). Disponer que las jurisdicciones que decidan aplicar este plan de estudios notifiquen al MINISTERIO DE EDUCACIÓN DE LA NACIÓN la nómina de instituciones en las que será implementado, a los efectos de obtener la validez nacional de los títulos y certificados a emitir.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/63-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=101">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                62
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Aprobar el documento “Mejora Continua de la Calidad de la Educación Técnico Profesional” y el coeficiente de distribución del Fondo Nacional para laEducación Técnico Profesional (anexos I y II).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/62-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=102">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                51
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Aprobar el Programa Nacional de refacción integral de edificios de establecimientos de Educación Técnico Profesional de gestión estatal (Anexo I);plazos jurisdiccionales; competencias del INET; facultades de la DIRECCIÓN DE INFRAESTRUCTURA de la SUBSECRETARÍA DE COORDINACIÓN ADMINISTRATIVA del MINISTERIO DE EDUCACIÓN DE LA NACIÓN y demás condiciones técnicas para los procedimientos de contratación del Programa.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/51-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=103">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                50
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Aprobar el Programa Nacional de Equipamiento Informático para las Instituciones de ETP que dicten carreras técnicas de nivel secundario(Anexos I y II);establecer plazos jurisdiccionales y competencias del INET en la implementación del Programa.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/50-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=104">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                49
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Establecer plazos jurisdiccionales para la presentación de planes de mejora correspondientes a instituciones de gestión privada, propuestos para ser financiados con los recursos previstos en el Fondo Nacional para la Educación Técnico Profesional, según documentación, requisitos, líneas de acción,operatoria y demás condiciones previstas en la presente resolución.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/49-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=105">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                48
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia para la homologación de certificados de formación profesional de: mecánico de sistemas de frenos,mecánico de sistemas de encendido y alimentación, mecánico de sistemas de inyección diesel, tornero y fresador (Anexos I, II, III, IV y V respectivamente)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/48-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=106">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                47
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Aprobar el documento “Lineamientos y criterios para la organización institucional y curricular de la educación técnico profesional correspondiente a laeducación secundaria y la educación superior” (Anexo)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/47-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=107">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                42
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Aprobar el “Programa nacional de producción y edición de materiales para la mejora de la enseńanza y el aprendizaje de la Biología, Física, Matemática,Química y aplicaciones emergentes, en el segundo ciclo de las escuelas de nivel secundario, ańos 2008/2009”.(Anexo I) Acordar la asignación de pesos veintidós millones ($ 22.000.000.-) del Fondo Nacional para la Educación Técnico Profesional, como recursos para atender los requerimientos del financiamiento de la producción y edición de libros en ciencias básicas.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/42-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=108">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                39
                            </td>
                            <td>
                                2008                            </td>
                            <td>
                                Extender hasta el 31 de diciembre de 2008 los alcances de las Resoluciones del Consejo Federal N°s 269/06 y 3/07 y de los convenios suscriptos entre el INET y las respectivas jurisdicciones, en el marco de la Resolución CFCyE Nş 250/05. Establecer, durante el 2008, un proceso de evaluación y seguimiento de la implementación de los planes de mejora y de la efectividad en la ejecución de los recursos previstos en el Fondo Nacional para laEducación Técnico Profesional, con vistas a su optimización.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res08/39-08.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=109">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                36
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia para la formación profesional de Auxiliar Mecánico de Motores Nafteros, Auxiliar Mecánico deMotores Diesel y Operador de Informática para Administración y Gestión. (Anexos I, II y III, respectivamente).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/36-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=110">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                35
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Encomendar al Ministerios de Educación la elaboración de un proyecto de reglamentación, para la acreditación de instituciones que dicten carreras denivel superior vinculadas al área de salud.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/35-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=111">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                34
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Aprobar los documentos base de las carreras: "Tecnicatura Superior en Medicina Nuclear", "Tecnicatura Superior en Hemoterapia", " TecnicaturaSuperior en Instrumentación Quirúrgica" y "Tecnicatura Superior de Esterilización". (Anexos I, II, III y IV).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/34-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=112">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                28
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Autorizar un tratamiento de excepción a lo dispuesto por la Resolución Nş 269/06, para incorporar al proceso de análisis y evaluación, el Plan de Mejorapresentado por el Instituto Agrotécnico, Presbítero Pedro Ignacio de Castro Barros, Provincia de La Rioja.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/28-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=113">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                27
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Autorizar un tratamiento de excepción a lo dispuesto por la Resolución Nş 269/06, para abordar los requerimientos de infraestructura y equipamiento delInstituto Superior de Educación Tecnológica Nş 812 - CeRET, Provincia de Chubut.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/27-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=114">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                26
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Autorizar un tratamiento de excepción a lo dispuesto por la Resolución Nş 269/06, para abordar los requerimientos de infraestructura y equipamiento delInstituto Tecnológico Miramar - Instituto Superior de Formación Técnica Nş194, Provincia de Buenos Aires.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/26-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=115">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                25
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia para la formación profesional de Apicultor, Asistente Apícola y Operario Apícola (Anexos I, II y III) .                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/25-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=116">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                15
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Aprobar los documentos de los marcos de referencia de los sectores Producción Agropecuaria, Construcciones Civiles, Electrónica, Electricidad,Electromecánica, Energías Renovables, Mecánica, Mecanización Agropecuaria, Automotores, Aeronáutica, Aviónica, Aerofotogrametría, Química, Industrias de Procesos, Minería, e Informática. (Anexos)                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/15-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=117">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                14
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Aprobar para la discusión el Documento “Lineamientos y criterios para la organización institucional y curricular de la Educación Técnico Profesional,correspondiente a la educación secundaria y la educación superior”. (Anexo)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/14-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=118">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                13
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Aprobar el Documento “ Títulos y Certificados de la Educación Técnico Profesional. (Anexo)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/13-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=119">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                8
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Autorizar un tratamiento de excepción a lo dispuesto por la Resolución CFCyE N° 269/06, para abordar los requerimientos de infraestructura yequipamientodel Instituto Agro Tecnológico de Tandil.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/08-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=120">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                7
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Aprobar el documento base de la carrera “ Tecnicatura Superior en Enfermería”. (Anexo)                            </td>
                            <td>
                                Superior                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/07-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=121">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                3
                            </td>
                            <td>
                                2007                            </td>
                            <td>
                                Acordar los plazos de inscripción para las universidades nacionales en los planes de mejora institucional, previstos por el Fondo Nacional para laEducación Técnico Profesional, así como condiciones, líneas de acción y montos adicionales.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res07/03-07.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=122">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                269
                            </td>
                            <td>
                                2006                            </td>
                            <td>
                                Se aprueba el coeficiente de distribución del Fondo Nacional para la Educación Técnico Profesional, que se agrega como Anexo II.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res06/269-06.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=123">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                267
                            </td>
                            <td>
                                2006                            </td>
                            <td>
                                Se acuerda la incorporación de los contenidos de la Declaración de los Principios yDerechos y Fundamentales en el Trabajo y el concepto de TrabajoDecente en la currícula de las instituciones de enseńanza media                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res06/267-06.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=124">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                261
                            </td>
                            <td>
                                2006                            </td>
                            <td>
                                Aprobación del documento "Proceso de Homologación y marcos de referencia de títulos y certificaciones de Educación Técnico profesional".                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res06/261-06.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=125">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                260
                            </td>
                            <td>
                                2006                            </td>
                            <td>
                                Adherir como usuarios al portal de la Biblioteca Electrónica a instituciones comprendidas en el alcance de la Ley de Educación Técnico Profesional parafacilitar el acceso a bibliografía especializada.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res06/260-06.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=126">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                250
                            </td>
                            <td>
                                2005                            </td>
                            <td>
                                Aprobar el documento "Mejora Continua de la Calidad de la Educación Técnico Profesional". Anexo. Sus lineamientos y procedimientos tendrán vigencia para las acciones a desarrollar 2006 y serán revisados para 2007. Asimismo, establece que, a partir del 2 de enero de 2006, las autoridades educativas jurisdiccionales podrán: i) inscribir a sus instituciones de ETP en el Registro Federal de Instituciones de ETP; ii) presentar los planes de mejora a serfinanciados por el Fondo Nacional para la ETP                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res05/250-05.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=127">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                238
                            </td>
                            <td>
                                2005                            </td>
                            <td>
                                Aprobar el documento Serie A-23 "Acuerdo Marco para la Educación Superior No Universitaria - Áreas Humanística, Social y Técnico-Profesional " Eldocumento aprobado podrá ser complementado posteriormente con otros documentos acordados federalmente. (Anexo I)                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res05/238-05.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=128">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                236
                            </td>
                            <td>
                                2005                            </td>
                            <td>
                                Aprobar los Módulos complementarios al Plan de Estudios del Maestro Mayor de Obras (Anexo I). Las Provincias y la Ciudad Autónoma de Buenos Aires adecuarán progresivamente la organización curricular e institucional a las pautas establecidas en los módulos aprobados en el artículo precedente. Los diseńos curriculares que realicen las jurisdicciones y que se ajusten a lo establecido en los Módulos aprobados en el artículo 1ş de la presente Resolución, serán considerados como "concertados" por el CONSEJO FEDERAL DE CULTURA Y EDUCACIÓN, según los términos del inciso c) del artículo 53, y a) del artículo 56 de la Ley Nş 24.195. Periódicamente se evaluará la implementación de los módulos complementarios al plan de formación y se propondrán modificaciones que serán incorporadas a los mismos para su actualización permanente. Las actualizaciones e innovaciones deberán ser acordadas por el CONSEJO FEDERAL DE CULTURA Y EDUCACIÓN a los efectos de la equivalencia y validez nacional de estudios y títulos.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res05/236-05.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=129">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                234
                            </td>
                            <td>
                                2005                            </td>
                            <td>
                                Aprobar los Documentos Base (Perfil Profesional, Bases Curriculares y Módulos) de los siguientes Perfiles de Formación Profesional: "Auxiliar en Mantenimiento de Motores Nafteros"; "Auxiliar en Mantenimiento de Motores Diesel"; "Colocador de Revestimientos Decorativos"; "Auxiliar en Gestión de Facturación en Salud" y "Operador de Informática de Oficina", los cuales integran la presente resolución. Las Provincias y la CIUDAD AUTÓNOMA DE BUENOS AIRES adecuarán sus ofertas formativas, en forma progresiva a las pautas establecidas en estos Documentos Base. Periódicamente se evaluará la implementación de estos Documentos y se propondrán modificaciones que serán incorporadas a los mismos para su actualización permanente. Las actualizaciones e innovaciones deberán ser acordados por el CONSEJO FEDERAL DE CULTURA Y EDUCACIÓN a los efectos de laequivalencia y validez nacional de estudios y títulos.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res05/234-05.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=130">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                230
                            </td>
                            <td>
                                2004                            </td>
                            <td>
                                Reconocer los circuitos de consulta coordinados por el Instituto Nacional de Educación Tecnológica para el análisis y discusión del Anteproyecto de Ley de Educación Técnico-Profesional, aprobado por Resolución CFCyE 215/04. Aprobar el "Proyecto de Ley de Educación-Técnico Profesional" (Anexo). Encomendar al MECyT realizar las gestiones necesarias para que el referido Proyecto de Ley tome estado parlamentario en el presente períodolegislativo.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res04/230-04.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=131">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                215
                            </td>
                            <td>
                                2004                            </td>
                            <td>
                                Incorporar como tema de agenda del Comité Ejecutivo y de las reuniones regionales de Ministros del Consejo Federal de Cultura y Educación eltratamiento de los avances acerca del documento base "Anteproyecto de Ley de Educación Técnico-Profesional". Acordar en avanzar en el análisis y en la elaboración de acuerdos en torno a un documento base de "Anteproyecto de Ley de Educación Técnico-Profesional" para que tome estado parlamentario en el presente período legislativo. Orientar el análisis y la discusión de dicho anteproyecto de ley de acuerdo con los criterios y propósitos enunciados en el Anexo I de la presente Resolución.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res04/215-04.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=132">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                208
                            </td>
                            <td>
                                2003                            </td>
                            <td>
                                Aprobar el Documento Base, Base Curricular y Módulos del Trayecto Técnico Profesional en Pesca y Acuicultura (Anexos I y II)                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res03/208-03.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=133">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                207
                            </td>
                            <td>
                                2003                            </td>
                            <td>
                                Aprobar el Documento Base, Base Curricular y Módulos del Trayecto Técnico Profesional en Minería (Anexos I y II).                            </td>
                            <td>
                                Secundaria Tecnica                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res03/207-03.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=134">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                206
                            </td>
                            <td>
                                2003                            </td>
                            <td>
                                Establecer para las carreras a distancia de formación de carácter post nivel polimodal/medio/secundario no universitario, excluyendo las carreras deformación docente, una carga horaria mínima de 1600 horas reloj.                            </td>
                            <td>
                                Superior                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://cfe.educacion.gob.ar/resoluciones/res03/206-03.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=135">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                428
                            </td>
                            <td>
                                2022                            </td>
                            <td>
                                Nueva trayectoria formativa de Educación Técnico Profesional que integra los lineamientos curriculares de la - EDJA                            </td>
                            <td>
                                Formacion Profesional                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="http://www.bnm.me.gov.ar/giga1/normas/RCFE_428-22.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=136">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                427
                            </td>
                            <td>
                                2022                            </td>
                            <td>
                                Sistema Nacional de Evaluación, Certificación y Acreditación Integral de la Educación Técnico Profesional                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion CFE</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="http://www.bnm.me.gov.ar/giga1/normas/RCFE_427-22.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=137">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                0
                            </td>
                            <td>
                                0                            </td>
                            <td>
                                Contenido                            </td>
                            <td>
                                Sector                            </td>
                            <td>TipoReso</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="link">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=142">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                26058
                            </td>
                            <td>
                                2005                            </td>
                            <td>
                                Objeto, alcances y ámbito de aplicación. Fines, objetivos y propósitos. Ordenamiento y regulación de la educación técnico profesional. Mejora continua de la calidad de la educación técnico profesional. Del gobierno y administración de la educación técnico profesional. Financiamiento. Normas transitorias y complementarias.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Ley</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/normativa/nacional/ley-26058-109525/texto">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=143">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                26206
                            </td>
                            <td>
                                2006                            </td>
                            <td>
                                Regula el ejercicio del derecho de enseñar y aprender consagrado por el artículo 14 de la Constitución Nacional y los tratados internacionales incorporados a ella.                            </td>
                            <td>
                                Educacion                            </td>
                            <td>Ley</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/normativa/nacional/ley-26206-123542/actualizacion">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=144">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                311
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Propicia condiciones para la inclusión escolar al interior del sistema educativo argentino para el acompañamiento de las trayectorias escolares de los/as estudiantes con discapacidad.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/res-311-cfe-58add7585fbc4.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=145">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                311
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                Anexo I Promoción, acreditación, certificación y titulación de estudiantes con discapacidad.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/anexo-i-res-311-cfe-58add7b4b3340.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=146">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                311
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                311 - Anexo II

2016

Ejes prioritarios para la confección del Proyecto Pedagógico para la Inclusión (PPI).                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/anexo-ii-res-311-cfe-58add83aa4885.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=147">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                311
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                311 - Anexo III

2016

Observaciones acerca de las Configuraciones de Apoyo a consignar en el punto 15 del Anexo II.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/anexo-iii-res-311-cfe-58add8afca529.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=148">Ver</a>
                            </td>
                        </tr>
                                            <tr>
                            <td>
                                311
                            </td>
                            <td>
                                2016                            </td>
                            <td>
                                311 - Anexo IV

2016

Informe de desarrollo de capacidades, saberes específicos y competencias adquiridas.                            </td>
                            <td>
                                ETP                            </td>
                            <td>Resolucion</td>
                            <!-- <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="https://www.argentina.gob.ar/sites/default/files/anexo-iv-res-311-cfe-58add8f857c9b_0.pdf">Descargar</a>
                            </td> -->
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="NormaLegal.php?id=149">Ver</a>
                            </td>
                        </tr>
                                    </tbody>

            </table>        </div>
    </div>
</div>






<!-- Google -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="js/scripts.js"></script>
<script type="text/javascript" src="\js\mysql.js"></script>

        
        
                        </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; ST3 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<!--         <script src="assets/demo/chart-area-demo.js"></script> Ejemplo-->
<!--        <script src="assets/demo/chart-bar-demo.js"></script> Ejemplo--> 
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<!--         <script src="js/datatables-simple-demo.js"></script> Ejemplo--> -->
    </body>
</html>