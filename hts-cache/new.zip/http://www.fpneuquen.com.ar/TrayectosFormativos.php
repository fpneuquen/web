

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-D23TBS0BCN"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-D23TBS0BCN');
    </script>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Web de consulta de Centros de Formacion Profesional" />
    <meta name="author" content="Silvio Stenta" />
    <title>Formacion Profesional WEB</title>
    <link rel="icon" type="image/png" href="img/logofp.png">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
 <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 --></head>

<body class="sb-nav-fixed">
    <nav class="navbar navbar-expand-lg navbar-dark ">
        <!-- Navbar Brand-->
        <button class="btn btn-link btn-sm order-1 order-lg-1 me-4 me-lg-1" id="sidebarToggle" href="index.php">
            <i class="fas fa-bars fa-lg "></i></button>
        <a class="navbar-brand ps-3" href="index.php"><img src="img/logo fp 288x271.png" class="img-fluid" alt="max-width: 30%;height: auto" width="20%"></a>
        <!-- Sidebar Toggle-->

        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <!-- <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button> -->
            </div>
        </form>
        <!-- Navbar User-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="login.php">Login</a></li>
                    <li><a class="dropdown-item" href="./administrador/inicio.php">Settings</a></li>
                    <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="cerrar.php">Cerrar</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <!-- Navbar Lateral -->

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-primary" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading"></div>
                        <a class="nav-link" href="dashboard.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Todas las Escuelas
                        </a>
                        <div class="collapse" id="collapsePages" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                            </nav>
                        </div>
                        <!-- <div class="sb-sidenav-menu-heading">Addons</div> -->
                        <!--                         <a class="nav-link" href="charts.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Graficos
                        </a> -->


                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseCFP" aria-expanded="false" aria-controls="collapseCFP">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Centros
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseCFP" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="table.php"><i class="fa fa-book" aria-hidden="true"></i>Listado por Zona</a>
                                <a class="nav-link" href="centrosxzonas.php"><i class="fas fa-map-pin" aria-hidden="true"></i>Ubicacion por Zona</a>
                            </nav>
                        </div>


                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseTray" aria-expanded="false" aria-controls="collapseTray">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Trayectos Formativos
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseTray" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="Sectores.php">
                                    <div class="sb-nav-link-icon"> <i class="fa-brands fa-bandcamp"></i></div>
                                    Sectores Productivos
                                </a>
                                <a class="nav-link" href="SubSectores.php">
                                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                    Sub-Sectores
                                </a>
                                <a class="nav-link" href="TrayectosFormativos.php">
                                    <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                    Trayectos Formativos
                                </a>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>

                    invitado                </div>
            </nav>
        </div>
        <!-- Principal -->



        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src="js/scripts.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.css" />
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/fc-4.0.2/r-2.2.9/rr-1.2.8/sc-2.0.5/sl-1.3.4/datatables.min.css" />

        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/fc-4.0.2/r-2.2.9/rr-1.2.8/sc-2.0.5/sl-1.3.4/datatables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.12.1/b-2.2.3/b-colvis-2.2.3/b-html5-2.2.3/b-print-2.2.3/datatables.min.js"></script>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

        <div id="layoutSidenav_content">
            <main>



<div class="container-fluid px-2">
    <h1 class="">Trayectos Formativos</h1>
    <ol class="breadcrumb mb-1">
        <li class="breadcrumb-item"><a href="index.php">Escritorio</a></li>
        <li class="breadcrumb-item active">Tablas</li>
    </ol>



    <form method="POST" enctype="multipart/form-data">
        <div class="btn-group btn-group-sm" role="group" aria-label="Basic outlined example">
            <br>Filtrar por : </br>

            <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle btn-sm" data-bs-toggle="dropdown" aria-expanded="false"> Sector
            </button>
            <ul class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                <li>
                    <input name="SectorElegido" class="btn btn-primary btn-sm" type="submit" value="Todos">
                </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Actividades Artísticas Técnicas">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Administración">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Aeronáutica">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Agropecuario">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Automotriz">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Construcción">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Cuero y Calzado">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Cultura y Comunicación">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Desarrollo Humano">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Electromecánica">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Electrónica">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Energía">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Energía Eléctrica">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Estética Profesional">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Hotelería y Gastronomía">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Industria de la Alimentación">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Industria de Procesos">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Industria Gráfica y Multimedial">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Informática">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Madera y Mueble">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Mecánica, Metalmecánica y Metalurgia">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Minería e Hidrocarburos">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Naval">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Salud">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Seguridad, Ambiente e Higiene">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Textil e Indumentaria">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Turismo">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Todos los sectores productivos">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Sin Sector">
                        </a>
                    </li>
                                    <li><a class="dropdown-item">
                            <input name="SectorElegido" class="btn btn-secondary btn-sm" type="submit" value="Telecomunicaciones">
                        </a>
                    </li>
                            </ul>

        </div>
    </form>





        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Listado de Trayectos             </div>
            <div class="card-body">
                <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>SubSector</th>
                        <th>Denominacion</th>
                        <th>Norma Legal</th>
                        <th>Tipo Cert</th>
                        <th>Nivel</th>
                        <th>Duracion</th>
                        <th>Centros</th>
                        <th>Trayectos</th>
                        <th>Descargar</th>
                    </tr>
                </thead>


                <tbody>
                                            <tr>
                            <td>
                                Panadería y Repostería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Auxiliar Pastelero                            </td>
                            <td>
                                Disp. 244/2019 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>150</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=1">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=1">Ver</a>
                            </td>
                            <td>
                                <a href="docs/244-19_04 Auxiliar pastelero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cocina (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Cocinero Especializado en Cocina Internacional                            </td>
                            <td>
                                Disp. 244/2019 Anexo 8                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                                            </td>
                            <td>96</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=3">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=3">Ver</a>
                            </td>
                            <td>
                                <a href="docs/244-19_08 COCINERO ESPECIALIZADO A EN COCINA INTERNACIONAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cocina (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Cocinero Especializado en Cocina Regional Patagonica                            </td>
                            <td>
                                Disp. 244/2019 Anexo 9                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                                            </td>
                            <td>48</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=4">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=4">Ver</a>
                            </td>
                            <td>
                                <a href="docs/244-19_09 COCINERO ESPECIALIZADO EN COCINA REGIONAL PATAGONICA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cocina (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Cocinero Especializado en Cocina Saludable                            </td>
                            <td>
                                Disp. 244/2019 Anexo 10                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                                            </td>
                            <td>96</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=5">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=5">Ver</a>
                            </td>
                            <td>
                                <a href="docs/244-19_10 COCINERO ESPECIALIZADO EN COCINA SALUDABLE.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cocina (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Cocinero Especializado en Cocina Vegetariana                            </td>
                            <td>
                                Disp. 244/2019 Anexo 11                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                                            </td>
                            <td>48</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=8">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=8">Ver</a>
                            </td>
                            <td>
                                <a href="docs/244-19_11 COCINERO ESPECIALIZADO EN COCINA VEGETARIANA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño, Decoración y Ambientación (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Ambientador de Salones para Eventos                            </td>
                            <td>
                                Disp. 244/2019 Anexo 17                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>100</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=10">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=10">Ver</a>
                            </td>
                            <td>
                                <a href="docs/244-19_17 Ambientador-a de salones para eventos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cocina (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Auxiliar en Cocina                            </td>
                            <td>
                                Disp. 244/2019 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>150</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=15">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=15">Ver</a>
                            </td>
                            <td>
                                <a href="docs/244-19_02 Auxiliar en cocina.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Vialidad (Construcción)
                            </td>
                            <td>
                                Operador De Máquinas Viales                            </td>
                            <td>
                                Disp. 240/2019 Anexo 5                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=16">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=16">Ver</a>
                            </td>
                            <td>
                                <a href="docs/240-19_05 Operador de Maquinas viales.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Minería (Minería e Hidrocarburos)
                            </td>
                            <td>
                                Auxiliar en Actividades Mineras                            </td>
                            <td>
                                Disp. 240/2019 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=17">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=17">Ver</a>
                            </td>
                            <td>
                                <a href="docs/240-19_02 Auxiliar en Actividades Mineras.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Orfebrería y Bijouterie (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Orfebre                            </td>
                            <td>
                                Disp. 240/2019 Anexo 6                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=18">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=18">Ver</a>
                            </td>
                            <td>
                                <a href="docs/240-19_06 Orfebre.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Minería (Minería e Hidrocarburos)
                            </td>
                            <td>
                                Cortador y Pulidor de Rocas y Minerales                            </td>
                            <td>
                                Disp. 240/2019 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=19">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=19">Ver</a>
                            </td>
                            <td>
                                <a href="docs/240-19_03 Cortador y Pulidor de Rocas y Minerales.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Artístico y Artesanal (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Elaborador De Lámparas De Sal                            </td>
                            <td>
                                Disp. 240/2019 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=20">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=20">Ver</a>
                            </td>
                            <td>
                                <a href="docs/240-19_04 Elaborador de lámparas de sal.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración y Conservación de Alimentos (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador De Conservas Y Chacinados                            </td>
                            <td>
                                Disp. 245/2019 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>120</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=21">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=21">Ver</a>
                            </td>
                            <td>
                                <a href="docs/245-19_02 Elaborador de conservas y chacinados.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración de Productos Alimenticios (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador de Pastas                            </td>
                            <td>
                                Disp. 245/2019 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=23">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=23">Ver</a>
                            </td>
                            <td>
                                <a href="docs/245-19_03 Elaborador-a de pastas.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones Sanitarias y de Gas (Construcción)
                            </td>
                            <td>
                                Instalador de Sistemas Solares Térmicos para Agua Caliente y Sanitarias (Reemplazado por 241-19)                            </td>
                            <td>
                                Disp. 103/2018 Anexo 6                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=26">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=26">Ver</a>
                            </td>
                            <td>
                                <a href="docs/https://drive.google.com/file/d/1JZkle2ruqlO9_0NsE7_sDU1RbP4mb1Lx/view?usp=sharing" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cerámica (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Operador/a en Torno Alfarero                            </td>
                            <td>
                                Disp. 98/2018 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>257</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=28">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=28">Ver</a>
                            </td>
                            <td>
                                <a href="docs/098-18_04 OPERADORA EN TORNO ALFARERO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Orfebrería y Bijouterie (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Joyero Básico                            </td>
                            <td>
                                Disp. 98/2018 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>220</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=29">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=29">Ver</a>
                            </td>
                            <td>
                                <a href="docs/098-18_02 JOYERO BÁSICO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Artístico y Artesanal (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Operador Artístico Del Vidrio (Vitrofusión - mosaiquismo)                            </td>
                            <td>
                                Disp. 98/2018 Anexo 5                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=30">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=30">Ver</a>
                            </td>
                            <td>
                                <a href="docs/098-18_05 OPERADOR ARTÍSTICO DEL VIDRIO (VITROFUSIÓNMOSAIQUISMO)..pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cerámica (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Auxiliar en Taller Cerámico                            </td>
                            <td>
                                Disp. 98/2018 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>220</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=31">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=31">Ver</a>
                            </td>
                            <td>
                                <a href="docs/098-18_03 AUXILIAR EN TALLER CERÁMICO..pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Redes Informáticas (Informática)
                            </td>
                            <td>
                                Instalación Y Configuración De Servidores                            </td>
                            <td>
                                Disp. 102/2018 Anexo 7                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>96</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=35">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=35">Ver</a>
                            </td>
                            <td>
                                <a href="docs/102-18_07 Instalación y Configuración de Servidores.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Vegetal (Agropecuario)
                            </td>
                            <td>
                                Horticultor Orgánico                            </td>
                            <td>
                                Disp. 104/2018 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=36">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=36">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_03 Horticultor Orgánico.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Vivero y Espacios Verdes (Agropecuario)
                            </td>
                            <td>
                                Oficial Jardinero Y Viverista                            </td>
                            <td>
                                Disp. 104/2018 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=37">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=37">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_02 Oficial Jardinero y Viverista.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cuero (Cuero y Calzado)
                            </td>
                            <td>
                                Confeccionista de Calzado a Medida                            </td>
                            <td>
                                Disp. 95/2018 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>245</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=38">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=38">Ver</a>
                            </td>
                            <td>
                                <a href="docs/095-18_04 Confeccionista de Calzado a Medida.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cuero (Cuero y Calzado)
                            </td>
                            <td>
                                Confeccionista Marroquinero                            </td>
                            <td>
                                Disp. 95/2018 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>246</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=39">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=39">Ver</a>
                            </td>
                            <td>
                                <a href="docs/095-18_02 Confeccionista Marroquinero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cuero (Cuero y Calzado)
                            </td>
                            <td>
                                Artesano Confeccionista En Cuero                            </td>
                            <td>
                                Disp. 95/2018 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>200</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=40">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=40">Ver</a>
                            </td>
                            <td>
                                <a href="docs/095-18_03 Artesano Confeccionista en Cuero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Tejido (Textil e Indumentaria)
                            </td>
                            <td>
                                Tejedor/a A Mano                            </td>
                            <td>
                                Disp. 96/2018 Anexo 5                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>300</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=42">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=42">Ver</a>
                            </td>
                            <td>
                                <a href="docs/096-18_05 CONFECCIONISTA A MEDIDA TEJEDORA A MANO..pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Auxiliar en Diseño de Estampación Textil                            </td>
                            <td>
                                Disp. 96/2018 Anexo 9                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>320</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=43">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=43">Ver</a>
                            </td>
                            <td>
                                <a href="docs/096-18_09 AUXILIAR EN DISEÑO DE ESTAMPACIÓN TEXTIL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Tejido (Textil e Indumentaria)
                            </td>
                            <td>
                                Tejedor/a a Máquina                            </td>
                            <td>
                                Disp. 96/2018 Anexo 8                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>540</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=44">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=44">Ver</a>
                            </td>
                            <td>
                                <a href="docs/096-18_08 CONFECCIONISTA A MEDIDA TEJEDORA A MÁQUINA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista Industrial                            </td>
                            <td>
                                Disp. 96/2018 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>380</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=45">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=45">Ver</a>
                            </td>
                            <td>
                                <a href="docs/096-18_04 CONFECCIONISTA INDUSTRIAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Tejido (Textil e Indumentaria)
                            </td>
                            <td>
                                Tejedor/a Telar Mapuche                            </td>
                            <td>
                                Disp. 96/2018 Anexo 6                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>340</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=47">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=47">Ver</a>
                            </td>
                            <td>
                                <a href="docs/096-18_06 CONFECCIONISTA A MEDIDA TEJEDORA TELAR MAPUCHE.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Redes Informáticas (Informática)
                            </td>
                            <td>
                                Seguridad Informática                            </td>
                            <td>
                                Disp. 102/2018 Anexo 8                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>48</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=49">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=49">Ver</a>
                            </td>
                            <td>
                                <a href="docs/102-18_08 Seguridad Informatica.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Redes Informáticas (Informática)
                            </td>
                            <td>
                                Instalador y Soporte de Sistemas Informáticos                            </td>
                            <td>
                                Disp. 102/2018 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>312</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=50">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=50">Ver</a>
                            </td>
                            <td>
                                <a href="docs/102-18_04 Instalador y Soporte de Sistemas Informáticos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Redes Informáticas (Informática)
                            </td>
                            <td>
                                Instalación Y Configuración De Redes Informáticas                            </td>
                            <td>
                                Disp. 102/2018 Anexo 6                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>96</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=51">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=51">Ver</a>
                            </td>
                            <td>
                                <a href="docs/102-18_06 Instalacion y Configuracion de Redes Informaticas.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Usuarios (Informática)
                            </td>
                            <td>
                                Laboratorio De Informática Para Agentes De Seguridad                            </td>
                            <td>
                                Disp. 102/2018 Anexo 10                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>100</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=52">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=52">Ver</a>
                            </td>
                            <td>
                                <a href="docs/102-18_10 Laboratorio de Informatica para Agentes de Seguridad.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Carpintería (Madera y Mueble)
                            </td>
                            <td>
                                Carpintero Mueblista Especializado (Madera Maciza)                            </td>
                            <td>
                                Disp. 506/2019 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>510</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=56">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=56">Ver</a>
                            </td>
                            <td>
                                <a href="docs/506-19_04 Carpintero Mueblista Especializado.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones en Seco Livianas (Construcción)
                            </td>
                            <td>
                                Armador y Montador de Perfileria galvanizada pesada, construccion en seco exteriores.                            </td>
                            <td>
                                Disp. 507/2019 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=57">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=57">Ver</a>
                            </td>
                            <td>
                                <a href="docs/507-19_02 ARMADOR Y MONTADOR DE PERFILERIA GALVANIZADA PESADA CONSTRUCCION EN SECO EXTERIORES.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cosmetología (Estética Profesional)
                            </td>
                            <td>
                                Manicuria y Belleza de pies                            </td>
                            <td>
                                Disp. 94/2018 Anexo 9                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=61">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=61">Ver</a>
                            </td>
                            <td>
                                <a href="docs/094-18_09 Manicuria y Belleza de Pies.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Aplicada al Equipamiento Frío - Calor (Electromecánica)
                            </td>
                            <td>
                                Reparador/a en Refrigeración y Aire Acondicionado                            </td>
                            <td>
                                Disp. 242/2019 Anexo 5                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=62">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=62">Ver</a>
                            </td>
                            <td>
                                <a href="docs/242_19_05 Reparador-a en refrigeracion y aire acondicionado.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Peluquería (Estética Profesional)
                            </td>
                            <td>
                                Peluquero especializado en peinados unisex                            </td>
                            <td>
                                Disp. 94/2018 Anexo 3                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>80</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=71">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=71">Ver</a>
                            </td>
                            <td>
                                <a href="docs/094-18_03 PELUQUEROA ESPECIALIZADOA EN PEINADOS UNISEX.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Peluquería (Estética Profesional)
                            </td>
                            <td>
                                Peluquero/a                            </td>
                            <td>
                                Disp. 94/2018 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>300</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=72">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=72">Ver</a>
                            </td>
                            <td>
                                <a href="docs/094-18_02 Peluquero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Renovables (Energía)
                            </td>
                            <td>
                                Instalador De Sistemas Solares Fotovoltaicos                            </td>
                            <td>
                                Disp. 241/2019 Anexo 1                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>130</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=73">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=73">Ver</a>
                            </td>
                            <td>
                                <a href="docs/241-19_01 Instalador de sistemas solares fotovoltaicos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Renovables (Energía)
                            </td>
                            <td>
                                Instalador De Sistemas Solares Térmicos para Agua Caliente                            </td>
                            <td>
                                Disp. 241/2019 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>130</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=74">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=74">Ver</a>
                            </td>
                            <td>
                                <a href="docs/241-19_02 Instalador de sistemas solares térmicos para agua caliente sanitaria.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Peluquería (Estética Profesional)
                            </td>
                            <td>
                                Peluquero Especializado En Coloración De Cabello                            </td>
                            <td>
                                Disp. 94/2018 Anexo 5                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>60</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=75">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=75">Ver</a>
                            </td>
                            <td>
                                <a href="docs/094-18_05 PELUQUEROA ESPECIALIZADOA EN COLORACIÓN DE CABELLO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cosmetología (Estética Profesional)
                            </td>
                            <td>
                                Depiladora Integral                            </td>
                            <td>
                                Disp. 94/2018 Anexo 8                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>220</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=76">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=76">Ver</a>
                            </td>
                            <td>
                                <a href="docs/094-18_08 DEPILADORA INTEGRAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Peluquería (Estética Profesional)
                            </td>
                            <td>
                                Peluquero Especializado En Cortes Unisex                            </td>
                            <td>
                                Disp. 94/2018 Anexo 4                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>60</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=78">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=78">Ver</a>
                            </td>
                            <td>
                                <a href="docs/094-18_04 PELUQUEROA ESPECIALIZADOA EN CORTES UNISEX.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cosmetología (Estética Profesional)
                            </td>
                            <td>
                                Cosmetóloga                            </td>
                            <td>
                                Disp. 94/2018 Anexo 6                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>300</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=79">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=79">Ver</a>
                            </td>
                            <td>
                                <a href="docs/094-18_06 COSMETÓLOGA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Audio, Video, Radio y Tv (Electrónica)
                            </td>
                            <td>
                                Operador en Electronica Basica                            </td>
                            <td>
                                Disp. 242/2019 Anexo 1                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=80">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=80">Ver</a>
                            </td>
                            <td>
                                <a href="docs/242-19_02 Operador-a en Electronica Basica.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Audio, Video, Radio y Tv (Electrónica)
                            </td>
                            <td>
                                Reparador Lavarropas Automáticos y Electrónicos                            </td>
                            <td>
                                Disp. 242/2019 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>222</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=81">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=81">Ver</a>
                            </td>
                            <td>
                                <a href="docs/242-19_02 Reparador lavarropas automaticos y electronicos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Audio, Video, Radio y Tv (Electrónica)
                            </td>
                            <td>
                                Reparador de Electrodomesticos y pequeñas Herramientas                            </td>
                            <td>
                                Disp. 242/2019 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=82">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=82">Ver</a>
                            </td>
                            <td>
                                <a href="docs/242-19_04 Reparador de electrodomesticos y pequeñas herramientas.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Audio, Video, Radio y Tv (Electrónica)
                            </td>
                            <td>
                                Reparador de Artefactos Electrónicos                            </td>
                            <td>
                                Disp. 242/2019 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>220</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=83">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=83">Ver</a>
                            </td>
                            <td>
                                <a href="docs/242-19_03 Reparador de artefactos electrónicos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Panadería y Repostería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Auxiliar Panadero                            </td>
                            <td>
                                Disp. 244/2019 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>150</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=84">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=84">Ver</a>
                            </td>
                            <td>
                                <a href="docs/244-19_03 Auxiliar panadero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Actividades Recreativas (Turismo)
                            </td>
                            <td>
                                Guia de Trekking                            </td>
                            <td>
                                Res. 2074/14                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>704</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=85">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=85">Ver</a>
                            </td>
                            <td>
                                <a href="docs/r_2074_14 Guia de Trekking.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista de lencería y corsetería                            </td>
                            <td>
                                Disp. 487/2019 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>300</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=87">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=87">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_02 Confeccion de  Lenceria y  Corseteria.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista a medida de ropa de trabajo                            </td>
                            <td>
                                Disp. 487/2019 Anexo 3                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>150</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=88">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=88">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_03 Confeccionista a medida de ropa de trabajo final.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista a medida de ropa deportiva                            </td>
                            <td>
                                Disp. 487/2019 Anexo 4                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>150</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=89">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=89">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_04 Confeccionista a medida de ropa deportiva final.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista a medida de ropa adaptada                            </td>
                            <td>
                                Disp. 487/2019 Anexo 5                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>190</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=90">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=90">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_05 Confeccionista de ropa adaptada.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista a medida de ropa de abrigo                            </td>
                            <td>
                                Disp. 487/2019 Anexo 6                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>120</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=91">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=91">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_06 Confeccionista de Ropa de Abrigo.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista de alta costura                            </td>
                            <td>
                                Disp. 487/2019 Anexo 7                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>210</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=92">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=92">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_07 Confeccionista de Alta  Costura.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista en sastrería                            </td>
                            <td>
                                Disp. 487/2019 Anexo 8                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=93">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=93">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_08 Confeccionista en Sastreria.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista de Accesorios, Blanco y mantelería                            </td>
                            <td>
                                Disp. 487/2019 Anexo 9                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>120</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=94">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=94">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_09  Accesorios, Blanco y manteleria.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Encimador/a, tizador/a y cortador/a industrial                            </td>
                            <td>
                                Disp. 487/2019 Anexo 10                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>80</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=95">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=95">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_10 Encimador, tizador y cortador industrial.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Marroquinero/a Textil                            </td>
                            <td>
                                Disp. 487/2019 Anexo 11                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>246</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=96">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=96">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_11 Marroquinero textil.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Tejido (Textil e Indumentaria)
                            </td>
                            <td>
                                Tejedor/a en Bastidores y Telares                            </td>
                            <td>
                                Disp. 487/2019 Anexo 12                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=97">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=97">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_12 Tejedor en bastidores y telares final.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Tejido (Textil e Indumentaria)
                            </td>
                            <td>
                                Tejedor/a en Telar Toba                            </td>
                            <td>
                                Disp. 487/2019 Anexo 13                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>120</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=98">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=98">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_13 Tejedor en telar toba.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Tejido (Textil e Indumentaria)
                            </td>
                            <td>
                                Tejedor/a en Moldetelar                            </td>
                            <td>
                                Disp. 487/2019 Anexo 14                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>120</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=99">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=99">Ver</a>
                            </td>
                            <td>
                                <a href="docs/487-19_14 Tejedor en moldetelar.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Redes Informáticas (Informática)
                            </td>
                            <td>
                                Automatización, Programación De Sistemas Embebidos (IoT internet de las cosas)                            </td>
                            <td>
                                Disp. 102/2018 Anexo 5                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>96</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=105">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=105">Ver</a>
                            </td>
                            <td>
                                <a href="docs/102-18_05 Automatización, Programación de Sistemas Embebidos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Análisis y Programación de Sistemas (Informática)
                            </td>
                            <td>
                                Diseñador Web                            </td>
                            <td>
                                Disp. 102/2018 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>144</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=106">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=106">Ver</a>
                            </td>
                            <td>
                                <a href="docs/102-18_02 Diseñador Web.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Redes Informáticas (Informática)
                            </td>
                            <td>
                                Auxiliar en Reparación y Mantenimiento De Pc                            </td>
                            <td>
                                Disp. 102/2018 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>260</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=107">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=107">Ver</a>
                            </td>
                            <td>
                                <a href="docs/102-18_03 Auxiliar en Reparación y Mantenimiento de PC.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Carpintería (Madera y Mueble)
                            </td>
                            <td>
                                Carpintero de Banco y Operador De Máquinas Simples                            </td>
                            <td>
                                Disp. 101/2018 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>510</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=110">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=110">Ver</a>
                            </td>
                            <td>
                                <a href="docs/101-18_02 Carpintero de Banco y Operador de Máquinas Simples.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Atención al Cliente (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Bartender                            </td>
                            <td>
                                Disp. 99/2018 Anexo 9                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=113">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=113">Ver</a>
                            </td>
                            <td>
                                <a href="docs/099-18_09 BARTENDER.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Atención al Cliente (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Asesor de Vinos y Bebidas                            </td>
                            <td>
                                Disp. 99/2018 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=114">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=114">Ver</a>
                            </td>
                            <td>
                                <a href="docs/099-18_02 ASESOR DE VINOS Y BEBIDAS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Panadería y Repostería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Decorador De Tortas                            </td>
                            <td>
                                Disp. 99/2018 Anexo 7                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>200</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=118">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=118">Ver</a>
                            </td>
                            <td>
                                <a href="docs/099-18_07 DECORADOR DE TORTAS..pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Especialidades (Salud)
                            </td>
                            <td>
                                Auxiliar Materno Infantil                            </td>
                            <td>
                                Disp. 97/2018 Anexo 0                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>1080</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=127">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=127">Ver</a>
                            </td>
                            <td>
                                <a href="docs/097-18_00 Auxiliar Materno Infantil.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Administración y Gestión (Administración)
                            </td>
                            <td>
                                Operador en Sistemas de Gestion contable                            </td>
                            <td>
                                Disp. 105/2018 Anexo 7                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>150</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=128">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=128">Ver</a>
                            </td>
                            <td>
                                <a href="docs/105-18_07 Operador de Sistema.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Administración y Gestión (Administración)
                            </td>
                            <td>
                                Secretariado Administrativo Contable                            </td>
                            <td>
                                Disp. 105/2018 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=129">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=129">Ver</a>
                            </td>
                            <td>
                                <a href="docs/105-18_03 Secretariado Administrativo Contale.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Administración y Gestión (Administración)
                            </td>
                            <td>
                                Secretariado Juridico                            </td>
                            <td>
                                Disp. 105/2018 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>312</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=130">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=130">Ver</a>
                            </td>
                            <td>
                                <a href="docs/105-18_04 Secretariado Juridico.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Contabilidad (Administración)
                            </td>
                            <td>
                                Liquidador de Sueldo Multiconvenio                            </td>
                            <td>
                                Disp. 105/2018 Anexo 6                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>115</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=132">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=132">Ver</a>
                            </td>
                            <td>
                                <a href="docs/105-18_06 Liquidador de Sueldo.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Contabilidad (Administración)
                            </td>
                            <td>
                                Liquidador de Impuestos                            </td>
                            <td>
                                Disp. 105/2018 Anexo 5                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>115</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=133">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=133">Ver</a>
                            </td>
                            <td>
                                <a href="docs/105-18_05 Liquidador de Impuestos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Administración y Gestión (Administración)
                            </td>
                            <td>
                                Auxiliar Administrativo Contable                            </td>
                            <td>
                                Disp. 105/2018 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>192</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=134">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=134">Ver</a>
                            </td>
                            <td>
                                <a href="docs/105-18_02 Auxiliar Administrativo Contable.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánica (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Herrero                            </td>
                            <td>
                                Res. CFE Nro. 108/10 Anexo 14                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>280</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=135">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=135">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_14 Herrero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánica (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Soldador                            </td>
                            <td>
                                Res. CFE N° 108/10 Anexo 17                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>300</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=136">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=136">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_17 Soldador.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánica (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Soldador Básico                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 16                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>150</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=137">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=137">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_16 Soldador Basico.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones en Seco Livianas (Construcción)
                            </td>
                            <td>
                                Armador y Montador de Paneles y Cielorrasos de Placas de Roca de Yeso                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=138">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=138">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_05 Armador y montador de paneles y cielorrasos de placas de roca de yeso.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones en Seco Livianas (Construcción)
                            </td>
                            <td>
                                Auxiliar en Construcciones en Seco con Componentes Livianos                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo VI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>70</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=139">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=139">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_06 Auxiliar en construcciones en seco con componentes livianos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones en Seco Livianas (Construcción)
                            </td>
                            <td>
                                Armador y Montador de Componentes Metálicos Livianos                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=140">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=140">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_04 Armador y montador de componentes metalicos livianos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones Sanitarias y de Gas (Construcción)
                            </td>
                            <td>
                                Montador de Instalaciones Sanitarias Domiciliarias                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 10                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=141">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=141">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_10 Montador de Instalaciones Sanitarias Domiciliarias.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Análisis y Programación de Sistemas (Informática)
                            </td>
                            <td>
                                Programador                            </td>
                            <td>
                                Res. CFE Nº 289/16 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>364</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=142">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=142">Ver</a>
                            </td>
                            <td>
                                <a href="docs/289-16_01 Programador.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Administración y Gestión de las Organizaciones (Informática)
                            </td>
                            <td>
                                Operador de Informática para Administración y Gestión                            </td>
                            <td>
                                Res. CFE N°036/07 Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=143">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=143">Ver</a>
                            </td>
                            <td>
                                <a href="docs/036-07_03 Operador de Informatica para Administracion y Gestion.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Animal (Agropecuario)
                            </td>
                            <td>
                                Apicultor                            </td>
                            <td>
                                Res. CFE N°25/07 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>400</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=144">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=144">Ver</a>
                            </td>
                            <td>
                                <a href="docs/025-07_01 Apicultor.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Animal (Agropecuario)
                            </td>
                            <td>
                                Asistente Apícola                            </td>
                            <td>
                                Res. CFE N°25/07 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>210</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=145">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=145">Ver</a>
                            </td>
                            <td>
                                <a href="docs/025-07_02 Asistente Apícola.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Animal (Agropecuario)
                            </td>
                            <td>
                                Operario Apícola                            </td>
                            <td>
                                Res. CFE N°25/07 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>115</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=146">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=146">Ver</a>
                            </td>
                            <td>
                                <a href="docs/025-07_03 Operario Apícola.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánica (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Tornero                            </td>
                            <td>
                                Res. CFE N°48/08 ANEXO IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>300</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=147">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=147">Ver</a>
                            </td>
                            <td>
                                <a href="docs/048-08_04 Tornero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánica (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Fresador                            </td>
                            <td>
                                Res. CFE N° 48/08 ANEXO V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>320</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=148">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=148">Ver</a>
                            </td>
                            <td>
                                <a href="docs/048-08_05 Fresador.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcción de Obra Civil (Construcción)
                            </td>
                            <td>
                                Albañil                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 1                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=149">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=149">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_01 Albañil.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcción de Obra Civil (Construcción)
                            </td>
                            <td>
                                Armador de Hierros para Hormigón Armado                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 2                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>110</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=150">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=150">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_02 Armador de Hierros para Hormigón Armado.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcción de Obra Civil (Construcción)
                            </td>
                            <td>
                                Auxiliar en Construcciones                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>70</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=151">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=151">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_03 Auxiliar en Construcciones.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Terminaciones Decorativas y Funcionales (Construcción)
                            </td>
                            <td>
                                Carpintero de Obra Fina                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 6                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=153">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=153">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_06 Carpintero de Obra Fina.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones de Base Húmeda (Construcción)
                            </td>
                            <td>
                                Carpintero para Hormigón Armado                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 7                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>110</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=154">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=154">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_07 Carpintero para Hormigón Armado.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones de Base Húmeda (Construcción)
                            </td>
                            <td>
                                Colocador de Revestimientos con Base Húmeda                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 8                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>220</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=155">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=155">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_08 Colocador de Revestimientos de Base Húmeda.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcción de Obra Civil (Construcción)
                            </td>
                            <td>
                                Techista de Faldones Inclinados                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 11                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=157">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=157">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_11 Techista de Faldones Inclinados.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Mecánico Instalador de Equipos de GNC                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 13                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>440</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=158">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=158">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_13 Mecanico Instalador de Equipos de GNC.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánico por Conformado (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Rectificador                            </td>
                            <td>
                                Res. CFE N°108/10 Anexo 15                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>280</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=159">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=159">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_15 Rectificador.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánico por Conformado (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Carpintero Metálico y de PVC                            </td>
                            <td>
                                Res. CFE Nro. 130/11 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>320</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=160">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=160">Ver</a>
                            </td>
                            <td>
                                <a href="docs/130-11_01 Carpintero metálico y de PVC.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánico por Arranque de Viruta (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Programador de máquinas comandadas a cnc para el arranque de viruta                            </td>
                            <td>
                                Res. CFE Nro. 130/11 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>760</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=161">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=161">Ver</a>
                            </td>
                            <td>
                                <a href="docs/130-11_02 Programador de maquinas CNC para el arranque de viruta.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánico por Arranque de Viruta (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Operador de máquinas comandadas a CNC para el arranque de viruta                            </td>
                            <td>
                                Res. CFE Nro. 130/11 Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>660</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=162">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=162">Ver</a>
                            </td>
                            <td>
                                <a href="docs/130-11_03 Operador de maquinas CNC para el arranque de viruta.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánico por Conformado (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Zinguero                            </td>
                            <td>
                                Res. CFE Nro. 130/11 Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>280</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=163">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=163">Ver</a>
                            </td>
                            <td>
                                <a href="docs/130-11_04 Zinguero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Sistemas de Suspensión y Dirección (Automotriz)
                            </td>
                            <td>
                                Gomero Balanceador                            </td>
                            <td>
                                Res. CFE Nro. 130/11 Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=164">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=164">Ver</a>
                            </td>
                            <td>
                                <a href="docs/130-11_05 Gomero balanceador.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones Sanitarias y de Gas (Construcción)
                            </td>
                            <td>
                                Auxiliar en Instalaciones Sanitarias y de Gas Domiciliarias                            </td>
                            <td>
                                Res. CFE N°204 /13 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>70</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=165">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=165">Ver</a>
                            </td>
                            <td>
                                <a href="docs/204-13 Gasista Completo - Auxiliar-Montador-Unifuncionales y Domiciliario.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones Sanitarias y de Gas (Construcción)
                            </td>
                            <td>
                                Montador de Instalaciones Domiciliarias de Gas                            </td>
                            <td>
                                Res. CFE N°204 /13 Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=166">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=166">Ver</a>
                            </td>
                            <td>
                                <a href="docs/204-13 Gasista Completo - Auxiliar-Montador-Unifuncionales y Domiciliario.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones Sanitarias y de Gas (Construcción)
                            </td>
                            <td>
                                Gasista de Unidades Unifuncionales                            </td>
                            <td>
                                Res. CFE N°204 /13 Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=167">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=167">Ver</a>
                            </td>
                            <td>
                                <a href="docs/204-13 Gasista Completo - Auxiliar-Montador-Unifuncionales y Domiciliario.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones Sanitarias y de Gas (Construcción)
                            </td>
                            <td>
                                Gasista Domiciliario                            </td>
                            <td>
                                Res. CFE N°204/13 Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>540</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=168">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=168">Ver</a>
                            </td>
                            <td>
                                <a href="docs/204-13 Gasista Completo - Auxiliar-Montador-Unifuncionales y Domiciliario.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones de Energía Eléctrica en Inmuebles (Construcción)
                            </td>
                            <td>
                                Auxiliar en Instalaciones Eléctricas Domiciliarias                            </td>
                            <td>
                                Res. CFE N°108 /10 Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>70</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=169">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=169">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_04 Auxiliar en Instalaciones Eléctricas Domiciliarias.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones de Energía Eléctrica en Inmuebles (Construcción)
                            </td>
                            <td>
                                Montador Electricista Domiciliario                            </td>
                            <td>
                                Res. CFE N°108 /10 Anexo XII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=170">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=170">Ver</a>
                            </td>
                            <td>
                                <a href="docs/108-10_12 Montador Electricista Domiciliario.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones de Energía Eléctrica en Inmuebles (Construcción)
                            </td>
                            <td>
                                Electricista en Inmuebles                            </td>
                            <td>
                                Res. CFE N°149/11 Anexo VI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>540</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=171">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=171">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_06 Electricista en Inmuebles.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Utilización de la Energía Eléctrica en Inmuebles (Energia Eléctrica)
                            </td>
                            <td>
                                Instalador de Sistemas Eléctricos de Energías Renovables                            </td>
                            <td>
                                Res. CFE N°178/12 Anexo IX                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>440</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=172">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=172">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_09 Instalador de Sistemas Eléctricos de Energía Renovable.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Utilización de la Energía Eléctrica en Inmuebles (Energia Eléctrica)
                            </td>
                            <td>
                                Instalador de Sistemas de Muy Baja Tensión                            </td>
                            <td>
                                Res. CFE N°178/12 Anexo X                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=173">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=173">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_10 Instalador de Sistemas de Muy Baja Tension (MBT).pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Mecánico de Motores de Combustión Interna                            </td>
                            <td>
                                Res. CFE N°178/12 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>480</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=174">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=174">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_02 Mecánico de Motores de Combustión Interna.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Auxiliar Mecánico de Motores Nafteros                            </td>
                            <td>
                                Res. CFE N°036/07 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>200</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=175">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=175">Ver</a>
                            </td>
                            <td>
                                <a href="docs/036-07_01 Auxiliar Mecanico de Motores Nafteros.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Mecánico de Sistemas de Encendido y Alimentación                            </td>
                            <td>
                                Res. CFE N°048/08 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>440</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=176">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=176">Ver</a>
                            </td>
                            <td>
                                <a href="docs/048-08_02 Mecanico de sistemas de encendido y alimentacion.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Mecánico de Sistemas de Inyección Diesel                            </td>
                            <td>
                                Res. CFE N°048/08 Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>440</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=177">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=177">Ver</a>
                            </td>
                            <td>
                                <a href="docs/048-08_03 Mecanico de sistemas de inyeccion diesel.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Auxiliar Mecánico de Motores Diesel                            </td>
                            <td>
                                Res. CFE N°036/07 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>200</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=178">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=178">Ver</a>
                            </td>
                            <td>
                                <a href="docs/036-07_02 Auxiliar Mecanico de Motores Diesel.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Electricidad / Electrónica (Automotriz)
                            </td>
                            <td>
                                Electricista de Automotores                            </td>
                            <td>
                                Res. CFE N°149/11 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>400</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=179">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=179">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_01 Electricista de automotores.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Reparación y Mantenimiento de Máquinas y Equipos Eléctricos (Energia Eléctrica)
                            </td>
                            <td>
                                Bobinador de Máquinas Eléctricas                            </td>
                            <td>
                                Res. CFE N°178/12 Anexo XII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=180">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=180">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_12 Bobinador de Maquinas Electricas.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Generación, Transporte y Distribución de Energía Eléctrica (Energía Eléctrica)
                            </td>
                            <td>
                                Auxiliar Electricista de Redes de Distribución de Media y Baja tensión                            </td>
                            <td>
                                Res. CFE Nro. 130/11 Anexo VI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=181">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=181">Ver</a>
                            </td>
                            <td>
                                <a href="docs/130-11_06 Auxiliar electricista de redes de distribucion de media y baja tension.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Utilización de la Energía Eléctrica en la Industria (Energia Eléctrica)
                            </td>
                            <td>
                                Auxiliar Electricista Industrial                            </td>
                            <td>
                                Res. CFE Nro. 130/11 Anexo VII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=182">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=182">Ver</a>
                            </td>
                            <td>
                                <a href="docs/130-11_07 Auxiliar electricista industrial.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Mecánico de Motos                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>600</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=183">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=183">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_02 Mecánico de motos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Mecánico Electrónico de Automotores                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>800</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=184">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=184">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_03 Mecanico electronico de automotores.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Motores de Combustión Interna (Automotriz)
                            </td>
                            <td>
                                Rectificador de Motores de Combustión Interna                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>480</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=185">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=185">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_04 Rectificador de Motores de Combustion Interna.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Generación, Transporte y Distribución de Energía Eléctrica (Energía Eléctrica)
                            </td>
                            <td>
                                Electricista de Redes de Distribución de Media y Baja Tensión                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>600</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=186">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=186">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_05 Electricista de Redes de Distribucion de Media y Baja Tension.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Utilización de la Energía Eléctrica en la Industria (Energia Eléctrica)
                            </td>
                            <td>
                                Electricista Industrial                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo VII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>440</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=187">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=187">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_07 Electricista Industrial.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Hotelería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Ama de Llaves                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo VIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=188">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=188">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_08 Ama de Llaves.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cocina (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Cocinero                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo IX                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=189">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=189">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_09 Cocinero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Atención al Cliente (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Mozo/Camarero de Salón                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo X                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=190">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=190">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_10 Mozo-Camarero de Salón.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Hotelería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Mucama                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo XI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=191">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=191">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_11 Mucama.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Hotelería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Organizador de Eventos                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo XII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=192">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=192">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_12 Organizador de Eventos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Administración y Gestión (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Organizador de Operaciones Hoteleras                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo XIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>800</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=193">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=193">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_13 Organizador de Operaciones Hoteleras.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Panadería y Repostería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Panadero                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo XIV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=194">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=194">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_14 Panadero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Panadería y Repostería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Pastelero                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo XV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=195">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=195">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_15 Pastelero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Hotelería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Recepcionista de Hotel                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo XVI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=196">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=196">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_16 Recepcionista de Hotel.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánico por Conformado (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Plegador                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo XVII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=197">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=197">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_17 Plegador.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánico por Conformado (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Programador y Operador de Máquinas Comandadas a CNC para el Conformado de Materiales                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo XVIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=198">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=198">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_18 Programador y Operador de maquinas comandadas a CNC para el conformado de materiales.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Enfermería (Salud)
                            </td>
                            <td>
                                Auxiliar en Cuidados Gerontológicos                            </td>
                            <td>
                                Res. CFE Nro. 149/11 Anexo IXX                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>380</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=199">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=199">Ver</a>
                            </td>
                            <td>
                                <a href="docs/149-11_19 Auxiliar en cuidados gerontológicos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Animal (Agropecuario)
                            </td>
                            <td>
                                Asistente de Producción Lechera                            </td>
                            <td>
                                Res. CFE Nro. 150/11 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>350</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=200">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=200">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_01 Asistente de producción lechera.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Animal (Agropecuario)
                            </td>
                            <td>
                                Operario en Producción Lechera                            </td>
                            <td>
                                Res. CFE Nro. 150/11 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=201">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=201">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_02 Operario en produccion lechera.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcción de Obra Civil (Construcción)
                            </td>
                            <td>
                                Armador y montador de andamios para obras civiles                            </td>
                            <td>
                                Res. CFE Nro. 150/11 Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=202">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=202">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_03 Armador y montador de andamios para obras civiles.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Terminaciones Decorativas y Funcionales (Construcción)
                            </td>
                            <td>
                                Colocador de Revestimientos Decorativos y Funcionales                            </td>
                            <td>
                                Res. CFE Nro. 150/11 Anexo VII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=203">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=203">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_07 Colocador de revestimientos decorativos y funcionales.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones de Base Húmeda (Construcción)
                            </td>
                            <td>
                                Pintor de Obra                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo VIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=204">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=204">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_08 Pintor de obra.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones de Base Húmeda (Construcción)
                            </td>
                            <td>
                                Yesero                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo IX                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=205">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=205">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_09 Yesero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista a Medida: Modista/o                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo X                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>380</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=206">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=206">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_10 Confeccionista a Medida Modista.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Modelista - Patronista                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo XI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=207">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=207">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_11 Modelista - Patronista.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Operador Cortador de Industria Indumentaria                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo XII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=208">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=208">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_12 Operador Cortador de Industria Indumentaria.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Operador de Máquinas para la Confección de Indumentaria                            </td>
                            <td>
                                Res. CFE N°150/11 Anexo XIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=209">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=209">Ver</a>
                            </td>
                            <td>
                                <a href="docs/150-11_13 Operador de Máquinas para la Confección de Indumentaria.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Aplicado a la Industrialización de la Madera (Madera y Mueble)
                            </td>
                            <td>
                                Auxiliar de Aserradero                            </td>
                            <td>
                                Res. CFE N°158/11 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>200</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=210">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=210">Ver</a>
                            </td>
                            <td>
                                <a href="docs/158-11_01 Auxiliar de Aserradero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Aplicado a la Industrialización de la Madera (Madera y Mueble)
                            </td>
                            <td>
                                Operador de Sala de Afilado                            </td>
                            <td>
                                Res. CFE N°158/11 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=211">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=211">Ver</a>
                            </td>
                            <td>
                                <a href="docs/158-11_02 Operador de Sala de Afilado.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Aplicado a la Industrialización de la Madera (Madera y Mueble)
                            </td>
                            <td>
                                Operador de máquina principal de aserradero                            </td>
                            <td>
                                Res. CFE N°158/11 Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=212">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=212">Ver</a>
                            </td>
                            <td>
                                <a href="docs/158-11_03 Operador de maquina principal de aserradero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Aplicado a la Industrialización de la Madera (Madera y Mueble)
                            </td>
                            <td>
                                Operador de Moldurera                            </td>
                            <td>
                                Res. CFE N°158/11 Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=213">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=213">Ver</a>
                            </td>
                            <td>
                                <a href="docs/158-11_04 Operador de Moldurera.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Aplicado a la Industrialización de la Madera (Madera y Mueble)
                            </td>
                            <td>
                                Operador de secado y tratamiento térmico de la madera                            </td>
                            <td>
                                Res. CFE N°158/11 Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=214">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=214">Ver</a>
                            </td>
                            <td>
                                <a href="docs/158-11_05 Operador de secado y tratamiento térmico de la madera.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Automotores (Automotriz)
                            </td>
                            <td>
                                Mecánico de Transmisiones                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>400</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=217">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=217">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_03 Mecanico de Transmisiones.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Sistemas de Suspensión y Dirección (Automotriz)
                            </td>
                            <td>
                                Mecánico de Sistemas de Suspensión y Dirección del Automotor                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>400</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=218">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=218">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_04 Mecanico de Sistemas de Suspension y Direccion del automotor.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Carrocería (Automotriz)
                            </td>
                            <td>
                                Chapista de Automotores                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>350</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=219">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=219">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_05 Chapista de automotores.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Carrocería (Automotriz)
                            </td>
                            <td>
                                Pintor de Automotores                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo VI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>280</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=220">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=220">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_06 Pintor de automotores.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Generación, Transporte y Distribución de Energía Eléctrica (Energía Eléctrica)
                            </td>
                            <td>
                                Electricista de Centrales de Generación de Energía Eléctrica                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo VII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>540</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=221">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=221">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_07 Electricista de Centrales de generación de Energia Electrica.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Generación, Transporte y Distribución de Energía Eléctrica (Energía Eléctrica)
                            </td>
                            <td>
                                Electricista de Redes de Alta tensión                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo VIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>600</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=222">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=222">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_08 Electricista de Redes de Alta Tension.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Utilización de la Energía Eléctrica en Inmuebles (Energia Eléctrica)
                            </td>
                            <td>
                                Montador Tablerista en Sistemas de Potencia                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>440</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=223">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=223">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_11 Montador Tablerista en Sistemas de Potencia.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Vegetal (Agropecuario)
                            </td>
                            <td>
                                Horticultor                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>400</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=224">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=224">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_13 Horticultor.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Vegetal (Agropecuario)
                            </td>
                            <td>
                                Operario Hortícola                            </td>
                            <td>
                                Res. CFE N° 178/12 - Anexo XIV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=225">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=225">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_14 Operario Horticola.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalurgia (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Moldeador                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=226">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=226">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_15 Moldeador.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalurgia (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Modelista en Madera                            </td>
                            <td>
                                Res. CFE N° 178/12 - Anexo XVI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>320</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=227">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=227">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_16 Modelista en Madera.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalmecánico por Arranque de Viruta (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Operador de Matricería                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XVII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>800</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=228">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=228">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_17 Operador de matriceria.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalurgia (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Operador de Hornos para Tratamientos Térmicos                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XVIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>320</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=229">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=229">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_18 Operador de hornos para tratamientos termicos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalurgia (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Operador de Horno a Inducción para la Fusión de Metales                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XIX                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=230">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=230">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_19 Operador de Horno a Inducción para la Fusión de Metales.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Metalurgia (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Operador de Horno Cubilote                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XX                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=231">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=231">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_20 Operador  de horno cubilote.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Análisis de Procesos y Productos Metalmecánicos (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Operador de Máquinas e Instrumentos de Medición                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XXI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=232">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=232">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_21 Operador de Máquinas e Instrumentos de Medición.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Análisis de Procesos y Productos Metalmecánicos (Mecánica, Metalmecánica y Metalurgia)
                            </td>
                            <td>
                                Auxiliar de Laboratorio                            </td>
                            <td>
                                Res. CFE NÂ° 178/12 - Anexo XXII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>440</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=233">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=233">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178-12_22 Auxiliar de Laboratorio.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Utilización de la Energía Eléctrica en Inmuebles (Energia Eléctrica)
                            </td>
                            <td>
                                Instalador de Sistemas Electricos de Energia Renovables (ISEER hasta 12 kVA)                            </td>
                            <td>
                                Res. CFE Nro. 336/18 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>500</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=234">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=234">Ver</a>
                            </td>
                            <td>
                                <a href="docs/336_18_01 Energia Renovable.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Aplicada al Equipamiento Industrial (Electromecánica)
                            </td>
                            <td>
                                Instalador de Sistemas de Automatización                            </td>
                            <td>
                                Res. CFE N°353/19 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>504</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=235">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=235">Ver</a>
                            </td>
                            <td>
                                <a href="docs/353_19_01 Instalador sistemas de automatizacion.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Productos Lácteos (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador de Quesos                            </td>
                            <td>
                                Res. CFE Nº 353/19 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>450</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=236">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=236">Ver</a>
                            </td>
                            <td>
                                <a href="docs/353_19_02 Elaborador de Quesos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Productos Lácteos (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador de Productos Helados                            </td>
                            <td>
                                Res. CFE N°353/19 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>450</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=237">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=237">Ver</a>
                            </td>
                            <td>
                                <a href="docs/353_19_03 Elaborador de Productos Helados.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Actividad Bomberil
                            </td>
                            <td>
                                Bombero (*)                            </td>
                            <td>
                                Res. CFE Nº 353/19 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>422</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=238">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=238">Ver</a>
                            </td>
                            <td>
                                <a href="docs/353_19_04 Bombero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Actividad Bomberil
                            </td>
                            <td>
                                Bombera/o - Suboficial Subalterno (*)                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>350</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=239">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=239">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_01 Bombero Suboficial Subalterno.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Aplicada al Equipamiento Frío - Calor (Electromecánica)
                            </td>
                            <td>
                                Instalador/a y Reparador/a de Equipos de Climatización                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=240">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=240">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_02 Instalador y Reparador Equipos de climatizacion.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cosmetología (Estética Profesional)
                            </td>
                            <td>
                                Maquillador/a Profesional                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>340</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=241">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=241">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_03 Maquilladora Profesional.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Actividad Bomberil
                            </td>
                            <td>
                                Guardavidas (*)                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>730</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=242">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=242">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_04 Guardavidas.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Forestal (Agropecuario)
                            </td>
                            <td>
                                Inventariador/a                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=243">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=243">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_05 Inventariador.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Carpintería (Madera y Mueble)
                            </td>
                            <td>
                                Operador/a de Clasificación, Corte y Armado de Bastidores de Madera                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo VI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=244">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=244">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_06 Operador de Clasificacion, Corte y Armado de bastidores de Madera.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Animal (Agropecuario)
                            </td>
                            <td>
                                Productor/a de Porcinos                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo VII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>375</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=245">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=245">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_07 Productora de Porcinos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Animal (Agropecuario)
                            </td>
                            <td>
                                Asistente de la Producción Porcina                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo VIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>300</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=246">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=246">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_08 Asistente de la Producción Porcina.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración de Productos Alimenticios (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador/a de Chacinados y Salazones                            </td>
                            <td>
                                Res. CFE Nro. 399/2021 Anexo IX                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>375</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=247">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=247">Ver</a>
                            </td>
                            <td>
                                <a href="docs/399-21_09 Elaboradora de Chacinados y Salazones.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Impresión (Industria Gráfica y Multimedial)
                            </td>
                            <td>
                                Operador de impresoras 3D                            </td>
                            <td>
                                Disp. 33/2022 Anexo 11                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=248">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=248">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_11 - Operador de Impresion 3D.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Recursos Humanos (Administración)
                            </td>
                            <td>
                                Asistente en Administracion de RRHH                            </td>
                            <td>
                                Disp. 33/2022 Anexo 5                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>360</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=249">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=249">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_5 - Asistente en Recursos Humanos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Industria Gráfica (Industria Gráfica y Multimedial)
                            </td>
                            <td>
                                Operador de herramientas de Diseño Gráfico                            </td>
                            <td>
                                Disp. 33/2022 Anexo 10                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>220</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=251">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=251">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_10 OPERADOR DE HERRAMIENTAS DE DISEÑO GRAFICO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Operación y Administracion de Comunicaciones
                            </td>
                            <td>
                                Radio Operador VHF                            </td>
                            <td>
                                Disp. 33/2022 Anexo 13                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>200</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=252">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=252">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_13 - Radio Operador VHF.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Vivero y Espacios Verdes (Agropecuario)
                            </td>
                            <td>
                                Operario en Jardineria y Vivero                            </td>
                            <td>
                                Disp. 104/2018 Anexo 5                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=253">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=253">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_05 OPERARIO EN  JARDINERIA Y VIVERO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Servicios (Agropecuario)
                            </td>
                            <td>
                                Operario Fruticola                            </td>
                            <td>
                                Disp. 104/2018 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=256">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=256">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_04 OPERARIO FRUTICOLA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Servicios (Agropecuario)
                            </td>
                            <td>
                                Auxiliar Elaborador de Bebidas Fermentadas                            </td>
                            <td>
                                Disp. 104/2018 Anexo 6                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=257">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=257">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_06 AUXILIAR ELABORADOR DE BEBIDAS FERMENTADAS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Servicios (Agropecuario)
                            </td>
                            <td>
                                Auxiliar Elaborador de Agroalimentos de Origen Vegetal                            </td>
                            <td>
                                Disp. 104/2018 Anexo 7                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=258">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=258">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_07 AUXILIAR ELABORADOR DE AGROALIMENTOS DE ORIGEN VEGETAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Servicios (Agropecuario)
                            </td>
                            <td>
                                Auxiliar Elaborador de Agroalimentos de Origen Animal                            </td>
                            <td>
                                Disp. 104/2018 Anexo 8                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=259">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=259">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_08 AUXILIAR ELABORADOR DE AGROALIMENTOS DE ORIGEN ANIMAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Servicios (Agropecuario)
                            </td>
                            <td>
                                Auxiliar de Producción Porcina                            </td>
                            <td>
                                Disp. 104/2018 Anexo 9                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=260">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=260">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_09 AUXILIAR DE PRODUCCION PORCINA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Construcciones de Base Húmeda (Construcción)
                            </td>
                            <td>
                                Albañil en Tierra Cruda                            </td>
                            <td>
                                Disp. 104/2018 Anexo 10                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=261">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=261">Ver</a>
                            </td>
                            <td>
                                <a href="docs/104-18_10 ALBAÑIL EN TIERRA CRUDA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Administración y Gestión (Administración)
                            </td>
                            <td>
                                Auxiliar de Gestoría del Automotor                            </td>
                            <td>
                                Disp. 33/2022 Anexo 4                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>220</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=262">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=262">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_4 - Auxiliar de Gestoría del Automotor.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Administración (Salud)
                            </td>
                            <td>
                                Recepcionista en Servicios de Salud                            </td>
                            <td>
                                Disp. 33/2022 Anexo 12                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>337</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=263">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=263">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_12 - Recepcionista en Servicio de Salud.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Panadería y Repostería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Maestro Pizzero                            </td>
                            <td>
                                Disp. 33/2022 Anexo 8                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>218</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=264">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=264">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_8 -  Maestro Pizzero.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración y Conservación de Alimentos (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaboracion y Envasado de dulces y conservas                            </td>
                            <td>
                                Disp. 33/2022 Anexo 9                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>218</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=266">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=266">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_9 - Elaboración y Envasado de dulces y conservas.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Animal (Agropecuario)
                            </td>
                            <td>
                                Manejo Integral de rodeos mixtos                            </td>
                            <td>
                                Disp. 33/2022 Anexo 6                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>350</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=267">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=267">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_6 - Manejo Integral de rodeos mixtos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Vegetal (Agropecuario)
                            </td>
                            <td>
                                Horticultor/a Agroecologico/a                            </td>
                            <td>
                                Disp. 33/2022 Anexo 7                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>280</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=268">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=268">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_7 - Horticultor Agroecologico.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Carpintería (Madera y Mueble)
                            </td>
                            <td>
                                Reparación y Mantenimiento de instrumentos musicales de cuerda                            </td>
                            <td>
                                Disp. 33/2022 Anexo 3                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=272">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=272">Ver</a>
                            </td>
                            <td>
                                <a href="docs/033-22_3 - Reparación y Mantenimiento de.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Análisis y Programación de Sistemas (Informática)
                            </td>
                            <td>
                                Programador Web                            </td>
                            <td>
                                Res. CFE Nro. 351/2019 Anexo I                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>205</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=273">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=273">Ver</a>
                            </td>
                            <td>
                                <a href="docs/351-19_01 Programador Web.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Análisis y Programación de Sistemas (Informática)
                            </td>
                            <td>
                                Programador de Dispositivos Móviles                            </td>
                            <td>
                                Res. CFE Nro. 351/2019 Anexo II                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>185</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=274">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=274">Ver</a>
                            </td>
                            <td>
                                <a href="docs/351-19_02 Programador de dispositivos Moviles.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Análisis y Programación de Sistemas (Informática)
                            </td>
                            <td>
                                Programador de Videojuegos                            </td>
                            <td>
                                Res. CFE Nro. 351/2019 Anexo III                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                3                            </td>
                            <td>225</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=275">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=275">Ver</a>
                            </td>
                            <td>
                                <a href="docs/351-19_03 Programador de videojuegos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Muebles (Madera y Mueble)
                            </td>
                            <td>
                                Armador de Muebles de Melamina                            </td>
                            <td>
                                Disp. N°031/21 Anexo 1                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>340</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=276">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=276">Ver</a>
                            </td>
                            <td>
                                <a href="docs/031-21_1-ARMADOR_DE_MUEBLES_EN_MELAMINA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Muebles (Madera y Mueble)
                            </td>
                            <td>
                                Artesano en Madera                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=278">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=278">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178_22_01_ARTESANO_EN_MADERA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Artesanal (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Artesano en Platería Regional                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=279">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=279">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178_22_02 ARTESANO EN PLATERIA REGIONAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Carpintería (Madera y Mueble)
                            </td>
                            <td>
                                Construccion de Instrumentos Musicales de Caja Vaciada                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=280">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=280">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178_22_03 Construccion de instrumentos musicales de caja vaciada.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Carpintería (Madera y Mueble)
                            </td>
                            <td>
                                Construccion de Instrumentos Musicales de Cuerda Pulsada                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=281">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=281">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178_22_04 - MR Construccion de instrumentos musicales de cuerda pulsada.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración de Bebidas (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador Artesanal de Cerveza                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>220</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=282">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=282">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178_22_05 - MR ELABORADOR ARTESANAL DE CERVEZA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración de Bebidas (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador Artesanal de Vinos                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo VI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>290</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=283">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=283">Ver</a>
                            </td>
                            <td>
                                <a href="docs/178_22_06 - MR ELABORADOR ARTESANAL DE VINOS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración de Bebidas (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador de Agroalimentos Origen Vegetal                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo VII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=284">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=284">Ver</a>
                            </td>
                            <td>
                                <a href="docs/Anexo 07 - MR ELABORADOR DE AGROALIMENTOS ORIGEN VEGETAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración y Conservación de Alimentos (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador de Embutidos, Chacinados y Ahumados                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo VIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=285">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=285">Ver</a>
                            </td>
                            <td>
                                <a href="docs/Anexo 08 - MR ELABORADOR DE EMBUTIDOS, CHACINADOS Y AHUMADOS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Carpintería (Madera y Mueble)
                            </td>
                            <td>
                                Elaborador de Jugueteria en Madera                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo IX                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=286">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=286">Ver</a>
                            </td>
                            <td>
                                <a href="docs/Anexo 09 - MR ELABORADOR DE JUGUETERIA EN MADRERA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Elaboración de Bebidas (Industria de la Alimentación)
                            </td>
                            <td>
                                Elaborador de Sidra                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo X                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=287">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=287">Ver</a>
                            </td>
                            <td>
                                <a href="docs/Anexo 10 - MR ELABORADOR DE SIDRA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Terminaciones Decorativas y Funcionales (Construcción)
                            </td>
                            <td>
                                Mosaiquista                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo XI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=288">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=288">Ver</a>
                            </td>
                            <td>
                                <a href="docs/Anexo 11 - MR MOSAIQUISTA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Vegetal (Agropecuario)
                            </td>
                            <td>
                                Productor de Hierbas Aromaticas                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo XII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=289">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=289">Ver</a>
                            </td>
                            <td>
                                <a href="docs/Anexo 12 - MR PRODUCTOR DE HIERBAS AROMÁTICAS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Vegetal (Agropecuario)
                            </td>
                            <td>
                                Productor de Hongos sobre Troncos                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo XIII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>150</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=290">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=290">Ver</a>
                            </td>
                            <td>
                                <a href="docs/Anexo 13 - MR PRODUCTOR DE HONGOS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Operación y Administracion de Comunicaciones
                            </td>
                            <td>
                                Radio Operador de Emergencias                            </td>
                            <td>
                                Disp. 0178/2022 - Anexo XIV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>200</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=291">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=291">Ver</a>
                            </td>
                            <td>
                                <a href="docs/Anexo 14 - MR RADIO – OPERADOR DE EMERGENCIAS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Mantenimiento y Reparación de Sistemas de Frenos (Automotriz)
                            </td>
                            <td>
                                Mecánico de Sistemas de Frenos                            </td>
                            <td>
                                Res. CFE Nº 048/08 Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                3                            </td>
                            <td>480</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=292">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=292">Ver</a>
                            </td>
                            <td>
                                <a href="docs/048-08_01 Mecanico de sistemas de frenos.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cosmetología (Estética Profesional)
                            </td>
                            <td>
                                Cosmetólogo/a Esteticista                            </td>
                            <td>
                                Resolución CFE Nº 438/22 Anexo I                            </td>
                            <td>
                                FPÏ                            </td>
                            <td>
                                3                            </td>
                            <td>480</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=293">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=293">Ver</a>
                            </td>
                            <td>
                                <a href="docs/438-22_Cosmetologa_Esteticista.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Idioma (Turismo)
                            </td>
                            <td>
                                Especialización en Inglés Turístico                            </td>
                            <td>
                                Disp. 077/2023 - Anexo IV                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                2                            </td>
                            <td>90</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=295">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=295">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_077_23_04 FPC IDIOMA INGLES ESPECIALIZACION EN TURISMO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Idioma (Turismo)
                            </td>
                            <td>
                                Especialización en portugués turístico                            </td>
                            <td>
                                Disp. 077/2023 - Anexo V                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                2                            </td>
                            <td>90</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=296">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=296">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_077_23_05 FPC IDIOMA PORTUGUES ESPECIALIZACION EN TURISMO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cerámica (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Ceramista Artesanal                             </td>
                            <td>
                                Disp. 077/2023 - Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>432</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=297">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=297">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_077_23_01_CERAMISTA_ARTESANAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Confeccionista en Fieltro                            </td>
                            <td>
                                Disp. 077/2023 - Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>160</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=298">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=298">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_077_23_02 FPI Confeccionista en Fieltro.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Actividades Recreativas (Turismo)
                            </td>
                            <td>
                                Anfitrion Turistico Local                            </td>
                            <td>
                                Disp. 077/2023 - Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=299">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=299">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_077_23_03 FPI ANFITRION TURISTICO LOCAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Forestal (Agropecuario)
                            </td>
                            <td>
                                Operador/a forestal                            </td>
                            <td>
                                Disp. 076/2023 - Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>250</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=300">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=300">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_01 FPI MR OPERADOR FORESTAL.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Producción Vegetal (Agropecuario)
                            </td>
                            <td>
                                Elaborador de Fitopreparados Naturales                            </td>
                            <td>
                                Disp. 076/2023 - Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=301">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=301">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_02 FPI MR ELABORADOR DE FITOPREPARADOS NATURALES.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Tapicería (Textil e Indumentaria)
                            </td>
                            <td>
                                Tapicero/a                            </td>
                            <td>
                                Disp. 076/2023 - Anexo III                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>420</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=302">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=302">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_03 FPI MR DE TAPICERIA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Multimedial (Industria Gráfica y Multimedial)
                            </td>
                            <td>
                                Operador de Herramientas para Modelado 3D                            </td>
                            <td>
                                Disp. 076/2023 - Anexo IV                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>300</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=303">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=303">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_04 FPI MR DE OPERADOR DE HERRAMIENTAS PARA MODELADO 3D.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Artístico y Artesanal (Actividades Artísticas Técnicas)
                            </td>
                            <td>
                                Forjador de cuchillos                            </td>
                            <td>
                                Disp. 076/2023 - Anexo V                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>320</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=304">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=304">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_05 FPI MR DE FORJADOR DE CUCHILLOS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cuero (Cuero y Calzado)
                            </td>
                            <td>
                                Artesano Talabartero                            </td>
                            <td>
                                Disp. 076/2023 - Anexo VI                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>270</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=305">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=305">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_06 FPI MR DE ARTESANO TALABARTERO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Especialización en Accesorios Textiles en Fieltro                            </td>
                            <td>
                                Disp. 076/2023 - Anexo XII                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                1                            </td>
                            <td>80</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=306">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=306">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_12 FPC ESPECIALIZACION EN ACCESORIOS TEXTILES EN FIELTRO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Peluquería (Estética Profesional)
                            </td>
                            <td>
                                Especialización en Barberia                            </td>
                            <td>
                                Disp. 076/2023 - Anexo VIII                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                1                            </td>
                            <td>60</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=307">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=307">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_08 FPC ESPECIALIZACION EN BARBERIA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Panadería y Repostería (Hotelería y Gastronomía)
                            </td>
                            <td>
                                Chocolatero/a                            </td>
                            <td>
                                Disp. 076/2023 - Anexo VII                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                1                            </td>
                            <td>218</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=308">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=308">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_07 FPI MR DE CHOCOLATERO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Tejido (Textil e Indumentaria)
                            </td>
                            <td>
                                Especialización en Matras y Maletas                            </td>
                            <td>
                                Disp. 076/2023 - Anexo IX                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                1                            </td>
                            <td>170</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=309">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=309">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_09 FPC ESPECIALIZACION EN MATRAS Y MALETAS.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Carpintería (Madera y Mueble)
                            </td>
                            <td>
                                Especialización en Tornero en Madera                            </td>
                            <td>
                                Disp. 076/2023 - Anexo X                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                1                            </td>
                            <td>240</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=310">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=310">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_10 FPC ESPECIALIZACION EN TORNERIA EN MADERA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Diseño de Indumentaria y Textil (Textil e Indumentaria)
                            </td>
                            <td>
                                Especialización en Superficies Textiles en Fieltro                            </td>
                            <td>
                                Disp. 076/2023 - Anexo XI                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                1                            </td>
                            <td>80</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=311">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=311">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_11 FPC ESPECIALIZACION EN SUPERFICIES TEXTILES EN FIELTRO.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones Sanitarias y de Gas (Construcción)
                            </td>
                            <td>
                                Actualización Profesional en Dibujo Técnico Asistido por Computadora en 2D para Gasistas                            </td>
                            <td>
                                Disp. 076/2023 - Anexo XIII                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                2                            </td>
                            <td>60</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=312">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=312">Ver</a>
                            </td>
                            <td>
                                <a href="docs/DI_076_23_13 FPC ACTUALIZACION CAD GASISTA.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Servicios (Agropecuario)
                            </td>
                            <td>
                                Operador/a de Tractor y Maquinarias Agrícolas                            </td>
                            <td>
                                Disp. 233/2023 - Anexo I                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>320</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=313">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=313">Ver</a>
                            </td>
                            <td>
                                <a href="docs/233-23_01.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Muebles (Madera y Mueble)
                            </td>
                            <td>
                                Carpintero de Muebles en Melamina, Enchapados y con Perfilería de Aluminio                            </td>
                            <td>
                                Disp. 233/2023 - Anexo II                            </td>
                            <td>
                                FPI                            </td>
                            <td>
                                2                            </td>
                            <td>540</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=314">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=314">Ver</a>
                            </td>
                            <td>
                                <a href="docs/233-23_02.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Cosmetología (Estética Profesional)
                            </td>
                            <td>
                                Especialización en Uñas Esculpidas                            </td>
                            <td>
                                Disp. 233/2023 - Anexo III                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                0                            </td>
                            <td>120</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=315">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=315">Ver</a>
                            </td>
                            <td>
                                <a href="docs/233-23_03.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Instalaciones Sanitarias y de Gas (Construcción)
                            </td>
                            <td>
                                Especialización en Calderas de calefacción por agua y Equipos Centrales de Calefacción a Gas                            </td>
                            <td>
                                Disp. 233/2023 - Anexo IV                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                0                            </td>
                            <td>100</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=316">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=316">Ver</a>
                            </td>
                            <td>
                                <a href="docs/233-23_04.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Utilización de la Energía Eléctrica en Inmuebles (Energia Eléctrica)
                            </td>
                            <td>
                                Especialización en Domótica Aplicada                            </td>
                            <td>
                                Disp. 233/2023 - Anexo V                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                0                            </td>
                            <td>120</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=317">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=317">Ver</a>
                            </td>
                            <td>
                                <a href="docs/233-23_05.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                            <tr>
                            <td>
                                Muebles (Madera y Mueble)
                            </td>
                            <td>
                                Especialización en Entramado en Madera                            </td>
                            <td>
                                Disp. 233/2023 - Anexo VI                            </td>
                            <td>
                                FPC                            </td>
                            <td>
                                0                            </td>
                            <td>180</td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-primary btn-sm" 
                                    href="./centrosXtrayecto.php?id=318">Centros</a>
                            </td>
                            <td>
                                <a  type="button" 
                                    class="btn btn-success btn-sm" 
                                    href="Trayecto.php?id=318">Ver</a>
                            </td>
                            <td>
                                <a href="docs/233-23_06.pdf" target="_blank" aria-current="true">
                                    <i class="fa fa-download" aria-hidden="true"></i>
                                                                    </a>
                            </td>

                        </tr>
                                    </tbody>

                <tfoot>
                    <tr>
                        <th>SubSector</th>
                        <th>Denominacion</th>
                        <th>Norma Legal</th>
                        <th>Tip oCert</th>
                        <th>Nivel</th>
                        <th>Duracion</th>
                        <th>Centros</th>
                        <th>Trayectos</th>
                        <th>Descargar</th>
                    </tr>
                </tfoot>
            </table>            </div>
        </div>
    </div>






<!-- Google -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="js/scripts.js"></script>
<script type="text/javascript" src="\js\mysql.js"></script>

        
        
                        </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; ST3 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<!--         <script src="assets/demo/chart-area-demo.js"></script> Ejemplo-->
<!--        <script src="assets/demo/chart-bar-demo.js"></script> Ejemplo--> 
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<!--         <script src="js/datatables-simple-demo.js"></script> Ejemplo--> -->
    </body>
</html>