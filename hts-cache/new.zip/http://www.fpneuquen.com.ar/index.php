<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-D23TBS0BCN"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'G-D23TBS0BCN');
    </script>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="Web de consulta de Centros de Formacion Profesional" />
    <meta name="author" content="Silvio Stenta" />
    <title>Formacion Profesional WEB</title>
    <link rel="icon" type="image/png" href="img/logofp.png">
    <link rel="stylesheet" href="https://bootswatch.com/5/superhero/bootstrap.min.css">

  <!--   <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" /> -->
<!--     <link href="css/styles.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/bootstrap.min.css" />  -->

    <!-- Impact Templed -->

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Raleway:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">      
    <!-- <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"> -->
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">  

    <!-- Template Main CSS File -->
     <link href="assets/css/main.css" rel="stylesheet"> 


</head>

<body>

    <!-- ======= Hero Section ======= -->
    <section id="hero" class="hero">
        <div class="container position-relative">
            <div class="row gy-5" data-aos="fade-in">
                <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
                    <h2>Bienvenido a <span>Formación Profesional </span></h2>
                    <p>En este espacio podras encontrar los centros educativos de la provincia de Neuquen que presentan ofertas de Formacion Profesional y los trayectos formativos aprobados, tambien conocer el contenido del trayecto y donde cursarlo.</p>
                    <div class="d-flex justify-content-center justify-content-lg-start">
                        <a href="dashboard.php" class="btn-get-started">Ingresar</a>
                        <!-- <a href="https://www.youtube.com/watch?v=LXb3EKWsInQ" class="glightbox btn-watch-video d-flex align-items-center"><i class="bi bi-play-circle"></i><span>Watch Video</span></a> -->
                    </div>
                </div>
                <div class="col-lg-6 order-1 order-lg-2">
                    <!-- <img src="assets/img/hero-img.svg" class="img-fluid" alt="" data-aos="zoom-out" data-aos-delay="100"> -->

                    <div id="carouselExampleControls" class="carousel slide w-70" data-bs-ride="carousel" style="align-items: center ;">
                        <div class="carousel-inner w-80">
                            <div class="carousel-item active">
                                <img src="./img/ATM.jpg" class="d-block w-100">
                            </div>
                            <div class="carousel-item">
                                <img src="./img/3d.jpg" class="d-block w-100">
                            </div>
                            <div class="carousel-item">
                                <img src="./img/cpe.jpg" class="d-block w-100">
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>

                    </div>

                </div>
            </div>
        </div>

        <div class="icon-boxes position-relative">
            <div class="container position-relative">
                <div class="row gy-4 mt-5">

                    <div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                        <div class="icon-box">
                            <div class="icon"><i class="bi bi-easel"></i></div>
                            <h4 class="title"><a href="TrayectosFormativos.php" class="stretched-link">Trayectos Formativos</a></h4>
                        </div>
                    </div>
                    <!--End Icon Box -->

                    <div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon"> <i class="fas fa-tools"></i> </div>
                            <h4 class="title"><a href="Sectores.php" class="stretched-link">Sectores Productivos</a></h4>
                        </div>
                    </div>
                    <!--End Icon Box -->

                    <div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
                        <div class="icon-box">
                            <div class="icon"><i class="bi bi-geo-alt"></i></div>
                            <h4 class="title"><a href="centrosxzonas.php" class="stretched-link">Centros por Ubicacion</a></h4>
                        </div>
                    </div>

                    <!--End Icon Box -->

                    <div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                        <div class="icon-box">
                            <div class="icon"><i class="bi bi-book"></i></div>
                            <h4 class="title"><a href="digesto.php" class="stretched-link">Digesto</a></h4>
                        </div>
                    </div>
                    <!--End Icon Box -->

                    <div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
                        <div class="icon-box">
                            <div class="icon"><i class="bi bi-hospital "></i></div>
                            <h4 class="title"><a href="table.php" class="stretched-link">Centros de Formacion Profesional</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        </div>
    </section>
    <!-- End Hero Section -->


    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>  
    <script src="assets/vendor/aos/aos.js"></script>
      <!--     
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>  -->

    <!-- Template Main JS File -->
   <script src="assets/js/main.js"></script> 

</body>

</html>